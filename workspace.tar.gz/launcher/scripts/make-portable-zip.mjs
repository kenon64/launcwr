/**
 * Упаковка release/win-unpacked в portable-ZIP внешним 7za из ЛЁГКОГО процесса.
 *
 * Зачем: в средах с жёстким лимитом RAM (≤1 ГБ) любой spawn из «тяжёлого»
 * процесса electron-builder (7za/makensis/app-builder) падает с ENOMEM.
 * Здесь 7za стартует из крошечного node-процесса (~30 МБ RSS) — fork дёшев,
 * лимит не затрагивается. Сам 7za стримит сжатие и ест мало памяти.
 *
 * Результат: release/WOSERGAME-Launcher-<version>-Portable.zip
 *   (в корне архива — "WOSERGAME Launcher.exe": распаковал → запустил)
 *
 * Запуск: node scripts/make-portable-zip.mjs
 */
import { spawn } from 'node:child_process'
import { chmod, stat } from 'node:fs/promises'
import { createRequire } from 'node:module'
import path from 'node:path'

const require = createRequire(import.meta.url)
const root = path.resolve(import.meta.dirname, '..')
const pkg = require(path.join(root, 'package.json'))

// 7zip-bin — зависимость electron-builder, уже лежит в node_modules.
// Берём ПРЯМОЙ бинарь платформы (обёртка path7x на linux иногда даёт 127).
const sevenZipBin = require('7zip-bin')
const candidates =
  process.platform === 'win32'
    ? [sevenZipBin.path7x, path.join(root, 'node_modules/7zip-bin/win/x64/7za.exe')]
    : process.platform === 'darwin'
      ? [sevenZipBin.path7x, path.join(root, 'node_modules/7zip-bin/mac/7za')]
      : [path.join(root, 'node_modules/7zip-bin/linux/x64/7za'), sevenZipBin.path7x]
let sevenZip = candidates[0]
for (const c of candidates) {
  try {
    await stat(c)
    sevenZip = c
    break
  } catch {
    /* пробуем следующий */
  }
}
const unpackedDir = path.join(root, 'release', 'win-unpacked')
const outFile = path.join(root, 'release', `${pkg.productName.replace(/\s+/g, '-')}-${pkg.version}-Portable.zip`)

await chmod(sevenZip, 0o755)
try {
  await stat(unpackedDir)
} catch {
  console.error('ERROR: нет release/win-unpacked — сначала выполните:')
  console.error('  npx electron-builder --win --dir --config.win.signAndEditExecutable=false')
  process.exit(1)
}

// -mx=1: быстрое сжатие с минимальной памятью; exe/MPQ-подобный контент всё
// равно плохо жмётся, а RAM и время экономим существенно
const args = ['a', '-tzip', '-mx=1', '-mtc=off', outFile, '.']
console.log(`[zip] ${sevenZip} ${args.join(' ')}  (cwd: ${unpackedDir})`)

const child = spawn(sevenZip, args, { cwd: unpackedDir, stdio: 'inherit' })
child.on('error', (e) => {
  console.error('ERROR: не удалось запустить 7za:', e.message)
  process.exit(1)
})
child.on('close', async (code) => {
  if (code !== 0) {
    console.error(`ERROR: 7za завершился с кодом ${code}`)
    process.exit(code ?? 1)
  }
  const st = await stat(outFile)
  console.log(`✓ portable-архив: ${path.relative(root, outFile)} (${(st.size / 1048576).toFixed(1)} МБ)`)
  console.log('  Внутри: "WOSERGAME Launcher.exe" + все файлы — распакуйте и запускайте.')
})
