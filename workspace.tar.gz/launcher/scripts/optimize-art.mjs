/**
 * Оптимизация арт-ассетов: PNG 2048² (~4 МБ/шт) → JPEG 1920px (~300-500 КБ/шт).
 * Слои фона painterly-стиля отлично переносят JPEG q85, а «прозрачность»
 * средних слоёв обеспечивается CSS-масками, а не альфа-каналом.
 * Запуск: node scripts/optimize-art.mjs  (требуется devDependency jimp)
 */
import { Jimp } from 'jimp'
import { mkdir } from 'node:fs/promises'
import path from 'node:path'

const ROOT = path.resolve(import.meta.dirname, '..')
const SRC = path.join(ROOT, 'art')
const OUT = path.join(ROOT, 'src/renderer/src/assets')

const JOBS = [
  { name: 'far', quality: 86 },
  { name: 'mid', quality: 86 },
  { name: 'near', quality: 88 }
]

await mkdir(OUT, { recursive: true })

for (const job of JOBS) {
  const src = path.join(SRC, `${job.name}.png`)
  const dst = path.join(OUT, `${job.name}.jpg`)
  const image = await Jimp.read(src)
  // Приводим квадрат 2048² к широкому формату: берём нижнюю полосу кадра,
  // где расположена композиция (небо/горы/силуэты), и масштабируем до 1920px
  const w = image.bitmap.width
  const h = image.bitmap.height
  const cropH = Math.floor(h * (job.name === 'far' ? 0.62 : 0.6))
  image.crop({ x: 0, y: h - cropH, w, h: cropH })
  image.resize({ w: 1920, h: Jimp.AUTO })
  await image.write(dst, { quality: job.quality })
  console.log(`✓ ${job.name}.jpg  ${image.bitmap.width}x${image.bitmap.height}`)
}
