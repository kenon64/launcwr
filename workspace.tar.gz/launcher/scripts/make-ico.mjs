/**
 * Генерация packaging/icon.ico из resources/icon.png БЕЗ electron-builder.
 * Формат: ICO с PNG-сжатием (валидно для Windows Vista+ и для rcedit).
 * Зачем: в средах с лимитом RAM (1 ГБ) spawn app-builder для конвертации
 * иконки из тяжёлого процесса сборщика падает с ENOMEM — готовый .ico
 * убирает этот шаг целиком.
 * Запуск: node scripts/make-ico.mjs [вход.png] [выход.ico] [размер]
 */
import { readFile, writeFile } from 'node:fs/promises'
import { Jimp } from 'jimp'

const input = process.argv[2] ?? 'resources/icon.png'
const output = process.argv[3] ?? 'packaging/icon.ico'
const size = Number(process.argv[4] ?? 256)

// 1) Готовим PNG нужного размера (jimp → buffer)
const image = await Jimp.read(input)
image.resize({ w: size, h: size })
const png = await image.getBuffer('image/png')

// 2) Упаковываем PNG в контейнер ICO (1 изображение, PNG-сжатие)
const header = Buffer.alloc(6)
header.writeUInt16LE(0, 0) // reserved
header.writeUInt16LE(1, 2) // type: icon
header.writeUInt16LE(1, 4) // count

const entry = Buffer.alloc(16)
entry.writeUInt8(size >= 256 ? 0 : size, 0) // width  (0 = 256)
entry.writeUInt8(size >= 256 ? 0 : size, 1) // height (0 = 256)
entry.writeUInt8(0, 2) // color palette
entry.writeUInt8(0, 3) // reserved
entry.writeUInt16LE(1, 4) // planes
entry.writeUInt16LE(32, 6) // bpp
entry.writeUInt32LE(png.length, 8) // bytes in res
entry.writeUInt32LE(6 + 16, 12) // offset

await writeFile(output, Buffer.concat([header, entry, png]))
console.log(`✓ ${output}: ${size}x${size}, PNG-compressed, ${(png.length / 1024).toFixed(0)} КБ`)
