/**
 * WindowManager: создание и контроль главного окна.
 *  - frameless-окно с кастомным titlebar'ом (drag-region в CSS renderer'а);
 *  - жёсткие настройки безопасности webPreferences;
 *  - запрет навигаций и window.open (внешние ссылки — только shell.openExternal через IPC);
 *  - minWidth/minHeight, центрирование, восстановление размера.
 */
import { BrowserWindow, screen, shell } from 'electron'
import path from 'node:path'
import { logger } from '../services/logger/LoggerService'
import { eventBus } from '../services/EventBus'
import { launchService } from '../services/wow/LaunchService'
import { configService } from '../services/config/ConfigService'

const SCOPE = 'Window'

const WIN_WIDTH = 1280
const WIN_HEIGHT = 800
const MIN_WIDTH = 1024
const MIN_HEIGHT = 640

export class WindowManager {
  private win: BrowserWindow | null = null

  get window(): BrowserWindow | null {
    return this.win
  }

  create(): BrowserWindow {
    const { workArea } = screen.getPrimaryDisplay()
    const width = Math.min(WIN_WIDTH, workArea.width - 40)
    const height = Math.min(WIN_HEIGHT, workArea.height - 40)

    this.win = new BrowserWindow({
      width,
      height,
      minWidth: MIN_WIDTH,
      minHeight: MIN_HEIGHT,
      show: false,
      title: 'WOSERGAME Launcher',
      backgroundColor: '#070b12',
      frame: false,
      autoHideMenuBar: true,
      webPreferences: {
        preload: path.join(__dirname, '../preload/index.js'),
        contextIsolation: true,
        nodeIntegration: false,
        sandbox: true,
        spellcheck: false,
        devTools: process.env.NODE_ENV === 'development',
        // Отключаем всё лишнее: веб-безопасность превыше всего
        webSecurity: true,
        allowRunningInsecureContent: false,
        experimentalFeatures: false
      }
    })

    // Показываем только после готовности содержимого (без «белой вспышки»)
    this.win.once('ready-to-show', () => {
      this.win?.show()
      logger.info(SCOPE, 'Окно показано')
    })

    // Полная остановка анимаций, когда окно свёрнуто/скрыто (экономия CPU)
    this.win.on('minimize', () => this.win?.webContents.send('app:visibility', false))
    this.win.on('restore', () => this.win?.webContents.send('app:visibility', true))
    this.win.on('maximize', () => this.win?.webContents.send('app:maximized', true))
    this.win.on('unmaximize', () => this.win?.webContents.send('app:maximized', false))

    // Запрет навигаций внутри окна
    this.win.webContents.on('will-navigate', (e, url) => {
      e.preventDefault()
      logger.warn(SCOPE, `Заблокирована навигация: ${url}`)
    })
    // window.open → наружу, только https
    this.win.webContents.setWindowOpenHandler(({ url }) => {
      if (url.startsWith('https://')) void shell.openExternal(url)
      return { action: 'deny' }
    })

    // Минимизация при старте игры (настройка minimizeOnGameStart)
    eventBus.on('game:state', (state) => {
      const s = state as { running: boolean }
      if (s.running && configService.userConfig.launch.minimizeOnGameStart && this.win && !this.win.isMinimized()) {
        this.win.minimize()
      }
    })

    if (process.env.ELECTRON_RENDERER_URL) {
      void this.win.loadURL(process.env.ELECTRON_RENDERER_URL)
    } else {
      void this.win.loadFile(path.join(__dirname, '../renderer/index.html'))
    }

    this.win.on('closed', () => {
      this.win = null
    })

    return this.win
  }

  minimize(): void {
    this.win?.minimize()
  }

  toggleMaximize(): void {
    if (!this.win) return
    if (this.win.isMaximized()) this.win.unmaximize()
    else this.win.maximize()
  }

  close(): void {
    this.win?.close()
  }

  isMaximized(): boolean {
    return this.win?.isMaximized() ?? false
  }

  /** Фокус/создание окна при повторном запуске (single-instance). */
  focusOrRestore(): void {
    if (!this.win) {
      this.create()
      return
    }
    if (this.win.isMinimized()) this.win.restore()
    this.win.focus()
  }

  dispose(): void {
    launchService.dispose()
    this.win = null
  }
}

export const windowManager = new WindowManager()
