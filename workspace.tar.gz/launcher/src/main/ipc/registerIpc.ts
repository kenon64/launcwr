/**
 * Единая точка регистрации IPC-обработчиков.
 * Все каналы описаны в @shared/ipc; аргументы валидируются на входе,
 * наружу уходят только сериализуемые DTO (без объектов Node/Electron).
 */
import { app, dialog, ipcMain, shell } from 'electron'
import type { UserConfig } from '@shared/types'
import { IPC } from '@shared/ipc'
import { configService } from '../services/config/ConfigService'
import { logger } from '../services/logger/LoggerService'
import { eventBus } from '../services/EventBus'
import { windowManager } from '../window/WindowManager'
import { wowClientService } from '../services/wow/WowClientService'
import { realmlistService } from '../services/wow/RealmlistService'
import { launchService } from '../services/wow/LaunchService'
import { integrityService } from '../services/integrity/IntegrityService'
import { patchUpdater } from '../services/updater/PatchUpdater'
import { launcherUpdater } from '../services/updater/LauncherUpdater'
import { realmStatusService } from '../services/status/RealmStatusService'
import { normalizeDirInput } from '../util/safePath'
import { httpsGetJson } from '../util/http'
import { parseClientManifest } from '../services/updater/manifestSchema'

const SCOPE = 'IPC'

/** Безопасное открытие внешних ссылок: только https. */
async function openExternalSafe(url: unknown): Promise<boolean> {
  if (typeof url !== 'string') return false
  try {
    const u = new URL(url)
    if (u.protocol !== 'https:' && u.protocol !== 'http:') return false
    await shell.openExternal(url)
    return true
  } catch {
    return false
  }
}

export function registerIpc(): void {
  // ─── Приложение / окно ────────────────────────────────────────────────────
  ipcMain.handle(IPC.APP_INFO, () => ({
    version: app.getVersion(),
    electron: process.versions.electron,
    chrome: process.versions.chrome,
    node: process.versions.node,
    platform: process.platform,
    arch: process.arch
  }))
  ipcMain.on(IPC.APP_MINIMIZE, () => windowManager.minimize())
  ipcMain.on(IPC.APP_MAXIMIZE, () => windowManager.toggleMaximize())
  ipcMain.on(IPC.APP_CLOSE, () => windowManager.close())
  ipcMain.handle(IPC.APP_OPEN_EXTERNAL, (_e, url: unknown) => openExternalSafe(url))
  ipcMain.handle(IPC.APP_OPEN_PATH, async (_e, p: unknown) => {
    if (typeof p !== 'string') return false
    const result = await shell.openPath(p)
    return result === ''
  })

  // ─── Конфигурация ─────────────────────────────────────────────────────────
  ipcMain.handle(IPC.CONFIG_GET, () => configService.snapshot())
  ipcMain.handle(IPC.CONFIG_SET, (_e, patch: unknown) => {
    if (typeof patch !== 'object' || patch === null) throw new Error('config:set: ожидается объект')
    return configService.set(patch as Partial<UserConfig>)
  })
  ipcMain.handle(IPC.CONFIG_RESET, () => configService.reset(true))

  // ─── Клиент WoW ───────────────────────────────────────────────────────────
  ipcMain.handle(IPC.CLIENT_VALIDATE, async (_e, p: unknown) => {
    const target = typeof p === 'string' && p.trim() ? normalizeDirInput(p) : configService.userConfig.clientPath
    return wowClientService.validate(target)
  })
  ipcMain.handle(IPC.CLIENT_PICK, async () => {
    const win = windowManager.window
    if (!win) return null
    const res = await dialog.showOpenDialog(win, {
      title: 'Выберите каталог с клиентом WoW 3.3.5a',
      properties: ['openDirectory', 'showHiddenFiles'],
      defaultPath: configService.userConfig.clientPath ?? app.getPath('home')
    })
    if (res.canceled || res.filePaths.length === 0) return null
    const dir = normalizeDirInput(res.filePaths[0])
    configService.set({ clientPath: dir })
    logger.info(SCOPE, `Пользователь выбрал каталог клиента: ${dir}`)
    return dir
  })
  ipcMain.handle(IPC.CLIENT_AUTODETECT, () => wowClientService.autodetect())

  // ─── Realmlist ────────────────────────────────────────────────────────────
  ipcMain.handle(IPC.REALMLIST_APPLY, async (_e, p: unknown) => {
    const dir = typeof p === 'string' && p.trim() ? normalizeDirInput(p) : configService.userConfig.clientPath
    if (!dir) return { ok: false, files: [], error: 'Путь к клиенту не задан' }
    return realmlistService.apply(dir, configService.serverConfig.server.realmHost)
  })

  // ─── Игра ────────────────────────────────────────────────────────────────
  ipcMain.handle(IPC.GAME_LAUNCH, () => launchService.launch())
  ipcMain.handle(IPC.GAME_STATE, () => launchService.getState())

  // ─── Целостность ──────────────────────────────────────────────────────────
  ipcMain.handle(IPC.INTEGRITY_START, async () => {
    const clientPath = configService.userConfig.clientPath
    if (!clientPath) throw new Error('Путь к клиенту не задан')
    // Манифест берём из настроек обновлений, если они включены; иначе — проверка ключевых файлов
    let manifest = null
    const srv = configService.serverConfig
    if (srv.updates.enabled && srv.updates.manifestUrl) {
      try {
        const raw = await httpsGetJson<unknown>(srv.updates.manifestUrl, { maxBytes: 4 * 1024 * 1024 })
        const parsed = parseClientManifest(raw)
        if (parsed.ok) manifest = parsed.manifest
      } catch (e) {
        logger.warn(SCOPE, `manifest недоступен, проверка по списку файлов пропущена: ${(e as Error).message}`)
      }
    }
    if (!manifest) {
      // Локальный fallback-манифест из resources (если админ положил его туда)
      manifest = await loadLocalManifest()
    }
    return integrityService.verify(clientPath, manifest)
  })
  ipcMain.on(IPC.INTEGRITY_CANCEL, () => integrityService.cancel())
  ipcMain.handle(IPC.INTEGRITY_LAST, () => integrityService.last())

  // ─── Патчи клиента ────────────────────────────────────────────────────────
  ipcMain.handle(IPC.PATCH_START, () => patchUpdater.start())
  ipcMain.on(IPC.PATCH_CANCEL, () => patchUpdater.cancel())
  ipcMain.handle(IPC.PATCH_STATE, () => patchUpdater.getState())

  // ─── Самообновление лаунчера ──────────────────────────────────────────────
  ipcMain.handle(IPC.UPDATE_CHECK, () => launcherUpdater.check())
  ipcMain.handle(IPC.UPDATE_INSTALL, () => launcherUpdater.install())
  ipcMain.handle(IPC.UPDATE_STATE, () => launcherUpdater.getState())

  // ─── Статус сервера ───────────────────────────────────────────────────────
  ipcMain.handle(IPC.STATUS_CHECK, () => realmStatusService.check())

  // ─── Логи ─────────────────────────────────────────────────────────────────
  ipcMain.handle(IPC.LOGS_RECENT, () => logger.recent())
  ipcMain.handle(IPC.LOGS_CLEAR, () => {
    logger.clearRing()
    return true
  })
  ipcMain.handle(IPC.LOGS_OPEN_FILE, async () => {
    const file = logger.logFile()
    const result = await shell.openPath(file)
    return result === ''
  })

  // ─── Проброс событий main → renderer ──────────────────────────────────────
  const eventNames = [
    'game:state',
    'integrity:progress',
    'integrity:done',
    'patch:state',
    'update:state',
    'status:update',
    'log:entry',
    'config:changed'
  ] as const
  for (const name of eventNames) {
    eventBus.on(name, (payload) => {
      const win = windowManager.window
      if (win && !win.isDestroyed()) win.webContents.send('event:' + name, payload)
    })
  }
  // Логи: отдельно подписываем эмиттер logger'а на шину
  logger.setEmitter((entry) => eventBus.emitEvent('log:entry', entry))
  configService.onChange(() => eventBus.emitEvent('config:changed', null))

  logger.info(SCOPE, `Зарегистрировано IPC-каналов: ${Object.keys(IPC).length}`)
}

/** Локальный manifest.json из resources/manifests (офлайн-режим проверки). */
async function loadLocalManifest(): Promise<import('@shared/types').ClientManifest | null> {
  const fs = await import('node:fs')
  const path = await import('node:path')
  const candidates = [
    path.join(process.resourcesPath ?? '', 'manifests', 'client-manifest.json'),
    path.join(app.getAppPath(), 'manifests', 'client-manifest.json')
  ]
  for (const file of candidates) {
    try {
      if (fs.existsSync(file)) {
        const parsed = parseClientManifest(JSON.parse(fs.readFileSync(file, 'utf8')))
        if (parsed.ok) return parsed.manifest
      }
    } catch {
      /* пропускаем */
    }
  }
  return null
}
