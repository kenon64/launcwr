/**
 * Точка входа главного процесса WOSERGAME Launcher.
 * Порядок инициализации:
 *   single-instance lock → logger → userData → config → IPC → окно → фоновые сервисы.
 * Любая ошибка на старте логируется и показывается пользователю диалогом.
 */
import { app, dialog } from 'electron'
import { logger } from './services/logger/LoggerService'
import { configService } from './services/config/ConfigService'
import { registerIpc } from './ipc/registerIpc'
import { windowManager } from './window/WindowManager'
import { realmStatusService } from './services/status/RealmStatusService'
import { launcherUpdater } from './services/updater/LauncherUpdater'

const SCOPE = 'Main'

// ─── Single-instance: второй экземпляр не нужен ─────────────────────────────
const gotLock = app.requestSingleInstanceLock()
if (!gotLock) {
  app.quit()
} else {
  app.on('second-instance', () => {
    logger.info(SCOPE, 'Попытка второго запуска — фокусирую существующее окно')
    windowManager.focusOrRestore()
  })

  main()
}

function main(): void {
  // Аппаратное ускорение GPU для плавных canvas-анимаций renderer'а
  app.commandLine.appendSwitch('enable-gpu-rasterization')
  app.commandLine.appendSwitch('enable-zero-copy')
  // Предсказуемое имя каталога профиля: %APPDATA%/WOSERGAME
  app.setPath('userData', require('node:path').join(app.getPath('appData'), 'WOSERGAME'))
  app.setAppUserModelId('net.wosergame.launcher')

  app
    .whenReady()
    .then(async () => {
      logger.init()
      logger.info(SCOPE, `WOSERGAME Launcher v${app.getVersion()} стартует (electron ${process.versions.electron}, ${process.platform}-${process.arch})`)

      // Уборка после portable-самообновления: удаляем прежний exe (.old)
      if (app.isPackaged && process.platform === 'win32') {
        const fsp = await import('node:fs/promises')
        await fsp.rm(process.execPath + '.old', { force: true }).catch(() => undefined)
      }

      await configService.ensureUserDataDir()
      configService.load()
      registerIpc()
      windowManager.create()

      // Фоновые сервисы — после создания окна, чтобы не тормозить старт UI
      realmStatusService.start()
      if (launcherUpdater.isEnabled()) {
        // Не блокируем старт: проверка апдейта в фоне через 5 секунд
        setTimeout(() => void launcherUpdater.check(), 5000)
      }
      logger.info(SCOPE, 'Инициализация завершена')

      // ─── Smoke-режим для CI/разработки: снять скриншот окна и выйти ───────
      if (process.env.WOS_SMOKE) {
        const win = windowManager.window
        if (win) {
          win.webContents.once('did-finish-load', () => {
            setTimeout(() => {
              win.webContents
                .capturePage()
                .then((img) => {
                  const fs = require('node:fs')
                  const out = process.env.WOS_SMOKE_OUT || 'smoke.png'
                  fs.writeFileSync(out, img.toPNG())
                  logger.info(SCOPE, `Smoke-скриншот сохранён: ${out}`)
                  app.quit()
                })
                .catch((e) => {
                  logger.errorEx(SCOPE, 'Smoke: capturePage не удался', e)
                  app.quit()
                })
            }, Number(process.env.WOS_SMOKE_DELAY ?? 4000))
          })
        }
      }
    })
    .catch((e) => {
      logger.errorEx(SCOPE, 'Критическая ошибка инициализации', e)
      void dialog.showErrorBox(
        'WOSERGAME Launcher — ошибка запуска',
        `Не удалось инициализировать лаунчер:\n${e instanceof Error ? e.message : String(e)}\n\nПодробности в логе: ${logger.logFile()}`
      )
      app.quit()
    })

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit()
  })

  app.on('activate', () => {
    if (windowManager.window === null) windowManager.create()
  })

  app.on('before-quit', () => {
    logger.info(SCOPE, 'Завершение работы лаунчера')
    realmStatusService.stop()
    configService.flush()
  })

  // Защита: падение renderer'а не должно ронять лаунчер молча
  process.on('uncaughtException', (e) => {
    logger.errorEx(SCOPE, 'uncaughtException', e)
  })
  process.on('unhandledRejection', (reason) => {
    logger.errorEx(SCOPE, 'unhandledRejection', reason)
  })
}
