/**
 * Сервис логирования: файл + кольцевой буфер для UI.
 * Файл: %APPDATA%/WOSERGAME/logs/launcher.log (ротация 5 МБ, electron-log).
 */
import path from 'node:path'
import { app } from 'electron'
import log from 'electron-log/main'
import type { LogEntry, LogLevel } from '@shared/types'

const RING_SIZE = 400

class LoggerService {
  private ring: LogEntry[] = []
  private emitter: ((e: LogEntry) => void) | null = null

  /** Инициализация транспортных каналов. Вызывается один раз на старте. */
  init(): void {
    log.initialize()
    log.transports.file.maxSize = 5 * 1024 * 1024
    log.transports.file.format = '[{y}-{m}-{d} {h}:{i}:{s}.{ms}] [{level}] {text}'
    log.transports.file.resolvePathFn = () => path.join(this.logsDir(), 'launcher.log')
    log.transports.console.level = process.env.NODE_ENV === 'development' ? 'debug' : 'info'
    log.info('─── Новая сессия лаунчера ───')
  }

  logsDir(): string {
    return path.join(app.getPath('userData'), 'logs')
  }

  logFile(): string {
    return path.join(this.logsDir(), 'launcher.log')
  }

  /** Подписка на новые записи (для проброса в renderer). */
  setEmitter(fn: (e: LogEntry) => void): void {
    this.emitter = fn
  }

  private push(level: LogLevel, scope: string, message: string): void {
    const entry: LogEntry = { ts: Date.now(), level, scope, message }
    this.ring.push(entry)
    if (this.ring.length > RING_SIZE) this.ring.shift()
    this.emitter?.(entry)
    const text = `[${scope}] ${message}`
    switch (level) {
      case 'error':
        log.error(text)
        break
      case 'warn':
        log.warn(text)
        break
      case 'debug':
        log.debug(text)
        break
      default:
        log.info(text)
    }
  }

  info(scope: string, message: string): void {
    this.push('info', scope, message)
  }

  warn(scope: string, message: string): void {
    this.push('warn', scope, message)
  }

  error(scope: string, message: string): void {
    this.push('error', scope, message)
  }

  debug(scope: string, message: string): void {
    this.push('debug', scope, message)
  }

  /** Удобный вывод ошибок с раскрытием cause/stack. */
  errorEx(scope: string, message: string, err: unknown): void {
    const e = err as Error | undefined
    const detail = e ? `${e.message}${e.stack ? ' | ' + e.stack.split('\n').slice(1, 3).join(' ').trim() : ''}` : String(err)
    this.push('error', scope, `${message}: ${detail}`)
  }

  recent(): LogEntry[] {
    return [...this.ring]
  }

  clearRing(): void {
    this.ring = []
  }
}

export const logger = new LoggerService()
