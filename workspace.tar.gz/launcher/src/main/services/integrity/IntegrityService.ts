/**
 * IntegrityService: проверка целостности файлов клиента по SHA256.
 * Хеширование вынесено в пул worker_threads (до 4 потоков), чтобы не блокировать
 * главный процесс и UI на многогигабайтных MPQ-архивах.
 * Worker создаётся из строки кода (eval:true), чтобы не плодить отдельные бандлы.
 */
import { Worker } from 'node:worker_threads'
import { createReadStream } from 'node:fs'
import fsp from 'node:fs/promises'
import os from 'node:os'
import path from 'node:path'
import { createHash } from 'node:crypto'
import type { ClientManifest, IntegrityIssue, IntegrityProgress, IntegrityReport } from '@shared/types'
import { safeJoin } from '../../util/safePath'
import { logger } from '../logger/LoggerService'
import { eventBus } from '../EventBus'

const SCOPE = 'Integrity'

/** JS-код worker'а: получает {id, path}, отвечает progress/done/error. */
const HASH_WORKER_SOURCE = `
const { parentPort } = require('worker_threads');
const fs = require('fs');
const crypto = require('crypto');
parentPort.on('message', (job) => {
  const hash = crypto.createHash('sha256');
  let done = 0, total = 0, last = 0;
  try { total = fs.statSync(job.path).size; } catch (e) {
    parentPort.postMessage({ type: 'error', id: job.id, message: e.message });
    return;
  }
  const stream = fs.createReadStream(job.path, { highWaterMark: 4 * 1024 * 1024 });
  stream.on('data', (chunk) => {
    hash.update(chunk);
    done += chunk.length;
    const now = Date.now();
    if (now - last > 120) { last = now; parentPort.postMessage({ type: 'progress', id: job.id, bytesDone: done, bytesTotal: total }); }
  });
  stream.on('end', () => parentPort.postMessage({ type: 'done', id: job.id, sha256: hash.digest('hex'), size: done }));
  stream.on('error', (e) => parentPort.postMessage({ type: 'error', id: job.id, message: e.message }));
});
`

interface Job {
  rel: string
  abs: string
  expectedSha: string | null
  expectedSize: number | null
}

interface WorkerMsg {
  type: 'progress' | 'done' | 'error'
  id: string
  sha256?: string
  size?: number
  bytesDone?: number
  bytesTotal?: number
  message?: string
}

export class IntegrityService {
  private workers = new Set<Worker>()
  private cancelled = false
  private running = false
  private lastReport: IntegrityReport | null = null
  private cancelHook: (() => void) | null = null

  isRunning(): boolean {
    return this.running
  }

  last(): IntegrityReport | null {
    return this.lastReport
  }

  /** Безопасная отмена: резолвит runPool и terminates воркеров. */
  cancel(): void {
    if (!this.running) return
    this.cancelled = true
    this.teardownWorkers()
    this.cancelHook?.()
    logger.warn(SCOPE, 'Проверка целостности отменена пользователем')
  }

  private teardownWorkers(): void {
    for (const w of this.workers) {
      try {
        w.terminate()
      } catch {
        /* noop */
      }
    }
    this.workers.clear()
  }

  /**
   * Проверка файлов клиента по manifest.json.
   * Пустой manifest.files → мгновенный пустой отчёт.
   */
  async verify(clientPath: string, manifest: ClientManifest | null): Promise<IntegrityReport> {
    if (this.running) throw new Error('Проверка целостности уже выполняется')
    this.running = true
    this.cancelled = false
    const startedAt = Date.now()

    const jobs: Job[] = []
    const skipped: IntegrityIssue[] = []
    if (manifest) {
      for (const f of manifest.files) {
        try {
          jobs.push({ rel: f.path, abs: safeJoin(clientPath, f.path), expectedSha: f.sha256, expectedSize: f.size })
        } catch (e) {
          logger.warn(SCOPE, `manifest: небезопасный путь пропущен: ${f.path} (${(e as Error).message})`)
          skipped.push({ path: f.path, kind: 'unreadable', expected: f.sha256, actual: null })
        }
      }
    }

    const bytesTotal = jobs.reduce((s, j) => s + (j.expectedSize ?? 0), 0)
    const progress: IntegrityProgress = { filesDone: 0, filesTotal: jobs.length, bytesDone: 0, bytesTotal, currentFile: null }
    const issues: IntegrityIssue[] = [...skipped]
    let bytesScanned = 0

    try {
      if (jobs.length > 0 && !this.cancelled) {
        eventBus.emitEvent('integrity:progress', { ...progress })
        await this.runPool(jobs, progress, issues, (n) => (bytesScanned = n))
      }
      const report: IntegrityReport = {
        finishedAt: Date.now(),
        durationMs: Date.now() - startedAt,
        total: jobs.length,
        okCount: Math.max(0, jobs.length - issues.filter((i) => i.kind !== 'unreadable').length),
        bytesScanned,
        issues: this.cancelled ? [] : issues,
        manifestVersion: manifest?.version ?? null
      }
      if (!this.cancelled) {
        this.lastReport = report
        eventBus.emitEvent('integrity:done', report)
        logger.info(
          SCOPE,
          `Проверка завершена: ${report.okCount}/${report.total} OK, проблем: ${issues.length}, ${(bytesScanned / 1048576).toFixed(1)} МБ за ${(report.durationMs / 1000).toFixed(1)} с`
        )
      } else {
        logger.warn(SCOPE, 'Проверка прервана — отчёт не сформирован')
      }
      return report
    } finally {
      this.teardownWorkers()
      this.cancelHook = null
      this.running = false
    }
  }

  /** Хеширование одного файла в главном процессе (skip-логика PatchUpdater). */
  async hashOne(absPath: string): Promise<{ sha256: string; size: number } | null> {
    try {
      const st = await fsp.stat(absPath)
      const hash = createHash('sha256')
      await new Promise<void>((res, rej) => {
        const rs = createReadStream(absPath, { highWaterMark: 4 * 1024 * 1024 })
        rs.on('data', (c) => hash.update(c))
        rs.on('end', () => res())
        rs.on('error', rej)
      })
      return { sha256: hash.digest('hex'), size: st.size }
    } catch {
      return null
    }
  }

  /** Абсолютный путь файла манифеста внутри клиента (с защитой от traversal). */
  resolveInClient(clientPath: string, rel: string): string {
    return safeJoin(clientPath, rel)
  }

  /** Нормализация пути для отображения в UI (всегда slash-разделители). */
  displayPath(p: string): string {
    return p.split(path.sep).join('/')
  }

  // ─── Внутреннее: пул воркеров ─────────────────────────────────────────────

  private runPool(
    jobs: Job[],
    progress: IntegrityProgress,
    issues: IntegrityIssue[],
    setScanned: (n: number) => void
  ): Promise<void> {
    return new Promise((resolve) => {
      // Крюк отмены: резолвим промис сразу после cancel()
      this.cancelHook = () => resolve()

      const poolSize = Math.max(1, Math.min(4, os.cpus().length))
      const queue = [...jobs]
      const inFlight = new Map<Worker, Job>()
      const partialBytes = new Map<string, number>()
      let doneBytes = 0
      let active = 0

      const recalcBytes = (): void => {
        let sum = doneBytes
        for (const v of partialBytes.values()) sum += v
        progress.bytesDone = sum
        setScanned(sum)
      }

      const finish = (): void => {
        active--
        if (active <= 0) resolve()
      }

      const feed = (w: Worker): void => {
        if (this.cancelled) {
          finish()
          return
        }
        const job = queue.shift()
        if (!job) {
          finish()
          return
        }
        inFlight.set(w, job)
        progress.currentFile = job.rel
        w.postMessage({ id: job.rel, path: job.abs })
      }

      for (let i = 0; i < poolSize; i++) {
        const w = new Worker(HASH_WORKER_SOURCE, { eval: true })
        this.workers.add(w)
        w.on('message', (msg: WorkerMsg) => {
          const job = inFlight.get(w)
          if (!job || msg.id !== job.rel) return
          if (msg.type === 'progress') {
            partialBytes.set(job.rel, msg.bytesDone ?? 0)
            recalcBytes()
            eventBus.emitEvent('integrity:progress', { ...progress })
          } else if (msg.type === 'done') {
            inFlight.delete(w)
            partialBytes.delete(job.rel)
            doneBytes += msg.size ?? 0
            progress.filesDone++
            recalcBytes()
            if (job.expectedSha && msg.sha256 !== job.expectedSha) {
              issues.push({ path: job.rel, kind: 'hash-mismatch', expected: job.expectedSha, actual: msg.sha256 ?? null })
            } else if (job.expectedSize !== null && msg.size !== job.expectedSize) {
              issues.push({ path: job.rel, kind: 'size-mismatch', expected: String(job.expectedSize), actual: String(msg.size) })
            }
            eventBus.emitEvent('integrity:progress', { ...progress })
            feed(w)
          } else {
            // error: файл отсутствует или не читается
            inFlight.delete(w)
            partialBytes.delete(job.rel)
            progress.filesDone++
            recalcBytes()
            issues.push({ path: job.rel, kind: msg.message?.includes('EPERM') ? 'unreadable' : 'missing', expected: job.expectedSha, actual: null })
            eventBus.emitEvent('integrity:progress', { ...progress })
            feed(w)
          }
        })
        w.on('error', (e) => {
          logger.errorEx(SCOPE, 'Worker hashing упал', e)
          const job = inFlight.get(w)
          if (job) {
            inFlight.delete(w)
            partialBytes.delete(job.rel)
            progress.filesDone++
            issues.push({ path: job.rel, kind: 'unreadable', expected: job.expectedSha, actual: null })
          }
          feed(w)
        })
        active++
        feed(w)
      }
    })
  }
}

export const integrityService = new IntegrityService()
