/**
 * Мини-шина событий главного процесса (main → renderer).
 * index.ts подписывает её на webContents.send.
 */
import { EventEmitter } from 'node:events'
import type { LauncherEventMap, LauncherEventName } from '@shared/types'

class EventBusService extends EventEmitter {
  constructor() {
    super()
    this.setMaxListeners(20)
  }

  emitEvent<K extends LauncherEventName>(name: K, payload: LauncherEventMap[K]): void {
    this.emit(name, payload)
  }
}

export const eventBus = new EventBusService()
