/**
 * RealmStatusService: индикатор онлайн/офлайн realm-сервера.
 * Метод: TCP-handshake на auth-порт (3724 для WoW 3.3.5a) + замер latency.
 * Опционально: HTTPS statusUrl вида {"players": 123} для счётчика онлайна.
 * Опрос: каждые 60 с + по требованию из UI.
 */
import net from 'node:net'
import type { RealmStatus } from '@shared/types'
import { configService } from '../config/ConfigService'
import { logger } from '../logger/LoggerService'
import { eventBus } from '../EventBus'
import { httpsGetJson } from '../../util/http'

const SCOPE = 'RealmStatus'
const POLL_MS = 60_000
const CONNECT_TIMEOUT_MS = 5000

export class RealmStatusService {
  private timer: NodeJS.Timeout | null = null
  private last: RealmStatus | null = null
  private checking = false

  getStatus(): RealmStatus {
    if (this.last) return { ...this.last }
    const s = configService.serverConfig.server
    return { state: 'unknown', host: s.realmHost, port: s.realmPort, latencyMs: null, players: null, checkedAt: 0 }
  }

  start(): void {
    this.stop()
    void this.check()
    this.timer = setInterval(() => void this.check(), POLL_MS)
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer)
    this.timer = null
  }

  async check(): Promise<RealmStatus> {
    if (this.checking) return this.getStatus()
    this.checking = true
    const s = configService.serverConfig.server
    const started = Date.now()
    try {
      const tcpOk = await this.tcpProbe(s.realmHost, s.realmPort)
      let players: number | null = null
      if (tcpOk && s.statusUrl) {
        players = await this.fetchPlayers(s.statusUrl)
      }
      const status: RealmStatus = {
        state: tcpOk ? 'online' : 'offline',
        host: s.realmHost,
        port: s.realmPort,
        latencyMs: tcpOk ? Date.now() - started : null,
        players,
        checkedAt: Date.now()
      }
      if (!this.last || this.last.state !== status.state) {
        logger.info(SCOPE, `Статус сервера: ${status.state}${status.latencyMs !== null ? ` (${status.latencyMs} мс)` : ''}`)
      }
      this.last = status
      eventBus.emitEvent('status:update', status)
      return status
    } catch (e) {
      logger.errorEx(SCOPE, 'Ошибка проверки статуса', e)
      const status: RealmStatus = { state: 'unknown', host: s.realmHost, port: s.realmPort, latencyMs: null, players: null, checkedAt: Date.now() }
      this.last = status
      eventBus.emitEvent('status:update', status)
      return status
    } finally {
      this.checking = false
    }
  }

  /** TCP-подключение к auth-порту: успешный handshake = сервер жив. */
  private tcpProbe(host: string, port: number): Promise<boolean> {
    return new Promise((resolve) => {
      const socket = net.connect({ host, port, timeout: CONNECT_TIMEOUT_MS })
      const done = (ok: boolean): void => {
        socket.destroy()
        resolve(ok)
      }
      socket.once('connect', () => done(true))
      socket.once('timeout', () => done(false))
      socket.once('error', () => done(false))
    })
  }

  /** Опциональный счётчик игроков (строго HTTPS, строго число). */
  private async fetchPlayers(url: string): Promise<number | null> {
    try {
      const data = await httpsGetJson<{ players?: unknown }>(url, { timeoutMs: 6000, maxBytes: 64 * 1024 })
      return typeof data.players === 'number' && Number.isFinite(data.players) ? Math.floor(data.players) : null
    } catch {
      return null
    }
  }
}

export const realmStatusService = new RealmStatusService()
