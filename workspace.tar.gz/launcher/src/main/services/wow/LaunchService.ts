/**
 * LaunchService: запуск Wow.exe с аргументами, контроль жизненного цикла.
 *  - обычный запуск: child_process.spawn (detached, windowsHide);
 *  - если каталог read-only и включён elevateIfReadonly — запуск через
 *    PowerShell Start-Process -Verb RunAs (запрос UAC), статус игры при этом
 *    отслеживается опросом списка процессов;
 *  - авто-починка realmlist перед стартом (настройка autoFixRealmlist).
 */
import { spawn } from 'node:child_process'
import { existsSync } from 'node:fs'
import type { GameState, LaunchResult } from '@shared/types'
import { configService } from '../config/ConfigService'
import { logger } from '../logger/LoggerService'
import { eventBus } from '../EventBus'
import { wowClientService } from './WowClientService'
import { realmlistService } from './RealmlistService'

const SCOPE = 'Launch'
const ELEVATED_POLL_MS = 5000

export class LaunchService {
  private state: GameState = { running: false, pid: null, lastExitCode: null, launchedAt: null }
  private elevatedTimer: NodeJS.Timeout | null = null

  getState(): GameState {
    return { ...this.state }
  }

  private setState(patch: Partial<GameState>): void {
    this.state = { ...this.state, ...patch }
    eventBus.emitEvent('game:state', this.getState())
  }

  /** Сборка аргументов командной строки из настроек пользователя. */
  buildArgs(): string[] {
    const u = configService.userConfig.launch
    const args: string[] = []
    if (u.windowed) args.push('-window')
    if (u.console) args.push('-console')
    for (const a of u.extraArgs) {
      const clean = a.trim()
      if (clean && !clean.includes('\n')) args.push(clean)
    }
    return args
  }

  async launch(): Promise<LaunchResult> {
    if (this.state.running) {
      return { ok: false, pid: this.state.pid, elevated: false, error: 'Игра уже запущена' }
    }
    const clientPath = configService.userConfig.clientPath
    const validation = await wowClientService.validate(clientPath)
    if (!validation.ok || !validation.wowExe) {
      const msg = validation.errors.map((e) => e.message).join('; ') || 'Клиент не найден'
      logger.error(SCOPE, `Запуск отменён: ${msg}`)
      return { ok: false, pid: null, elevated: false, error: msg }
    }
    if (!existsSync(validation.wowExe)) {
      return { ok: false, pid: null, elevated: false, error: `Файл не существует: ${validation.wowExe}` }
    }

    // Авто-починка realmlist
    if (configService.userConfig.launch.autoFixRealmlist) {
      const host = configService.serverConfig.server.realmHost
      const rl = await realmlistService.apply(clientPath!, host)
      if (!rl.ok) {
        logger.warn(SCOPE, `Не удалось применить realmlist: ${rl.error}`)
      }
    }

    const args = this.buildArgs()
    const needElevate = !validation.writable && configService.userConfig.launch.elevateIfReadonly && process.platform === 'win32'

    try {
      if (needElevate) {
        this.launchElevated(validation.wowExe, clientPath!, args)
      } else {
        const child = spawn(validation.wowExe, args, {
          cwd: clientPath!,
          detached: true,
          stdio: 'ignore',
          windowsHide: false
        })
        child.unref()
        child.on('exit', (code) => {
          logger.info(SCOPE, `Wow.exe завершился с кодом ${code}`)
          this.setState({ running: false, pid: null, lastExitCode: code })
        })
        child.on('error', (e) => {
          logger.errorEx(SCOPE, 'Ошибка процесса Wow.exe', e)
          this.setState({ running: false, pid: null })
        })
        this.setState({ running: true, pid: child.pid ?? null, launchedAt: Date.now() })
      }

      logger.info(SCOPE, `Запуск: ${validation.wowExe} ${args.join(' ')} (elevated=${needElevate})`)

      if (configService.userConfig.launch.minimizeOnGameStart) {
        eventBus.emitEvent('game:state', this.getState()) // окно минимизирует WindowManager по событию
      }
      return { ok: true, pid: this.state.pid, elevated: needElevate, error: null }
    } catch (e) {
      logger.errorEx(SCOPE, 'Не удалось запустить игру', e)
      return { ok: false, pid: null, elevated: needElevate, error: e instanceof Error ? e.message : String(e) }
    }
  }

  /** Запуск с запросом UAC (PowerShell Start-Process -Verb RunAs). */
  private launchElevated(exe: string, cwd: string, args: string[]): void {
    const argList = args.map((a) => `'${a.replace(/'/g, "''")}'`).join(', ')
    const ps =
      `Start-Process -FilePath '${exe.replace(/'/g, "''")}' ` +
      `-WorkingDirectory '${cwd.replace(/'/g, "''")}' ` +
      (argList ? `-ArgumentList ${argList} ` : '') +
      '-Verb RunAs'
    const child = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command', ps], {
      stdio: 'ignore',
      windowsHide: true
    })
    child.on('error', (e) => logger.errorEx(SCOPE, 'Ошибка elevated-запуска', e))
    this.setState({ running: true, pid: null, launchedAt: Date.now() })
    this.startElevatedPolling()
  }

  /** Опрос списка процессов, пока не увидим Wow.exe (для elevated-режима). */
  private startElevatedPolling(): void {
    this.stopElevatedPolling()
    let misses = 0
    this.elevatedTimer = setInterval(() => {
      const probe = spawn('tasklist', ['/FO', 'CSV', '/NH', '/FI', 'IMAGENAME eq Wow.exe'], {
        stdio: ['ignore', 'pipe', 'ignore'],
        windowsHide: true
      })
      let out = ''
      probe.stdout.on('data', (d: Buffer) => (out += d.toString()))
      probe.on('close', () => {
        const alive = /wow\.exe/i.test(out)
        if (alive) {
          misses = 0
        } else if (this.state.running) {
          misses++
          // Даём игре время стартовать (первые ~15 с) и фиксируем выход после
          if (misses >= 3 && Date.now() - (this.state.launchedAt ?? 0) > 15_000) {
            logger.info(SCOPE, 'Wow.exe больше не найден в процессах — игра закрыта')
            this.setState({ running: false, pid: null, lastExitCode: null })
            this.stopElevatedPolling()
          }
        }
      })
    }, ELEVATED_POLL_MS)
  }

  private stopElevatedPolling(): void {
    if (this.elevatedTimer) {
      clearInterval(this.elevatedTimer)
      this.elevatedTimer = null
    }
  }

  dispose(): void {
    this.stopElevatedPolling()
  }
}

export const launchService = new LaunchService()
