/**
 * RealmlistService: поиск и правка realmlist.wtf в клиенте WoW 3.3.5a.
 * Особенности:
 *  - регистронезависимый поиск каталогов/файлов (Windows case-insensitive, но бывают кривые сборки);
 *  - поддержка кодировок UTF-8 (с BOM и без) и UTF-16LE;
 *  - бэкап исходного файла перед правкой (realmlist.wtf.bak);
 *  - правятся ВСЕ найденные локали (enUS/enGB/ruRU/...).
 */
import fsp from 'node:fs/promises'
import path from 'node:path'
import type { RealmlistFileResult, RealmlistResult } from '@shared/types'
import { buildRealmlist, parseRealmlist } from './realmlistCore'
import { logger } from '../logger/LoggerService'

const SCOPE = 'Realmlist'

const KNOWN_LOCALES = ['enUS', 'enGB', 'ruRU', 'deDE', 'frFR', 'esES', 'esMX', 'ptBR', 'zhCN', 'zhTW', 'koKR']

type Encoding = 'utf8' | 'utf8-bom' | 'utf16le'

function decode(buf: Buffer): { text: string; encoding: Encoding } {
  if (buf.length >= 2 && buf[0] === 0xff && buf[1] === 0xfe) {
    return { text: buf.subarray(2).toString('utf16le'), encoding: 'utf16le' }
  }
  if (buf.length >= 3 && buf[0] === 0xef && buf[1] === 0xbb && buf[2] === 0xbf) {
    return { text: buf.subarray(3).toString('utf8'), encoding: 'utf8-bom' }
  }
  return { text: buf.toString('utf8'), encoding: 'utf8' }
}

function encode(text: string, encoding: Encoding): Buffer {
  switch (encoding) {
    case 'utf16le':
      return Buffer.concat([Buffer.from([0xff, 0xfe]), Buffer.from(text, 'utf16le')])
    case 'utf8-bom':
      return Buffer.concat([Buffer.from([0xef, 0xbb, 0xbf]), Buffer.from(text, 'utf8')])
    default:
      return Buffer.from(text, 'utf8')
  }
}

/** Регистронезависимый поиск имени среди записей каталога. */
async function findIgnoreCase(dir: string, wanted: string): Promise<string | null> {
  let entries: string[]
  try {
    entries = await fsp.readdir(dir)
  } catch {
    return null
  }
  const lower = wanted.toLowerCase()
  const hit = entries.find((e) => e.toLowerCase() === lower)
  return hit ?? null
}

export class RealmlistService {
  /** Список файлов realmlist.wtf во всех локалях клиента. */
  async listFiles(clientPath: string): Promise<string[]> {
    const dataDirName = await findIgnoreCase(clientPath, 'Data')
    if (!dataDirName) return []
    const dataDir = path.join(clientPath, dataDirName)
    const result: string[] = []
    for (const locale of KNOWN_LOCALES) {
      const localeDirName = await findIgnoreCase(dataDir, locale)
      if (!localeDirName) continue
      const fileName = await findIgnoreCase(path.join(dataDir, localeDirName), 'realmlist.wtf')
      if (fileName) result.push(path.join(dataDir, localeDirName, fileName))
    }
    return result
  }

  /** Текущий хост из первого найденного realmlist.wtf (для отображения в UI). */
  async currentHost(clientPath: string): Promise<string | null> {
    const files = await this.listFiles(clientPath)
    if (files.length === 0) return null
    try {
      const buf = await fsp.readFile(files[0])
      return parseRealmlist(decode(buf).text).host
    } catch {
      return null
    }
  }

  /**
   * Прописывает host во все realmlist.wtf клиента.
   * Если файлов нет — создаёт Data/enUS/realmlist.wtf.
   */
  async apply(clientPath: string, host: string): Promise<RealmlistResult> {
    const results: RealmlistFileResult[] = []
    try {
      let files = await this.listFiles(clientPath)
      if (files.length === 0) {
        const dataDir = path.join(clientPath, 'Data')
        const localeDir = path.join(dataDir, 'enUS')
        await fsp.mkdir(localeDir, { recursive: true })
        files = [path.join(localeDir, 'realmlist.wtf')]
        logger.info(SCOPE, 'realmlist.wtf не найден — создаю Data/enUS/realmlist.wtf')
      }

      for (const file of files) {
        let text: string | null = null
        let encoding: Encoding = 'utf8'
        try {
          const buf = await fsp.readFile(file)
          const dec = decode(buf)
          text = dec.text
          encoding = dec.encoding
        } catch {
          text = null // файла нет — создадим
        }

        const before = parseRealmlist(text).host
        const next = buildRealmlist(text, host)
        const changed = before !== host.toLowerCase().replace(/[^a-z0-9.-]/g, '')

        if (changed) {
          // Бэкап исходного состояния (перезаписываем каждый раз — это «до правки»)
          if (text !== null) {
            await fsp.copyFile(file, file + '.bak').catch(() => undefined)
          }
          const tmp = file + '.tmp'
          await fsp.writeFile(tmp, encode(next, encoding))
          await fsp.rename(tmp, file)
        }

        results.push({ file, previousHost: before, newHost: host, changed })
        logger.info(SCOPE, `${file}: ${before ?? '∅'} → ${host}${changed ? '' : ' (без изменений)'}`)
      }
      return { ok: true, files: results, error: null }
    } catch (e) {
      logger.errorEx(SCOPE, 'Ошибка применения realmlist', e)
      return { ok: false, files: results, error: e instanceof Error ? e.message : String(e) }
    }
  }
}

export const realmlistService = new RealmlistService()
