/**
 * WowClientService: валидация каталога клиента WoW 3.3.5a и автопоиск установки.
 */
import fsp from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import type { ClientValidation } from '@shared/types'
import { logger } from '../logger/LoggerService'

const SCOPE = 'WowClient'

/** MPQ-архивы, обязательные для полноценного клиента 3.3.5a */
const REQUIRED_MPQ = ['common.MPQ', 'common-2.MPQ', 'expansion.MPQ', 'lichking.MPQ']
const LOCALES = ['enUS', 'enGB', 'ruRU', 'deDE', 'frFR', 'esES', 'esMX', 'ptBR', 'zhCN', 'zhTW', 'koKR']

async function readDirSafe(dir: string): Promise<string[]> {
  try {
    return await fsp.readdir(dir)
  } catch {
    return []
  }
}

async function findIgnoreCase(dir: string, wanted: string): Promise<string | null> {
  const entries = await readDirSafe(dir)
  return entries.find((e) => e.toLowerCase() === wanted.toLowerCase()) ?? null
}

export class WowClientService {
  /** Полная валидация каталога клиента. */
  async validate(clientPath: string | null): Promise<ClientValidation> {
    const result: ClientValidation = {
      ok: false,
      path: clientPath,
      wowExe: null,
      locale: null,
      build: null,
      writable: false,
      errors: [],
      warnings: []
    }
    if (!clientPath || clientPath.trim() === '') {
      result.errors.push({ code: 'NO_DIR', message: 'Путь к клиенту не задан', fatal: true })
      return result
    }

    // 1. Каталог существует?
    try {
      const st = await fsp.stat(clientPath)
      if (!st.isDirectory()) {
        result.errors.push({ code: 'NO_DIR', message: `Указанный путь не является каталогом: ${clientPath}`, fatal: true })
        return result
      }
    } catch {
      result.errors.push({ code: 'NO_DIR', message: `Каталог не существует: ${clientPath}`, fatal: true })
      return result
    }

    // 2. Wow.exe (регистронезависимо)
    const exeName = await findIgnoreCase(clientPath, 'Wow.exe')
    if (!exeName) {
      result.errors.push({ code: 'NO_EXE', message: 'В каталоге не найден Wow.exe', fatal: true })
    } else {
      result.wowExe = path.join(clientPath, exeName)
    }

    // 3. Каталог Data
    const dataName = await findIgnoreCase(clientPath, 'Data')
    if (!dataName) {
      result.errors.push({ code: 'NO_DATA', message: 'Не найден каталог Data', fatal: true })
    } else {
      const dataDir = path.join(clientPath, dataName)
      // 3.1 Локаль + realmlist
      let localeFound: string | null = null
      for (const locale of LOCALES) {
        const locDir = await findIgnoreCase(dataDir, locale)
        if (!locDir) continue
        const rl = await findIgnoreCase(path.join(dataDir, locDir), 'realmlist.wtf')
        if (rl) {
          localeFound = locale
          break
        }
      }
      result.locale = localeFound
      if (!localeFound) {
        result.warnings.push({ code: 'NO_REALMLIST', message: 'Не найден realmlist.wtf — он будет создан при применении настроек', fatal: false })
      }
      // 3.2 MPQ-архивы
      const dataEntries = await readDirSafe(dataDir)
      const lowerEntries = new Set(dataEntries.map((e) => e.toLowerCase()))
      for (const mpq of REQUIRED_MPQ) {
        if (!lowerEntries.has(mpq.toLowerCase())) {
          result.warnings.push({ code: 'MISSING_MPQ', message: `Отсутствует архив ${mpq}`, fatal: false })
        }
      }
    }

    // 4. Build-версия: у 3.3.5a нет .build.info, но если файл есть (клиент новее) — читаем
    try {
      const buildInfo = await fsp.readFile(path.join(clientPath, '.build.info'), 'utf8')
      const m = /"BuildNumber"\s*:\s*(\d+)/.exec(buildInfo) ?? /\b(\d{5})\b/.exec(buildInfo)
      if (m) result.build = parseInt(m[1], 10)
    } catch {
      result.build = null // для 3.3.5a это норма
    }

    // 5. Доступ на запись (нужно для правки realmlist.wtf)
    try {
      await fsp.access(clientPath, (await import('node:fs')).constants.W_OK)
      result.writable = true
    } catch {
      result.writable = false
      result.warnings.push({ code: 'NOT_WRITABLE', message: 'Каталог доступен только для чтения — запуск может потребовать прав администратора', fatal: false })
    }

    result.ok = result.errors.length === 0
    logger.info(
      SCOPE,
      `validate(${clientPath}) → ok=${result.ok}, exe=${result.wowExe ?? 'нет'}, locale=${result.locale ?? 'нет'}, errors=${result.errors.length}, warnings=${result.warnings.length}`
    )
    return result
  }

  /** Быстрая проверка «похоже ли на клиент» (для автопоиска). */
  async looksLikeClient(dir: string): Promise<boolean> {
    const exe = await findIgnoreCase(dir, 'Wow.exe')
    const data = await findIgnoreCase(dir, 'Data')
    return Boolean(exe && data)
  }

  /** Автопоиск клиента в типовых каталогах (Windows). */
  async autodetect(): Promise<string[]> {
    if (process.platform !== 'win32') return []
    const home = os.homedir()
    const drives = ['C:', 'D:', 'E:']
    const candidates: string[] = []
    for (const d of drives) {
      candidates.push(
        path.join(d + path.sep, 'World of Warcraft'),
        path.join(d + path.sep, 'Games', 'World of Warcraft'),
        path.join(d + path.sep, 'Games', 'WoW'),
        path.join(d + path.sep, 'WoW'),
        path.join(d + path.sep, 'Games', 'WOSERGAME'),
        path.join(d + path.sep, 'WOSERGAME')
      )
    }
    candidates.push(path.join(home, 'Games', 'World of Warcraft'), path.join(home, 'World of Warcraft'))

    const found: string[] = []
    for (const dir of candidates) {
      if (await this.looksLikeClient(dir)) found.push(dir)
    }
    // Второй уровень: сканируем C:\Games и D:\Games на глубину 1
    for (const d of drives.slice(0, 2)) {
      const roots = [path.join(d + path.sep, 'Games'), path.join(d + path.sep)]
      for (const root of roots) {
        const entries = await readDirSafe(root)
        for (const e of entries.slice(0, 60)) {
          const full = path.join(root, e)
          if (found.includes(full)) continue
          try {
            const st = await fsp.stat(full)
            if (st.isDirectory() && /wow|warcraft|wosergame/i.test(e) && (await this.looksLikeClient(full))) {
              found.push(full)
            }
          } catch {
            /* пропускаем недоступные */
          }
        }
      }
    }
    logger.info(SCOPE, `autodetect: найдено кандидатов: ${found.length}`)
    return found
  }
}

export const wowClientService = new WowClientService()
