/**
 * Схема manifest.json клиента (чистые функции — покрыто тестами).
 * Формат:
 * {
 *   "version": 3,
 *   "baseUrl": "https://cdn.wosergame.net/patch/",   // обязателен https
 *   "files": [ { "path": "Data/common.MPQ", "sha256": "<64 hex>", "size": 123456 } ]
 * }
 */
import type { ClientManifest, ManifestFileEntry } from '@shared/types'
import { isObject, sanitizeHttpsUrl } from '../../../shared/validate'
import { isValidSha256 } from '../../util/hash'

export interface ManifestParseResult {
  ok: boolean
  manifest: ClientManifest | null
  error: string | null
}

function normalizeRelPath(p: unknown): string | null {
  if (typeof p !== 'string' || p.length === 0 || p.length > 512) return null
  if (p.includes('\0')) return null
  const cleaned = p.replace(/\\/g, '/').replace(/^\/+/, '')
  if (!cleaned) return null
  if (/^[a-zA-Z]:/.test(cleaned)) return null
  const parts = cleaned.split('/')
  if (parts.some((seg) => seg === '..' || seg === '' )) return null
  return cleaned
}

/** Валидирует и нормализует manifest.json. Любая ошибка → ok:false. */
export function parseClientManifest(raw: unknown): ManifestParseResult {
  if (!isObject(raw)) return { ok: false, manifest: null, error: 'manifest: корень не является объектом' }
  const version = typeof raw.version === 'number' && Number.isFinite(raw.version) ? Math.floor(raw.version) : null
  if (version === null) return { ok: false, manifest: null, error: 'manifest: нет поля version' }

  const baseUrl = raw.baseUrl === null || raw.baseUrl === undefined ? null : sanitizeHttpsUrl(raw.baseUrl)
  if (raw.baseUrl && !baseUrl) return { ok: false, manifest: null, error: 'manifest: baseUrl должен быть HTTPS-URL' }

  if (!Array.isArray(raw.files)) return { ok: false, manifest: null, error: 'manifest: поле files не является массивом' }

  const files: ManifestFileEntry[] = []
  const seen = new Set<string>()
  for (const item of raw.files) {
    if (!isObject(item)) continue
    const rel = normalizeRelPath(item.path)
    const sha = item.sha256
    const size = typeof item.size === 'number' && Number.isFinite(item.size) && item.size >= 0 ? Math.floor(item.size) : null
    if (!rel || !isValidSha256(sha) || size === null) continue
    if (seen.has(rel.toLowerCase())) continue
    seen.add(rel.toLowerCase())
    files.push({ path: rel, sha256: sha, size })
  }
  if (files.length === 0) return { ok: false, manifest: null, error: 'manifest: нет валидных записей files' }

  return { ok: true, manifest: { version, baseUrl, files }, error: null }
}
