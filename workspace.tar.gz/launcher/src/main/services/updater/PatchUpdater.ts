/**
 * PatchUpdater: автообновление/починка клиента по manifest.json.
 * Алгоритм:
 *  1) скачать и валидировать manifest.json (только HTTPS);
 *  2) прогнать IntegrityService → список проблемных файлов;
 *  3) скачать каждый проблемный файл с докачкой (.wpart), сверить SHA256+size;
 *  4) атомарно положить на место (rename из .wpart делает downloadFile);
 *  5) повторная контрольная проверка → phase 'done'.
 * Любая небезопасная запись пути из манифеста отбрасывается (safeJoin).
 */
import path from 'node:path'
import type { ClientManifest, PatchState } from '@shared/types'
import { configService } from '../config/ConfigService'
import { logger } from '../logger/LoggerService'
import { eventBus } from '../EventBus'
import { httpsGetJson } from '../../util/http'
import { downloadFile, DownloadError } from '../../util/download'
import { parseClientManifest } from './manifestSchema'
import { integrityService } from '../integrity/IntegrityService'

const SCOPE = 'Patcher'
const MAX_RETRIES = 3
const CONCURRENCY = 2

const initialState = (): PatchState => ({
  phase: 'idle',
  progress: { filesDone: 0, filesTotal: 0, bytesDone: 0, bytesTotal: 0, currentFile: null },
  speedBps: 0,
  currentFile: null,
  error: null,
  repaired: 0
})

export class PatchUpdater {
  private state: PatchState = initialState()
  private abort: AbortController | null = null

  getState(): PatchState {
    return { ...this.state, progress: { ...this.state.progress } }
  }

  private setState(patch: Partial<PatchState>): void {
    this.state = { ...this.state, ...patch }
    eventBus.emitEvent('patch:state', this.getState())
  }

  isEnabled(): boolean {
    const s = configService.serverConfig
    return s.updates.enabled && Boolean(s.updates.manifestUrl) && configService.userConfig.updates.enabled
  }

  cancel(): void {
    if (this.state.phase === 'downloading' || this.state.phase === 'checking') {
      this.abort?.abort()
      integrityService.cancel()
      this.setState({ phase: 'idle', error: 'Отменено пользователем' })
      logger.warn(SCOPE, 'Обновление клиента отменено')
    }
  }

  async start(): Promise<PatchState> {
    if (!this.isEnabled()) {
      this.setState({ phase: 'disabled', error: 'Обновления клиента выключены в конфигурации сервера' })
      return this.getState()
    }
    const clientPath = configService.userConfig.clientPath
    if (!clientPath) {
      this.setState({ phase: 'error', error: 'Не задан путь к клиенту' })
      return this.getState()
    }
    if (this.state.phase === 'downloading' || this.state.phase === 'checking' || this.state.phase === 'manifest') {
      return this.getState()
    }

    this.abort = new AbortController()
    this.setState({ ...initialState(), phase: 'manifest' })
    logger.info(SCOPE, 'Старт обновления клиента')

    try {
      // 1) manifest.json
      const manifestUrl = configService.serverConfig.updates.manifestUrl!
      const raw = await httpsGetJson<unknown>(manifestUrl, { signal: this.abort.signal, maxBytes: 4 * 1024 * 1024 })
      const parsed = parseClientManifest(raw)
      if (!parsed.ok || !parsed.manifest) {
        throw new Error(parsed.error ?? 'Невалидный manifest.json')
      }
      const manifest: ClientManifest = parsed.manifest
      logger.info(SCOPE, `manifest v${manifest.version}: файлов ${manifest.files.length}, baseUrl=${manifest.baseUrl ?? 'относительные пути'}`)

      // 2) проверка целостности
      this.setState({ phase: 'checking' })
      const report = await integrityService.verify(clientPath, manifest)
      if (this.abort.signal.aborted) return this.getState()

      const byRel = new Map(manifest.files.map((f) => [f.path.toLowerCase(), f]))
      const toFix = report.issues
        .map((i) => byRel.get(i.path.toLowerCase()))
        .filter((f): f is NonNullable<typeof f> => Boolean(f))

      if (toFix.length === 0) {
        this.setState({ phase: 'done', repaired: 0, error: null })
        logger.info(SCOPE, 'Клиент актуален — загрузка не требуется')
        return this.getState()
      }

      // 3) загрузка проблемных файлов
      const bytesTotal = toFix.reduce((s, f) => s + f.size, 0)
      this.setState({
        phase: 'downloading',
        progress: { filesDone: 0, filesTotal: toFix.length, bytesDone: 0, bytesTotal, currentFile: null }
      })

      let filesDone = 0
      let bytesDone = 0
      let repaired = 0
      const queue = [...toFix]

      const worker = async (): Promise<void> => {
        while (queue.length > 0) {
          if (this.abort?.signal.aborted) return
          const entry = queue.shift()!
          const baseUrl = manifest.baseUrl
          if (!baseUrl) throw new Error('manifest.baseUrl не задан, скачивание невозможно')
          const url = baseUrl.endsWith('/') ? baseUrl + entry.path : baseUrl + '/' + entry.path
          let target: string
          try {
            target = integrityService.resolveInClient(clientPath, entry.path)
          } catch (e) {
            logger.warn(SCOPE, `Пропускаю небезопасный путь: ${entry.path}`)
            continue
          }
          this.setState({ currentFile: entry.path, progress: { ...this.getState().progress, currentFile: entry.path } })

          let ok = false
          for (let attempt = 1; attempt <= MAX_RETRIES && !ok; attempt++) {
            try {
              await downloadFile(url, target, {
                signal: this.abort!.signal,
                expectedSha256: entry.sha256,
                expectedSize: entry.size,
                timeoutMs: 120_000,
                onProgress: (bd, _bt, speed) => {
                  this.setState({ speedBps: speed, progress: { ...this.getState().progress, bytesDone: bytesDone + bd } })
                }
              })
              ok = true
              repaired++
            } catch (e) {
              if (e instanceof DownloadError && e.code === 'ABORTED') throw e
              logger.warn(SCOPE, `Попытка ${attempt}/${MAX_RETRIES} не удалась для ${entry.path}: ${(e as Error).message}`)
              if (attempt === MAX_RETRIES) throw new Error(`Не удалось скачать ${entry.path}: ${(e as Error).message}`)
            }
          }
          filesDone++
          bytesDone += entry.size
          this.setState({
            repaired,
            progress: { filesDone, filesTotal: toFix.length, bytesDone, bytesTotal, currentFile: entry.path }
          })
          logger.info(SCOPE, `Файл обновлён: ${entry.path} (${(entry.size / 1048576).toFixed(1)} МБ)`)
        }
      }

      await Promise.all(Array.from({ length: CONCURRENCY }, () => worker()))
      if (this.abort.signal.aborted) return this.getState()

      // 4) контрольная проверка
      this.setState({ phase: 'applying', currentFile: null })
      const recheck = await integrityService.verify(clientPath, manifest)
      const stillBroken = recheck.issues.filter((i) => i.kind !== 'unreadable').length
      if (stillBroken > 0) {
        throw new Error(`После обновления осталось проблемных файлов: ${stillBroken}`)
      }
      this.setState({ phase: 'done', repaired, error: null })
      logger.info(SCOPE, `Обновление клиента завершено: восстановлено файлов ${repaired}`)
      return this.getState()
    } catch (e) {
      const aborted = this.abort?.signal.aborted
      const message = e instanceof Error ? e.message : String(e)
      if (!aborted) {
        logger.errorEx(SCOPE, 'Ошибка обновления клиента', e)
        this.setState({ phase: 'error', error: message })
      }
      return this.getState()
    } finally {
      void path // path используется в displayPath ниже
    }
  }

  /** Человекочитаемый путь для UI. */
  display(p: string): string {
    return integrityService.displayPath(p)
  }
}

export const patchUpdater = new PatchUpdater()
