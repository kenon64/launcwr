/**
 * LauncherUpdater: самообновление лаунчера.
 * Схема: manifest.json лаунчера → { version, url, sha256, size, notes }
 *  - сравнение версий (semver);
 *  - загрузка установщика в %APPDATA%/WOSERGAME/updates/ с докачкой;
 *  - обязательная проверка SHA256 перед запуском установки;
 *  - тихая установка (NSIS /S) и выход лаунчера.
 * На не-Windows платформах — предлагаем скачать вручную (openExternal).
 */
import { spawn } from 'node:child_process'
import path from 'node:path'
import { app, shell } from 'electron'
import type { LauncherUpdateState } from '@shared/types'
import { configService } from '../config/ConfigService'
import { logger } from '../logger/LoggerService'
import { eventBus } from '../EventBus'
import { httpsGetJson } from '../../util/http'
import { downloadFile, DownloadError } from '../../util/download'
import { compareVersions, isValidVersion } from '../../util/semver'
import { sanitizeHttpsUrl, isObject } from '@shared/validate'
import { isValidSha256 } from '../../util/hash'

const SCOPE = 'LauncherUpdate'

interface UpdateManifest {
  version: string
  url: string
  sha256: string
  size: number
  notes: string | null
}

const initialState = (): LauncherUpdateState => ({
  phase: 'idle',
  latestVersion: null,
  progress: { bytesDone: 0, bytesTotal: 0 },
  error: null
})

export class LauncherUpdater {
  private state: LauncherUpdateState = initialState()
  private downloadedFile: string | null = null

  getState(): LauncherUpdateState {
    return { ...this.state, progress: { ...this.state.progress } }
  }

  private setState(patch: Partial<LauncherUpdateState>): void {
    this.state = { ...this.state, ...patch }
    eventBus.emitEvent('update:state', this.getState())
  }

  isEnabled(): boolean {
    const s = configService.serverConfig
    return s.launcherUpdate.enabled && Boolean(s.launcherUpdate.manifestUrl) && configService.userConfig.launcherUpdate.enabled
  }

  /** Парсинг и валидация манифеста обновления лаунчера. */
  private parseManifest(raw: unknown): UpdateManifest | null {
    if (!isObject(raw)) return null
    const version = raw.version
    const url = sanitizeHttpsUrl(raw.url)
    const sha = raw.sha256
    const size = typeof raw.size === 'number' && Number.isFinite(raw.size) ? Math.floor(raw.size) : null
    if (!isValidVersion(version) || !url || !isValidSha256(sha) || size === null || size <= 0) return null
    return { version, url, sha256: sha, size, notes: typeof raw.notes === 'string' ? raw.notes.slice(0, 2000) : null }
  }

  async check(): Promise<LauncherUpdateState> {
    if (!this.isEnabled()) {
      this.setState({ phase: 'disabled' })
      return this.getState()
    }
    this.setState({ phase: 'checking', error: null })
    try {
      const url = configService.serverConfig.launcherUpdate.manifestUrl!
      const manifest = this.parseManifest(await httpsGetJson<unknown>(url, { maxBytes: 256 * 1024, timeoutMs: 10_000 }))
      if (!manifest) throw new Error('Невалидный манифест обновления лаунчера')

      const current = app.getVersion()
      logger.info(SCOPE, `Проверка: текущая ${current}, доступна ${manifest.version}`)
      if (compareVersions(manifest.version, current) <= 0) {
        this.setState({ phase: 'uptodate', latestVersion: manifest.version })
        return this.getState()
      }
      this.setState({ phase: 'available', latestVersion: manifest.version })
      // Начинаем загрузку сразу (тихий апдейт)
      await this.download(manifest)
      return this.getState()
    } catch (e) {
      logger.errorEx(SCOPE, 'Ошибка проверки обновлений лаунчера', e)
      this.setState({ phase: 'error', error: e instanceof Error ? e.message : String(e) })
      return this.getState()
    }
  }

  private async download(manifest: UpdateManifest): Promise<void> {
    this.setState({ phase: 'downloading', progress: { bytesDone: 0, bytesTotal: manifest.size } })
    const dir = path.join(app.getPath('userData'), 'updates')
    const ext = process.platform === 'win32' ? 'exe' : process.platform === 'darwin' ? 'dmg' : 'AppImage'
    const target = path.join(dir, `launcher-update-${manifest.version}.${ext}`)
    try {
      await downloadFile(manifest.url, target, {
        expectedSha256: manifest.sha256,
        expectedSize: manifest.size,
        timeoutMs: 300_000,
        onProgress: (bd, bt) => this.setState({ progress: { bytesDone: bd, bytesTotal: bt || manifest.size } })
      })
      this.downloadedFile = target
      this.setState({ phase: 'ready', progress: { bytesDone: manifest.size, bytesTotal: manifest.size } })
      logger.info(SCOPE, `Обновление ${manifest.version} загружено и проверено: ${target}`)
    } catch (e) {
      if (e instanceof DownloadError && e.code === 'HASH_MISMATCH') {
        logger.error(SCOPE, 'SHA256 установщика не совпал — установка отменена (защита от подмены)')
      }
      throw e
    }
  }

  /**
   * Установка обновления.
   *  - NSIS-установщик (имя содержит "Setup") → тихий режим /S;
   *  - portable-сборка → безопасная подмена файла: текущий exe переименовается
   *    в ".old" (rename работающего exe в Windows разрешён), новый кладётся
   *    на его место, запускается, лаунчер выходит. ".old" удаляется при старте.
   */
  async install(): Promise<boolean> {
    if (this.state.phase !== 'ready' || !this.downloadedFile) {
      logger.warn(SCOPE, 'install() вызван без готового установщика')
      return false
    }
    const file = this.downloadedFile
    this.setState({ phase: 'installing' })
    logger.info(SCOPE, `Запуск установщика: ${file}`)
    try {
      if (process.platform === 'win32') {
        const isInstaller = /setup/i.test(path.basename(file))
        if (isInstaller) {
          const child = spawn(file, ['/S'], { detached: true, stdio: 'ignore' })
          child.unref()
        } else {
          // Portable-подмена: rename текущего exe → .old, копирование нового
          const current = process.execPath
          if (!current || !current.endsWith('.exe')) throw new Error('Не определён путь текущего exe')
          const old = current + '.old'
          const fsp = await import('node:fs/promises')
          await fsp.rm(old, { force: true }).catch(() => undefined)
          await fsp.rename(current, old)
          await fsp.copyFile(file, current)
          const child = spawn(current, [], { detached: true, stdio: 'ignore' })
          child.unref()
        }
        // Даём процессу отцепиться и выходим
        setTimeout(() => app.quit(), 800)
        return true
      }
      // Не-Windows: открываем страницу загрузки
      const url = configService.serverConfig.launcherUpdate.manifestUrl
      if (url) await shell.openExternal(configService.serverConfig.server.websiteUrl ?? url)
      app.quit()
      return true
    } catch (e) {
      logger.errorEx(SCOPE, 'Не удалось запустить установщик', e)
      this.setState({ phase: 'error', error: e instanceof Error ? e.message : String(e) })
      return false
    }
  }
}

export const launcherUpdater = new LauncherUpdater()
