/**
 * ConfigService: двухслойная конфигурация.
 *  1) Серверный слой  — resources/config/launcher.config.json (read-only, правит админ сервера).
 *  2) Пользовательский — %APPDATA%/WOSERGAME/launcher-config.json (настройки игрока).
 * Атомарная запись (tmp + rename), debounce, миграции по version, подписка на изменения.
 */
import { app } from 'electron'
import path from 'node:path'
import fs from 'node:fs'
import fsp from 'node:fs/promises'
import type { ConfigSnapshot, ServerConfig, UserConfig } from '@shared/types'
import { CONFIG_VERSION, defaultUserConfig, sanitizeServerConfig, sanitizeUserConfig, EMBEDDED_SERVER_CONFIG } from './schema'
import { logger } from '../logger/LoggerService'

const SCOPE = 'Config'
const USER_FILE = 'launcher-config.json'
const SAVE_DEBOUNCE_MS = 400

export class ConfigService {
  private server!: ServerConfig
  private user!: UserConfig
  private saveTimer: NodeJS.Timeout | null = null
  private listeners = new Set<(snap: ConfigSnapshot) => void>()

  get serverConfig(): ServerConfig {
    return this.server
  }

  get userConfig(): UserConfig {
    return this.user
  }

  userFile(): string {
    return path.join(app.getPath('userData'), USER_FILE)
  }

  /** Загрузка обоих слоёв. Вызывается до создания окна. */
  load(): void {
    this.server = this.loadServerConfig()
    this.user = this.loadUserConfig()
    logger.info(SCOPE, `Конфигурация загружена (server v${this.server.version}, user v${this.user.version})`)
  }

  private loadServerConfig(): ServerConfig {
    const candidates = [
      path.join(process.resourcesPath ?? '', 'config', 'launcher.config.json'),
      path.join(app.getAppPath(), 'config', 'launcher.config.json')
    ]
    for (const file of candidates) {
      try {
        if (file && fs.existsSync(file)) {
          const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
          const cfg = sanitizeServerConfig(raw)
          logger.info(SCOPE, `Серверный конфиг: ${file}`)
          return cfg
        }
      } catch (e) {
        logger.errorEx(SCOPE, `Не удалось прочитать серверный конфиг ${file}`, e)
      }
    }
    logger.warn(SCOPE, 'Серверный конфиг не найден — используется встроенный fallback')
    return structuredClone(EMBEDDED_SERVER_CONFIG)
  }

  private loadUserConfig(): UserConfig {
    const file = this.userFile()
    try {
      if (fs.existsSync(file)) {
        const raw = JSON.parse(fs.readFileSync(file, 'utf8'))
        const migrated = this.migrate(raw)
        const cfg = sanitizeUserConfig(migrated, this.server)
        // Если sanitize что-то починил — сохраняем нормализованную версию
        if (JSON.stringify(cfg) !== JSON.stringify(raw)) this.scheduleSave()
        return cfg
      }
    } catch (e) {
      logger.errorEx(SCOPE, 'Повреждён пользовательский конфиг — создаю заново (бэкап остаётся)', e)
      this.backupBroken(file)
    }
    const fresh = defaultUserConfig(this.server)
    this.user = fresh
    this.scheduleSave()
    return fresh
  }

  /** Простейшие миграции между версиями схемы. */
  private migrate(raw: Record<string, unknown>): Record<string, unknown> {
    const version = typeof raw.version === 'number' ? raw.version : 0
    if (version < CONFIG_VERSION) {
      logger.info(SCOPE, `Миграция пользовательского конфига: v${version} → v${CONFIG_VERSION}`)
      // Пример задела под будущие миграции:
      // if (version < 2) { ...преобразования полей... }
      raw.version = CONFIG_VERSION
    }
    return raw
  }

  private backupBroken(file: string): void {
    try {
      if (fs.existsSync(file)) fs.copyFileSync(file, file + '.broken-' + Date.now())
    } catch {
      /* некритично */
    }
  }

  /** Частичное обновление пользовательского конфига (deep-merge по секциям). */
  set(patch: Partial<UserConfig>): UserConfig {
    const next = sanitizeUserConfig({ ...this.user, ...patch }, this.server)
    // Секции мержим точечно, чтобы UI мог прислать только изменённую секцию
    if (patch.ui) next.ui = sanitizeUserConfig({ ...this.user, ui: { ...this.user.ui, ...patch.ui } }, this.server).ui
    if (patch.graphics)
      next.graphics = sanitizeUserConfig({ ...this.user, graphics: { ...this.user.graphics, ...patch.graphics } }, this.server).graphics
    if (patch.launch)
      next.launch = sanitizeUserConfig({ ...this.user, launch: { ...this.user.launch, ...patch.launch } }, this.server).launch
    if (patch.updates) next.updates = { ...this.user.updates, ...patch.updates }
    if (patch.launcherUpdate) next.launcherUpdate = { ...this.user.launcherUpdate, ...patch.launcherUpdate }
    this.user = next
    this.scheduleSave()
    this.emit()
    logger.debug(SCOPE, 'Пользовательский конфиг обновлён')
    return this.user
  }

  /** Сброс пользовательских настроек к дефолтам (путь к клиенту сохраняется). */
  reset(keepClientPath = true): UserConfig {
    const savedPath = this.user.clientPath
    this.user = defaultUserConfig(this.server)
    if (keepClientPath) this.user.clientPath = savedPath
    this.user.firstRun = false
    this.scheduleSave()
    this.emit()
    logger.info(SCOPE, 'Настройки сброшены к значениям по умолчанию')
    return this.user
  }

  private scheduleSave(): void {
    if (this.saveTimer) clearTimeout(this.saveTimer)
    this.saveTimer = setTimeout(() => {
      this.saveTimer = null
      this.saveSync()
    }, SAVE_DEBOUNCE_MS)
  }

  /** Атомарная запись: пишем .tmp, затем rename (не рвём файл при сбое питания). */
  saveSync(): void {
    const file = this.userFile()
    const tmp = file + '.tmp'
    try {
      fs.mkdirSync(path.dirname(file), { recursive: true })
      fs.writeFileSync(tmp, JSON.stringify(this.user, null, 2), 'utf8')
      fs.renameSync(tmp, file)
    } catch (e) {
      logger.errorEx(SCOPE, 'Не удалось сохранить конфигурацию', e)
    }
  }

  snapshot(): ConfigSnapshot {
    return {
      server: this.server,
      user: this.user,
      appVersion: app.getVersion(),
      paths: {
        userData: app.getPath('userData'),
        logs: logger.logsDir(),
        config: this.userFile()
      }
    }
  }

  onChange(fn: (snap: ConfigSnapshot) => void): () => void {
    this.listeners.add(fn)
    return () => this.listeners.delete(fn)
  }

  private emit(): void {
    const snap = this.snapshot()
    this.listeners.forEach((fn) => fn(snap))
  }

  flush(): void {
    if (this.saveTimer) {
      clearTimeout(this.saveTimer)
      this.saveTimer = null
    }
    this.saveSync()
  }

  async ensureUserDataDir(): Promise<void> {
    await fsp.mkdir(app.getPath('userData'), { recursive: true })
  }
}

export const configService = new ConfigService()
