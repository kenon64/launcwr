/**
 * Схема и sanitizer'ы конфигурации (чистые функции — покрыты unit-тестами).
 * Никаких импортов Electron: файл участвует в tests.
 */
import type { ServerConfig, UserConfig } from '@shared/types'
import {
  isObject,
  pickBool,
  pickEnum,
  pickNumber,
  pickString,
  pickStringArray,
  pickStringOrNull,
  sanitizeHttpsUrl,
  GRAPHICS_QUALITIES,
  LOCALES,
  PARTICLE_KINDS,
  THEMES
} from '../../../shared/validate'

export const CONFIG_VERSION = 1

/** Встроенный fallback на случай отсутствия resources/config/launcher.config.json */
export const EMBEDDED_SERVER_CONFIG: ServerConfig = {
  version: CONFIG_VERSION,
  server: {
    name: 'WOSERGAME.NET',
    tagline: 'Легендарный приватный сервер World of Warcraft 3.3.5a',
    clientVersion: '3.3.5a',
    expectedBuild: 12340,
    realmHost: 'play.wosergame.net',
    realmPort: 3724,
    websiteUrl: 'https://wosergame.net',
    supportUrl: 'https://vk.ru/wosergame',
    statusUrl: null
  },
  updates: { enabled: false, manifestUrl: null, channel: 'stable' },
  launcherUpdate: { enabled: false, manifestUrl: null },
  ui: { defaultLocale: 'ru', theme: 'dark' },
  graphics: { quality: 'auto', particles: 'embers' },
  launch: { extraArgs: [], autoFixRealmlist: true, elevateIfReadonly: true, minimizeOnGameStart: true }
}

/** Приводит произвольный JSON к валидному ServerConfig (все поля с fallback). */
export function sanitizeServerConfig(raw: unknown): ServerConfig {
  const d = EMBEDDED_SERVER_CONFIG
  if (!isObject(raw)) return structuredClone(d)
  const server = isObject(raw.server) ? raw.server : {}
  const updates = isObject(raw.updates) ? raw.updates : {}
  const launcherUpdate = isObject(raw.launcherUpdate) ? raw.launcherUpdate : {}
  const ui = isObject(raw.ui) ? raw.ui : {}
  const graphics = isObject(raw.graphics) ? raw.graphics : {}
  const launch = isObject(raw.launch) ? raw.launch : {}

  const realmHost = pickString(server.realmHost, d.server.realmHost)
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9.-]/g, '')

  return {
    version: pickNumber(raw.version, CONFIG_VERSION),
    server: {
      name: pickString(server.name, d.server.name).slice(0, 64),
      tagline: pickString(server.tagline, d.server.tagline).slice(0, 128),
      clientVersion: pickString(server.clientVersion, d.server.clientVersion).slice(0, 16),
      expectedBuild: Math.floor(pickNumber(server.expectedBuild, d.server.expectedBuild)),
      realmHost: realmHost || d.server.realmHost,
      realmPort: Math.min(65535, Math.max(1, Math.floor(pickNumber(server.realmPort, d.server.realmPort)))),
      websiteUrl: sanitizeHttpsUrl(server.websiteUrl),
      supportUrl: sanitizeHttpsUrl(server.supportUrl),
      statusUrl: sanitizeHttpsUrl(server.statusUrl)
    },
    updates: {
      enabled: pickBool(updates.enabled, d.updates.enabled),
      manifestUrl: sanitizeHttpsUrl(updates.manifestUrl),
      channel: pickString(updates.channel, 'stable').slice(0, 32)
    },
    launcherUpdate: {
      enabled: pickBool(launcherUpdate.enabled, d.launcherUpdate.enabled),
      manifestUrl: sanitizeHttpsUrl(launcherUpdate.manifestUrl)
    },
    ui: {
      defaultLocale: pickEnum(ui.defaultLocale, LOCALES, d.ui.defaultLocale),
      theme: pickEnum(ui.theme, THEMES, d.ui.theme)
    },
    graphics: {
      quality: pickEnum(graphics.quality, GRAPHICS_QUALITIES, d.graphics.quality),
      particles: pickEnum(graphics.particles, PARTICLE_KINDS, d.graphics.particles)
    },
    launch: {
      extraArgs: pickStringArray(launch.extraArgs, d.launch.extraArgs),
      autoFixRealmlist: pickBool(launch.autoFixRealmlist, d.launch.autoFixRealmlist),
      elevateIfReadonly: pickBool(launch.elevateIfReadonly, d.launch.elevateIfReadonly),
      minimizeOnGameStart: pickBool(launch.minimizeOnGameStart, d.launch.minimizeOnGameStart)
    }
  }
}

/** Дефолтная пользовательская конфигурация (создаётся при первом запуске). */
export function defaultUserConfig(server: ServerConfig): UserConfig {
  return {
    version: CONFIG_VERSION,
    clientPath: null,
    ui: { locale: server.ui.defaultLocale, theme: server.ui.theme },
    graphics: {
      quality: server.graphics.quality,
      particles: server.graphics.particles,
      parallax: true,
      fog: true,
      runes: true,
      fpsCap: 30
    },
    launch: {
      extraArgs: [...server.launch.extraArgs],
      autoFixRealmlist: server.launch.autoFixRealmlist,
      elevateIfReadonly: server.launch.elevateIfReadonly,
      minimizeOnGameStart: server.launch.minimizeOnGameStart,
      windowed: false,
      console: false
    },
    updates: { enabled: server.updates.enabled },
    launcherUpdate: { enabled: server.launcherUpdate.enabled },
    firstRun: true
  }
}

/** Приводит произвольный JSON к валидному UserConfig (миграции + fallback'и). */
export function sanitizeUserConfig(raw: unknown, server: ServerConfig): UserConfig {
  const d = defaultUserConfig(server)
  if (!isObject(raw)) return d
  const ui = isObject(raw.ui) ? raw.ui : {}
  const graphics = isObject(raw.graphics) ? raw.graphics : {}
  const launch = isObject(raw.launch) ? raw.launch : {}
  const updates = isObject(raw.updates) ? raw.updates : {}
  const launcherUpdate = isObject(raw.launcherUpdate) ? raw.launcherUpdate : {}

  const clientPath = pickStringOrNull(raw.clientPath)
  const fpsCapRaw = pickNumber(graphics.fpsCap, 30)

  return {
    version: CONFIG_VERSION,
    clientPath,
    ui: {
      locale: pickEnum(ui.locale, LOCALES, d.ui.locale),
      theme: pickEnum(ui.theme, THEMES, d.ui.theme)
    },
    graphics: {
      quality: pickEnum(graphics.quality, GRAPHICS_QUALITIES, d.graphics.quality),
      particles: pickEnum(graphics.particles, PARTICLE_KINDS, d.graphics.particles),
      parallax: pickBool(graphics.parallax, d.graphics.parallax),
      fog: pickBool(graphics.fog, d.graphics.fog),
      runes: pickBool(graphics.runes, d.graphics.runes),
      fpsCap: fpsCapRaw >= 60 ? 60 : 30
    },
    launch: {
      extraArgs: pickStringArray(launch.extraArgs, d.launch.extraArgs),
      autoFixRealmlist: pickBool(launch.autoFixRealmlist, d.launch.autoFixRealmlist),
      elevateIfReadonly: pickBool(launch.elevateIfReadonly, d.launch.elevateIfReadonly),
      minimizeOnGameStart: pickBool(launch.minimizeOnGameStart, d.launch.minimizeOnGameStart),
      windowed: pickBool(launch.windowed, d.launch.windowed),
      console: pickBool(launch.console, d.launch.console)
    },
    updates: { enabled: pickBool(updates.enabled, d.updates.enabled) },
    launcherUpdate: { enabled: pickBool(launcherUpdate.enabled, d.launcherUpdate.enabled) },
    firstRun: pickBool(raw.firstRun, d.firstRun)
  }
}
