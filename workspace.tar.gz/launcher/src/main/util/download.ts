/**
 * Потоковая загрузка файла на диск с докачкой (resume) и проверкой SHA256.
 * Временный файл: "<target>.wpart". После успешной проверки — атомарный rename.
 */
import { createWriteStream, createReadStream, existsSync, statSync } from 'node:fs'
import { rename, unlink, mkdir } from 'node:fs/promises'
import path from 'node:path'
import { createHash } from 'node:crypto'
import { net as electronNet } from 'electron'
import { HttpError } from './http'

export interface DownloadOptions {
  signal?: AbortSignal
  /** Ожидаемый sha256 (обязателен для боевых загрузок) */
  expectedSha256?: string
  expectedSize?: number
  onProgress?: (bytesDone: number, bytesTotal: number, speedBps: number) => void
  timeoutMs?: number
}

export interface DownloadResult {
  path: string
  bytes: number
  resumed: boolean
}

const CHUNK_REPORT_MS = 150

export class DownloadError extends Error {
  constructor(message: string, public readonly code = 'DOWNLOAD_ERROR') {
    super(message)
    this.name = 'DownloadError'
  }
}

function assertHttps(url: string): void {
  let u: URL
  try {
    u = new URL(url)
  } catch {
    throw new DownloadError(`Некорректный URL: ${url}`)
  }
  if (u.protocol !== 'https:') throw new DownloadError(`Разрешён только HTTPS: ${url}`)
  if (u.username || u.password) throw new DownloadError('URL не должен содержать учётные данные')
}

/**
 * Скачивает url в targetPath. Если рядом лежит "<target>.wpart" — докачивает.
 * После загрузки (если задан expectedSha256) сверяет хеш и только потом
 * переименовует в целевой файл.
 */
export async function downloadFile(url: string, targetPath: string, opts: DownloadOptions = {}): Promise<DownloadResult> {
  assertHttps(url)
  await mkdir(path.dirname(targetPath), { recursive: true })

  const partPath = targetPath + '.wpart'
  let resumeFrom = 0
  let resumed = false
  if (existsSync(partPath)) {
    const st = statSync(partPath)
    if (st.size > 0) {
      resumeFrom = st.size
      resumed = true
    } else {
      await unlink(partPath).catch(() => undefined)
    }
  }

  const headers: Record<string, string> = {
    'User-Agent': 'WOSERGAME-Launcher/1.0 (+https://wosergame.net)'
  }
  if (resumeFrom > 0) headers.Range = `bytes=${resumeFrom}-`

  return await new Promise<DownloadResult>((resolve, reject) => {
    const request = electronNet.request({ url, method: 'GET', headers })
    const stream = createWriteStream(partPath, { flags: resumeFrom > 0 ? 'a' : 'w' })
    let bytesDone = resumeFrom
    let bytesTotal = opts.expectedSize ?? 0
    let lastReport = 0
    let lastBytes = resumeFrom
    let lastTime = Date.now()
    let settled = false

    const timer = setTimeout(() => {
      cleanup(new DownloadError(`Таймаут загрузки (${opts.timeoutMs ?? 60_000} мс)`))
    }, opts.timeoutMs ?? 60_000)

    function cleanup(err?: Error): void {
      if (settled) return
      settled = true
      clearTimeout(timer)
      stream.destroy()
      try {
        request.abort()
      } catch {
        /* noop */
      }
      if (err) reject(err)
    }

    request.on('response', (response) => {
      const code = response.statusCode
      if (code !== 200 && code !== 206) {
        cleanup(new HttpError(`HTTP ${code} при загрузке ${url}`, code, url))
        return
      }
      if (code === 200 && resumeFrom > 0) {
        // Сервер не поддержал Range — начинаем заново
        bytesDone = 0
        resumed = false
        stream.close()
        stream.destroy()
      }
      const clen = Number(response.headers['content-length'])
      if (Number.isFinite(clen) && clen > 0) bytesTotal = code === 206 ? bytesDone + clen : clen

      const out =
        code === 206
          ? createWriteStream(partPath, { flags: 'a' })
          : createWriteStream(partPath, { flags: 'w' })

      response.on('data', (chunk: Buffer) => {
        bytesDone += chunk.length
        out.write(chunk)
        const now = Date.now()
        if (opts.onProgress && now - lastReport > CHUNK_REPORT_MS) {
          const dt = (now - lastTime) / 1000
          const speed = dt > 0 ? (bytesDone - lastBytes) / dt : 0
          lastReport = now
          lastBytes = bytesDone
          lastTime = now
          opts.onProgress(bytesDone, bytesTotal, Math.round(speed))
        }
      })
      response.on('end', () => {
        out.end(() => {
          clearTimeout(timer)
          if (opts.signal?.aborted) {
            cleanup(new DownloadError('Загрузка отменена', 'ABORTED'))
            return
          }
          verifyAndFinalize()
            .then(() => {
              settled = true
              resolve({ path: targetPath, bytes: bytesDone, resumed })
            })
            .catch((e) => cleanup(e as Error))
        })
      })
      response.on('error', (e) => cleanup(new DownloadError(`Ошибка чтения потока: ${e.message}`)))
    })
    request.on('error', (e) => cleanup(new DownloadError(`Сетевая ошибка: ${e.message}`)))

    if (opts.signal) {
      if (opts.signal.aborted) cleanup(new DownloadError('Загрузка отменена', 'ABORTED'))
      opts.signal.addEventListener('abort', () => cleanup(new DownloadError('Загрузка отменена', 'ABORTED')))
    }

    async function verifyAndFinalize(): Promise<void> {
      if (opts.expectedSha256) {
        const hash = createHash('sha256')
        await new Promise<void>((res, rej) => {
          const rs = createReadStream(partPath)
          rs.on('data', (c) => hash.update(c))
          rs.on('end', () => res())
          rs.on('error', rej)
        })
        const digest = hash.digest('hex')
        if (digest !== opts.expectedSha256) {
          await unlink(partPath).catch(() => undefined)
          throw new DownloadError(`Несовпадение SHA256: ожидался ${opts.expectedSha256}, получен ${digest}`, 'HASH_MISMATCH')
        }
      }
      if (typeof opts.expectedSize === 'number' && bytesDone !== opts.expectedSize) {
        await unlink(partPath).catch(() => undefined)
        throw new DownloadError(`Несовпадение размера: ожидалось ${opts.expectedSize}, получено ${bytesDone}`, 'SIZE_MISMATCH')
      }
      await rename(partPath, targetPath)
    }

    request.end()
  })
}
