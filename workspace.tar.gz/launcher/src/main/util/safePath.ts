/**
 * Безопасная работа с путями: защита от path traversal (требование ТЗ).
 * Все пути из внешних источников (manifest.json, конфиг) проходят через safeJoin.
 */
import path from 'node:path'

export class PathTraversalError extends Error {
  constructor(p: string) {
    super(`Обнаружена попытка path traversal: "${p}"`)
    this.name = 'PathTraversalError'
  }
}

/**
 * Объединяет базовый каталог с относительным путём и гарантирует,
 * что результат остаётся ВНУТРИ базового каталога.
 * Блокирует: "..", абсолютные пути, UNC-пути, диски Windows ("C:"), нуль-байты.
 */
export function safeJoin(baseDir: string, relative: string): string {
  if (typeof relative !== 'string' || relative.includes('\0')) {
    throw new PathTraversalError(relative)
  }
  // Нормализуем разделители к платформенным
  const cleaned = relative.replace(/\\/g, '/')
  if (!cleaned || cleaned.length === 0) throw new PathTraversalError(relative)
  // Fail-close: любые абсолютные пути из внешних источников отклоняем
  if (cleaned.startsWith('/')) throw new PathTraversalError(relative)

  // Явные признаки абсолютного/UNC/drive-пути
  if (/^[a-zA-Z]:/.test(cleaned) || cleaned.startsWith('//') || cleaned.startsWith('\\\\')) {
    throw new PathTraversalError(relative)
  }

  const base = path.resolve(baseDir)
  const target = path.resolve(base, cleaned)

  if (target !== base && !target.startsWith(base + path.sep)) {
    throw new PathTraversalError(relative)
  }
  return target
}

/** Проверяет, что путь target лежит внутри baseDir (для пользовательского выбора каталога). */
export function isInside(baseDir: string, target: string): boolean {
  const base = path.resolve(baseDir)
  const t = path.resolve(target)
  return t === base || t.startsWith(base + path.sep)
}

/** Нормализует пользовательский путь к каталогу (убирает хвостовые слеши, кавычки). */
export function normalizeDirInput(raw: string): string {
  let p = raw.trim().replace(/^["']|["']$/g, '')
  p = p.replace(/[\\/]+$/, '')
  return p
}
