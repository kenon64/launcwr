/**
 * Безопасный HTTP-клиент главного процесса.
 * Правила (ТЗ, раздел «Безопасность»):
 *  - только HTTPS (http:// отклоняется сразу);
 *  - таймауты на соединение и на простой;
 *  - лимит размера ответа;
 *  - без автоматических редиректов за пределы https.
 */
import { net as electronNet } from 'electron'

export class HttpError extends Error {
  constructor(
    message: string,
    public readonly statusCode?: number,
    public readonly url?: string
  ) {
    super(message)
    this.name = 'HttpError'
  }
}

export interface FetchOptions {
  /** Максимальный размер тела в байтах (по умолчанию 8 МБ) */
  maxBytes?: number
  /** Таймаут запроса, мс (по умолчанию 15000) */
  timeoutMs?: number
  /** Заголовок Range для докачки */
  rangeFrom?: number
  signal?: AbortSignal
  headers?: Record<string, string>
}

function assertHttps(url: string): URL {
  let parsed: URL
  try {
    parsed = new URL(url)
  } catch {
    throw new HttpError(`Некорректный URL: ${url}`, undefined, url)
  }
  if (parsed.protocol !== 'https:') {
    throw new HttpError(`Разрешён только HTTPS, получен: ${parsed.protocol}//`, undefined, url)
  }
  if (parsed.username || parsed.password) {
    throw new HttpError('URL не должен содержать учётные данные', undefined, url)
  }
  return parsed
}

/**
 * GET-запрос через net-модуль Electron (использует системный прокси и TLS).
 * Возвращает буфер тела.
 */
export async function httpsGetBuffer(url: string, opts: FetchOptions = {}): Promise<Buffer> {
  const parsed = assertHttps(url)
  const maxBytes = opts.maxBytes ?? 8 * 1024 * 1024
  const timeoutMs = opts.timeoutMs ?? 15_000

  return new Promise<Buffer>((resolve, reject) => {
    const headers: Record<string, string> = {
      'User-Agent': 'WOSERGAME-Launcher/1.0 (+https://wosergame.net)',
      Accept: '*/*',
      ...opts.headers
    }
    if (typeof opts.rangeFrom === 'number' && opts.rangeFrom > 0) {
      headers.Range = `bytes=${opts.rangeFrom}-`
    }

    const request = electronNet.request({ url: parsed.toString(), method: 'GET', headers })
    const chunks: Buffer[] = []
    let total = 0
    let settled = false

    const timer = setTimeout(() => {
      if (!settled) {
        settled = true
        request.abort()
        reject(new HttpError(`Таймаут запроса (${timeoutMs} мс): ${url}`, undefined, url))
      }
    }, timeoutMs)

    const fail = (err: Error): void => {
      if (settled) return
      settled = true
      clearTimeout(timer)
      reject(err)
    }

    request.on('response', (response) => {
      const code = response.statusCode
      // Поддержка частичного контента для докачки
      if (code !== 200 && code !== 206) {
        fail(new HttpError(`HTTP ${code} при запросе ${url}`, code, url))
        response.on('data', () => undefined) // дренируем
        return
      }
      response.on('data', (chunk: Buffer) => {
        total += chunk.length
        if (total > maxBytes) {
          fail(new HttpError(`Превышен лимит размера (${maxBytes} Б) для ${url}`, code, url))
          request.abort()
          return
        }
        chunks.push(chunk)
      })
      response.on('end', () => {
        if (settled) return
        settled = true
        clearTimeout(timer)
        resolve(Buffer.concat(chunks))
      })
      response.on('error', (e) => fail(new HttpError(`Ошибка чтения ответа: ${e.message}`, code, url)))
    })
    request.on('error', (e) => fail(new HttpError(`Сетевая ошибка: ${e.message}`, undefined, url)))
    request.on('abort', () => fail(new HttpError('Запрос прерван', undefined, url)))

    if (opts.signal) {
      if (opts.signal.aborted) fail(new HttpError('Запрос отменён', undefined, url))
      opts.signal.addEventListener('abort', () => {
        request.abort()
        fail(new HttpError('Запрос отменён', undefined, url))
      })
    }

    request.end()
  })
}

/** GET + parse JSON с валидацией типа. */
export async function httpsGetJson<T>(url: string, opts: FetchOptions = {}): Promise<T> {
  const buf = await httpsGetBuffer(url, opts)
  try {
    return JSON.parse(buf.toString('utf8')) as T
  } catch {
    throw new HttpError(`Ответ не является валидным JSON: ${url}`, undefined, url)
  }
}
