/**
 * Потоковое вычисление SHA256 (для проверки целостности и загрузок).
 */
import { createReadStream } from 'node:fs'
import { createHash, type Hash } from 'node:crypto'
import { stat } from 'node:fs/promises'

export interface HashProgress {
  bytesDone: number
  bytesTotal: number
}

/**
 * Считает SHA256 файла чанками по 4 МБ (не держим файл в памяти).
 * onProgress вызывается не чаще раза в 100 мс, чтобы не спамить IPC.
 */
export function hashFileSha256(
  filePath: string,
  onProgress?: (p: HashProgress) => void
): Promise<string> {
  return new Promise((resolve, reject) => {
    const hash: Hash = createHash('sha256')
    let bytesDone = 0
    let bytesTotal = 0
    let lastReport = 0

    stat(filePath)
      .then((s) => {
        bytesTotal = s.size
        const stream = createReadStream(filePath, { highWaterMark: 4 * 1024 * 1024 })
        stream.on('data', (chunk) => {
          hash.update(chunk)
          bytesDone += chunk.length
          const now = Date.now()
          if (onProgress && now - lastReport > 100) {
            lastReport = now
            onProgress({ bytesDone, bytesTotal })
          }
        })
        stream.on('end', () => resolve(hash.digest('hex')))
        stream.on('error', reject)
      })
      .catch(reject)
  })
}

/** SHA256 буфера (для небольших данных: manifest, realmlist). */
export function hashBufferSha256(buf: Buffer): string {
  return createHash('sha256').update(buf).digest('hex')
}

export function isValidSha256(hex: unknown): hex is string {
  return typeof hex === 'string' && /^[0-9a-f]{64}$/.test(hex)
}
