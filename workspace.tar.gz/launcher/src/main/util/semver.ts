/**
 * Сравнение semver-подобных версий ("1.2.3", "v1.2.3-beta").
 * Используется модулем самообновления лаунчера.
 */
export function parseVersion(v: string): number[] {
  const cleaned = v.trim().replace(/^v/i, '').split('-')[0]
  const parts = cleaned.split('.').map((p) => parseInt(p, 10))
  while (parts.length < 3) parts.push(0)
  return parts.slice(0, 3).map((n) => (Number.isFinite(n) ? n : 0))
}

/** 1 — a новее b, -1 — a старее, 0 — равны */
export function compareVersions(a: string, b: string): number {
  const pa = parseVersion(a)
  const pb = parseVersion(b)
  for (let i = 0; i < 3; i++) {
    if (pa[i] > pb[i]) return 1
    if (pa[i] < pb[i]) return -1
  }
  return 0
}

export function isValidVersion(v: unknown): v is string {
  return typeof v === 'string' && /^\d+\.\d+\.\d+([-.][0-9A-Za-z.-]+)?$/.test(v.trim())
}
