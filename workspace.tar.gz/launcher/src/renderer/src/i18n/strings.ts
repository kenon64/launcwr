/**
 * Локализация RU/EN. Словари + хук useI18n.
 */
import { createContext, useContext, useMemo } from 'react'
import type { Locale } from '@shared/types'

type Dict = Record<string, string>

const ru: Dict = {
  'tab.play': 'Игра',
  'tab.settings': 'Настройки',
  'tab.diagnostics': 'Диагностика',

  'titlebar.status.online': 'Сервер онлайн',
  'titlebar.status.offline': 'Сервер офлайн',
  'titlebar.status.unknown': 'Статус неизвестен',
  'titlebar.players': 'Игроков: {n}',
  'titlebar.latency': '{ms} мс',

  'play.hero.tagline': 'Твоя легенда начинается здесь',
  'play.client.title': 'Каталог клиента WoW 3.3.5a',
  'play.client.pick': 'Выбрать…',
  'play.client.autodetect': 'Найти автоматически',
  'play.client.placeholder': 'Каталог не выбран — укажите путь к клиенту',
  'play.client.ok': 'Клиент найден и готов к запуску',
  'play.client.bad': 'Клиент не прошёл проверку',
  'play.client.checking': 'Проверка клиента…',
  'play.realmlist.fix': 'Применить realmlist',
  'play.realmlist.ok': 'realmlist.wtf обновлён: {files} файл(ов)',
  'play.realmlist.fail': 'Ошибка применения realmlist: {err}',

  'play.launch': 'ИГРАТЬ',
  'play.launching': 'ЗАПУСК…',
  'play.running': 'ИГРА ЗАПУЩЕНА',
  'play.launch.error': 'Не удалось запустить: {err}',
  'play.launch.ok': 'Клиент запущен. Удачной охоты!',

  'patch.title': 'Обновление клиента',
  'patch.start': 'Проверить и обновить',
  'patch.cancel': 'Отменить',
  'patch.phase.manifest': 'Загрузка манифеста…',
  'patch.phase.checking': 'Проверка файлов…',
  'patch.phase.downloading': 'Загрузка файлов…',
  'patch.phase.applying': 'Контрольная проверка…',
  'patch.phase.done': 'Клиент актуален',
  'patch.phase.error': 'Ошибка обновления: {err}',
  'patch.phase.disabled': 'Обновления выключены',
  'patch.progress': '{done} / {total} файлов · {mb} МБ · {speed} МБ/с',

  'update.banner': 'Доступна новая версия лаунчера: {v}',
  'update.install': 'Установить и перезапустить',
  'update.downloading': 'Загрузка обновления… {mb} МБ',
  'update.ready': 'Обновление готово к установке',

  'settings.general': 'Общие',
  'settings.language': 'Язык интерфейса',
  'settings.theme': 'Тема оформления',
  'settings.theme.dark': 'Тёмная (Нордскол)',
  'settings.theme.light': 'Светлая (Летний Штормград)',

  'settings.graphics': 'Графика и анимации',
  'settings.graphics.quality': 'Качество эффектов',
  'settings.graphics.q.auto': 'Авто (адаптивно)',
  'settings.graphics.q.high': 'Высокое',
  'settings.graphics.q.medium': 'Среднее',
  'settings.graphics.q.low': 'Низкое (слабые ПК)',
  'settings.graphics.q.off': 'Выключено (макс. FPS игры)',
  'settings.graphics.particles': 'Частицы в атмосфере',
  'settings.graphics.p.embers': 'Искры',
  'settings.graphics.p.snow': 'Снег',
  'settings.graphics.p.ash': 'Пепел',
  'settings.graphics.p.mixed': 'Микс',
  'settings.graphics.fpscap': 'Предел FPS сцены',
  'settings.graphics.parallax': 'Параллакс (глубина за мышью)',
  'settings.graphics.fog': 'Движение тумана',
  'settings.graphics.runes': 'Мерцание рун',

  'settings.game': 'Параметры запуска игры',
  'settings.game.windowed': 'Оконный режим (-window)',
  'settings.game.console': 'Консоль (-console)',
  'settings.game.autofix': 'Автоматически править realmlist.wtf перед запуском',
  'settings.game.elevate': 'Запрашивать права администратора, если каталог read-only',
  'settings.game.minimize': 'Сворачивать лаунчер при старте игры',
  'settings.game.args': 'Дополнительные аргументы (через пробел)',

  'settings.updates': 'Обновления',
  'settings.updates.client': 'Автообновление клиента по manifest.json',
  'settings.updates.launcher': 'Автообновление лаунчера',
  'settings.updates.serveroff': 'Управление доступно только при включённых обновлениях на стороне сервера',

  'settings.about': 'О программе',
  'settings.about.version': 'Версия лаунчера',
  'settings.about.paths': 'Каталоги',
  'settings.about.openlogs': 'Открыть лог',
  'settings.about.openconfig': 'Открыть конфиг',
  'settings.about.reset': 'Сбросить настройки',
  'settings.about.reset.confirm': 'Сбросить все пользовательские настройки к значениям по умолчанию?',

  'diag.realm': 'Статус realm-сервера',
  'diag.realm.host': 'Адрес',
  'diag.realm.refresh': 'Обновить',
  'diag.realm.online': 'ОНЛАЙН',
  'diag.realm.offline': 'ОФЛАЙН',
  'diag.realm.unknown': 'НЕТ ДАННЫХ',

  'diag.integrity': 'Целостность файлов (SHA256)',
  'diag.integrity.start': 'Проверить файлы',
  'diag.integrity.cancel': 'Отменить',
  'diag.integrity.running': 'Проверка: {done}/{total} файлов',
  'diag.integrity.ok': 'Все файлы в порядке ({n} проверено, {mb} МБ)',
  'diag.integrity.bad': 'Проблемных файлов: {n}',
  'diag.integrity.none': 'Проверка ещё не выполнялась',
  'diag.integrity.issue.missing': 'отсутствует',
  'diag.integrity.issue.hash-mismatch': 'несовпадение хеша',
  'diag.integrity.issue.size-mismatch': 'несовпадение размера',
  'diag.integrity.issue.unreadable': 'нет доступа',

  'diag.logs': 'Журнал лаунчера',
  'diag.logs.clear': 'Очистить',
  'diag.logs.open': 'Открыть файл',
  'diag.logs.empty': 'Записей пока нет',

  'diag.system': 'Система',

  'toast.config.saved': 'Настройки сохранены',
  'toast.autodetect.none': 'Клиент WoW не найден в типовых каталогах',
  'toast.autodetect.found': 'Найден клиент: {path}',
  'toast.scene.downgrade': 'Производительность низкая — качество эффектов снижено',
  'toast.copied': 'Скопировано',

  'common.cancel': 'Отмена',
  'common.confirm': 'Подтвердить',
  'common.close': 'Закрыть',
  'common.on': 'Вкл',
  'common.off': 'Выкл',
  'common.error': 'Ошибка'
}

const en: Dict = {
  'tab.play': 'Play',
  'tab.settings': 'Settings',
  'tab.diagnostics': 'Diagnostics',

  'titlebar.status.online': 'Server online',
  'titlebar.status.offline': 'Server offline',
  'titlebar.status.unknown': 'Status unknown',
  'titlebar.players': 'Players: {n}',
  'titlebar.latency': '{ms} ms',

  'play.hero.tagline': 'Your legend begins here',
  'play.client.title': 'WoW 3.3.5a client folder',
  'play.client.pick': 'Browse…',
  'play.client.autodetect': 'Auto-detect',
  'play.client.placeholder': 'No folder selected — point the launcher to your client',
  'play.client.ok': 'Client found and ready',
  'play.client.bad': 'Client validation failed',
  'play.client.checking': 'Validating client…',
  'play.realmlist.fix': 'Apply realmlist',
  'play.realmlist.ok': 'realmlist.wtf updated: {files} file(s)',
  'play.realmlist.fail': 'realmlist error: {err}',

  'play.launch': 'PLAY',
  'play.launching': 'LAUNCHING…',
  'play.running': 'GAME IS RUNNING',
  'play.launch.error': 'Launch failed: {err}',
  'play.launch.ok': 'Client started. Good hunting!',

  'patch.title': 'Client update',
  'patch.start': 'Check & update',
  'patch.cancel': 'Cancel',
  'patch.phase.manifest': 'Fetching manifest…',
  'patch.phase.checking': 'Verifying files…',
  'patch.phase.downloading': 'Downloading files…',
  'patch.phase.applying': 'Final verification…',
  'patch.phase.done': 'Client is up to date',
  'patch.phase.error': 'Update error: {err}',
  'patch.phase.disabled': 'Updates are disabled',
  'patch.progress': '{done} / {total} files · {mb} MB · {speed} MB/s',

  'update.banner': 'New launcher version available: {v}',
  'update.install': 'Install & restart',
  'update.downloading': 'Downloading update… {mb} MB',
  'update.ready': 'Update is ready to install',

  'settings.general': 'General',
  'settings.language': 'Interface language',
  'settings.theme': 'Theme',
  'settings.theme.dark': 'Dark (Northrend)',
  'settings.theme.light': 'Light (Stormwind Summer)',

  'settings.graphics': 'Graphics & animations',
  'settings.graphics.quality': 'Effects quality',
  'settings.graphics.q.auto': 'Auto (adaptive)',
  'settings.graphics.q.high': 'High',
  'settings.graphics.q.medium': 'Medium',
  'settings.graphics.q.low': 'Low (weak PCs)',
  'settings.graphics.q.off': 'Off (max game FPS)',
  'settings.graphics.particles': 'Ambient particles',
  'settings.graphics.p.embers': 'Embers',
  'settings.graphics.p.snow': 'Snow',
  'settings.graphics.p.ash': 'Ash',
  'settings.graphics.p.mixed': 'Mixed',
  'settings.graphics.fpscap': 'Scene FPS cap',
  'settings.graphics.parallax': 'Parallax (mouse depth)',
  'settings.graphics.fog': 'Fog drift',
  'settings.graphics.runes': 'Rune shimmer',

  'settings.game': 'Launch options',
  'settings.game.windowed': 'Windowed mode (-window)',
  'settings.game.console': 'Console (-console)',
  'settings.game.autofix': 'Auto-fix realmlist.wtf before launch',
  'settings.game.elevate': 'Request admin rights if client folder is read-only',
  'settings.game.minimize': 'Minimize launcher when game starts',
  'settings.game.args': 'Extra arguments (space separated)',

  'settings.updates': 'Updates',
  'settings.updates.client': 'Client auto-update via manifest.json',
  'settings.updates.launcher': 'Launcher auto-update',
  'settings.updates.serveroff': 'Available only when updates are enabled server-side',

  'settings.about': 'About',
  'settings.about.version': 'Launcher version',
  'settings.about.paths': 'Folders',
  'settings.about.openlogs': 'Open log',
  'settings.about.openconfig': 'Open config',
  'settings.about.reset': 'Reset settings',
  'settings.about.reset.confirm': 'Reset all user settings to defaults?',

  'diag.realm': 'Realm server status',
  'diag.realm.host': 'Address',
  'diag.realm.refresh': 'Refresh',
  'diag.realm.online': 'ONLINE',
  'diag.realm.offline': 'OFFLINE',
  'diag.realm.unknown': 'NO DATA',

  'diag.integrity': 'File integrity (SHA256)',
  'diag.integrity.start': 'Verify files',
  'diag.integrity.cancel': 'Cancel',
  'diag.integrity.running': 'Verifying: {done}/{total} files',
  'diag.integrity.ok': 'All files are fine ({n} checked, {mb} MB)',
  'diag.integrity.bad': 'Broken files: {n}',
  'diag.integrity.none': 'Not verified yet',
  'diag.integrity.issue.missing': 'missing',
  'diag.integrity.issue.hash-mismatch': 'hash mismatch',
  'diag.integrity.issue.size-mismatch': 'size mismatch',
  'diag.integrity.issue.unreadable': 'no access',

  'diag.logs': 'Launcher log',
  'diag.logs.clear': 'Clear',
  'diag.logs.open': 'Open file',
  'diag.logs.empty': 'No entries yet',

  'diag.system': 'System',

  'toast.config.saved': 'Settings saved',
  'toast.autodetect.none': 'No WoW client found in common folders',
  'toast.autodetect.found': 'Client found: {path}',
  'toast.scene.downgrade': 'Low performance — effects quality reduced',
  'toast.copied': 'Copied',

  'common.cancel': 'Cancel',
  'common.confirm': 'Confirm',
  'common.close': 'Close',
  'common.on': 'On',
  'common.off': 'Off',
  'common.error': 'Error'
}

const DICTS: Record<Locale, Dict> = { ru, en }

export interface I18nApi {
  locale: Locale
  t: (key: string, vars?: Record<string, string | number>) => string
}

export const I18nContext = createContext<I18nApi>({ locale: 'ru', t: (k) => k })

export function useI18n(): I18nApi {
  return useContext(I18nContext)
}

export function makeI18n(locale: Locale): I18nApi {
  const dict = DICTS[locale] ?? ru
  return {
    locale,
    t: (key, vars) => {
      let s = dict[key] ?? ru[key] ?? key
      if (vars) {
        for (const [k, v] of Object.entries(vars)) s = s.replaceAll(`{${k}}`, String(v))
      }
      return s
    }
  }
}

export function useMemoI18n(locale: Locale): I18nApi {
  return useMemo(() => makeI18n(locale), [locale])
}
