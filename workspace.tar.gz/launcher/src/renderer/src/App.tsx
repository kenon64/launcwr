/**
 * Корневой компонент: провайдеры состояния, сцена-фон, titlebar,
 * навигация вкладками с плавными переходами, сплэш при загрузке.
 */
import { useEffect, useMemo, useState } from 'react'
import type { ReactElement } from 'react'
import { AppStateProvider, useAppState } from '@renderer/state/AppState'
import { ToastProvider } from '@renderer/components/ui/Toasts'
import { I18nContext, useMemoI18n } from '@renderer/i18n/strings'
import { ParallaxScene } from '@renderer/components/ParallaxScene'
import { TitleBar } from '@renderer/components/TitleBar'
import { PlayPanel } from '@renderer/components/PlayPanel'
import { SettingsPanel } from '@renderer/components/SettingsPanel'
import { DiagnosticsPanel } from '@renderer/components/DiagnosticsPanel'

type Tab = 'play' | 'settings' | 'diagnostics'

const TAB_ICONS: Record<Tab, ReactElement> = {
  play: (
    <svg viewBox="0 0 24 24">
      <path d="M8 5.5v13l11-6.5z" fill="currentColor" />
    </svg>
  ),
  settings: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
      <circle cx="12" cy="12" r="3.2" />
      <path d="M12 2.8v3M12 18.2v3M2.8 12h3M18.2 12h3M5.5 5.5l2.1 2.1M16.4 16.4l2.1 2.1M18.5 5.5l-2.1 2.1M7.6 16.4l-2.1 2.1" strokeLinecap="round" />
    </svg>
  ),
  diagnostics: (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7">
      <path d="M3 12h4l2.5-6 4 12L16 12h5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  )
}

function Shell(): ReactElement {
  const { state } = useAppState()
  const [tab, setTab] = useState<Tab>('play')
  const locale = state.snapshot?.user.ui.locale ?? 'ru'
  const theme = state.snapshot?.user.ui.theme ?? 'dark'
  const i18n = useMemoI18n(locale)
  const { t } = i18n

  // Тема применяется классом на <html>, чтобы токены покрывали всё окно
  useEffect(() => {
    document.documentElement.dataset.theme = theme
    document.documentElement.lang = locale
  }, [theme, locale])

  const tabs = useMemo(
    () =>
      [
        { id: 'play' as Tab, label: t('tab.play') },
        { id: 'settings' as Tab, label: t('tab.settings') },
        { id: 'diagnostics' as Tab, label: t('tab.diagnostics') }
      ],
    [t]
  )

  if (!state.ready || !state.snapshot) {
    return (
      <div className="splash">
        <div className="splash-logo">
          <svg viewBox="0 0 32 32" aria-hidden="true">
            <path d="M16 2 L28 7 v9 c0 8-5.4 12.6-12 14C9.4 28.6 4 24 4 16 V7 Z" fill="none" stroke="currentColor" strokeWidth="1.6" />
            <path d="M16 8 v16 M10.5 12 l11 8 M21.5 12 l-11 8" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
          </svg>
        </div>
        <div className="splash-bar">
          <span />
        </div>
        <p className="splash-text">WOSERGAME.NET</p>
      </div>
    )
  }

  return (
    <I18nContext.Provider value={i18n}>
      <div className="app-root">
        <ParallaxScene />
        <TitleBar serverName={state.snapshot.server.server.name} />
        <div className="app-body">
          <nav className="side-nav">
            {tabs.map((tb) => (
              <button key={tb.id} className={`nav-item ${tab === tb.id ? 'active' : ''}`} onClick={() => setTab(tb.id)} title={tb.label}>
                <span className="nav-icon">{TAB_ICONS[tb.id]}</span>
                <span className="nav-label">{tb.label}</span>
                <span className="nav-glow" />
              </button>
            ))}
          </nav>
          <main className="content">
            {/* key заставляет React перемонтировать панель → CSS-анимация входа */}
            <div className="tab-content" key={tab}>
              {tab === 'play' && <PlayPanel />}
              {tab === 'settings' && <SettingsPanel />}
              {tab === 'diagnostics' && <DiagnosticsPanel />}
            </div>
          </main>
        </div>
        <footer className="app-footer">
          <span className="footer-left">© {new Date().getFullYear()} WOSERGAME.NET · не аффилировано с Blizzard Entertainment</span>
          <span className="footer-right mono">v{state.snapshot.appVersion}</span>
        </footer>
      </div>
    </I18nContext.Provider>
  )
}

export function App(): ReactElement {
  return (
    <AppStateProvider>
      <ToastProvider>
        <Shell />
      </ToastProvider>
    </AppStateProvider>
  )
}
