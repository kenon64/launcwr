/**
 * Точка входа renderer'а (React).
 */
import React from 'react'
import { createRoot } from 'react-dom/client'
import { App } from './App'
import './styles/tokens.css'
import './styles/global.css'
import './styles/scene.css'
import './styles/components.css'

const container = document.getElementById('root')
if (!container) {
  throw new Error('Не найден контейнер #root')
}

createRoot(container).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
)
