/**
 * Вкладка «Настройки»: общие, графика/анимации, параметры запуска, обновления, о программе.
 * Все изменения сразу уходят в ConfigService (main) и персистятся атомарно.
 */
import { useState } from 'react'
import type { ReactElement } from 'react'
import { useAppState } from '@renderer/state/AppState'
import { useI18n } from '@renderer/i18n/strings'
import { GlowButton, Select, TextField, Toggle } from '@renderer/components/ui/Controls'
import { ConfirmModal, useToasts, type ConfirmRequest } from '@renderer/components/ui/Toasts'

export function SettingsPanel(): ReactElement {
  const { state, actions } = useAppState()
  const { t } = useI18n()
  const toasts = useToasts()
  const [confirm, setConfirm] = useState<ConfirmRequest | null>(null)
  const [args, setArgs] = useState<string | null>(null)

  const user = state.snapshot?.user
  const server = state.snapshot?.server
  if (!user || !server) return <div className="panel" />

  const set = (patch: Parameters<typeof actions.setConfig>[0]): void => {
    void actions.setConfig(patch).then(() => toasts.push('info', t('toast.config.saved')))
  }

  const serverUpdatesOff = !server.updates.enabled || !server.updates.manifestUrl
  const serverLauncherUpdateOff = !server.launcherUpdate.enabled || !server.launcherUpdate.manifestUrl

  return (
    <div className="panel settings-panel">
      <section className="card">
        <h2>{t('settings.general')}</h2>
        <Select
          label={t('settings.language')}
          value={user.ui.locale}
          onChange={(v) => set({ ui: { ...user.ui, locale: v as 'ru' | 'en' } })}
          options={[
            { value: 'ru', label: 'Русский' },
            { value: 'en', label: 'English' }
          ]}
        />
        <Select
          label={t('settings.theme')}
          value={user.ui.theme}
          onChange={(v) => set({ ui: { ...user.ui, theme: v as 'dark' | 'light' } })}
          options={[
            { value: 'dark', label: t('settings.theme.dark') },
            { value: 'light', label: t('settings.theme.light') }
          ]}
        />
      </section>

      <section className="card">
        <h2>{t('settings.graphics')}</h2>
        <Select
          label={t('settings.graphics.quality')}
          value={user.graphics.quality}
          onChange={(v) => set({ graphics: { ...user.graphics, quality: v as typeof user.graphics.quality } })}
          options={[
            { value: 'auto', label: t('settings.graphics.q.auto') },
            { value: 'high', label: t('settings.graphics.q.high') },
            { value: 'medium', label: t('settings.graphics.q.medium') },
            { value: 'low', label: t('settings.graphics.q.low') },
            { value: 'off', label: t('settings.graphics.q.off') }
          ]}
        />
        <Select
          label={t('settings.graphics.particles')}
          value={user.graphics.particles}
          onChange={(v) => set({ graphics: { ...user.graphics, particles: v as typeof user.graphics.particles } })}
          options={[
            { value: 'embers', label: t('settings.graphics.p.embers') },
            { value: 'snow', label: t('settings.graphics.p.snow') },
            { value: 'ash', label: t('settings.graphics.p.ash') },
            { value: 'mixed', label: t('settings.graphics.p.mixed') }
          ]}
        />
        <Select
          label={t('settings.graphics.fpscap')}
          value={String(user.graphics.fpsCap)}
          onChange={(v) => set({ graphics: { ...user.graphics, fpsCap: v === '60' ? 60 : 30 } })}
          options={[
            { value: '30', label: '30 FPS' },
            { value: '60', label: '60 FPS' }
          ]}
        />
        <Toggle label={t('settings.graphics.parallax')} checked={user.graphics.parallax} onChange={(v) => set({ graphics: { ...user.graphics, parallax: v } })} />
        <Toggle label={t('settings.graphics.fog')} checked={user.graphics.fog} onChange={(v) => set({ graphics: { ...user.graphics, fog: v } })} />
        <Toggle label={t('settings.graphics.runes')} checked={user.graphics.runes} onChange={(v) => set({ graphics: { ...user.graphics, runes: v } })} />
      </section>

      <section className="card">
        <h2>{t('settings.game')}</h2>
        <div className="client-row">
          <input className="text-input mono grow" readOnly value={user.clientPath ?? ''} placeholder={t('play.client.placeholder')} />
          <GlowButton variant="ghost" onClick={() => void window.launcherAPI.client.pick()}>
            {t('play.client.pick')}
          </GlowButton>
        </div>
        <Toggle label={t('settings.game.windowed')} checked={user.launch.windowed} onChange={(v) => set({ launch: { ...user.launch, windowed: v } })} />
        <Toggle label={t('settings.game.console')} checked={user.launch.console} onChange={(v) => set({ launch: { ...user.launch, console: v } })} />
        <Toggle label={t('settings.game.autofix')} checked={user.launch.autoFixRealmlist} onChange={(v) => set({ launch: { ...user.launch, autoFixRealmlist: v } })} />
        <Toggle label={t('settings.game.elevate')} checked={user.launch.elevateIfReadonly} onChange={(v) => set({ launch: { ...user.launch, elevateIfReadonly: v } })} />
        <Toggle label={t('settings.game.minimize')} checked={user.launch.minimizeOnGameStart} onChange={(v) => set({ launch: { ...user.launch, minimizeOnGameStart: v } })} />
        <TextField
          label={t('settings.game.args')}
          mono
          value={args ?? user.launch.extraArgs.join(' ')}
          placeholder="-opengl"
          onChange={(v) => {
            setArgs(v)
          }}
        />
        <div className="row-actions">
          <GlowButton
            variant="ghost"
            onClick={() => {
              const list = (args ?? '').split(/\s+/).filter(Boolean)
              set({ launch: { ...user.launch, extraArgs: list } })
              setArgs(null)
            }}
          >
            {t('common.confirm')}
          </GlowButton>
        </div>
      </section>

      <section className="card">
        <h2>{t('settings.updates')}</h2>
        <Toggle
          label={t('settings.updates.client')}
          checked={user.updates.enabled}
          onChange={(v) => set({ updates: { enabled: v } })}
          hint={serverUpdatesOff ? t('settings.updates.serveroff') : undefined}
        />
        {serverUpdatesOff && <p className="muted-note">{t('settings.updates.serveroff')}</p>}
        <Toggle
          label={t('settings.updates.launcher')}
          checked={user.launcherUpdate.enabled}
          onChange={(v) => set({ launcherUpdate: { enabled: v } })}
          hint={serverLauncherUpdateOff ? t('settings.updates.serveroff') : undefined}
        />
        {serverLauncherUpdateOff && <p className="muted-note">{t('settings.updates.serveroff')}</p>}
      </section>

      <section className="card">
        <h2>{t('settings.about')}</h2>
        <p className="about-line">
          {t('settings.about.version')}: <b>{state.snapshot?.appVersion ?? '—'}</b>
        </p>
        <p className="about-line muted">
          {t('settings.about.paths')}: {state.snapshot?.paths.userData ?? '—'}
        </p>
        <div className="row-actions">
          <GlowButton variant="ghost" onClick={() => void window.launcherAPI.logs.openFile()}>
            {t('settings.about.openlogs')}
          </GlowButton>
          <GlowButton variant="ghost" onClick={() => void window.launcherAPI.app.openPath(state.snapshot?.paths.config ?? '')}>
            {t('settings.about.openconfig')}
          </GlowButton>
          <GlowButton
            variant="danger"
            onClick={() =>
              setConfirm({
                title: t('settings.about.reset'),
                message: t('settings.about.reset.confirm'),
                confirmLabel: t('common.confirm'),
                cancelLabel: t('common.cancel'),
                onConfirm: () => void actions.resetConfig()
              })
            }
          >
            {t('settings.about.reset')}
          </GlowButton>
        </div>
      </section>

      <ConfirmModal req={confirm} onClose={() => setConfirm(null)} />
    </div>
  )
}
