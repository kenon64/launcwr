/**
 * Кастомный titlebar: drag-region + логотип + индикатор статуса сервера + кнопки окна.
 */
import type { ReactElement } from 'react'
import { useAppState } from '@renderer/state/AppState'
import { useI18n } from '@renderer/i18n/strings'

function StatusPill(): ReactElement {
  const { state, actions } = useAppState()
  const { t } = useI18n()
  const realm = state.realm
  const cls = realm?.state ?? 'unknown'
  const label =
    realm?.state === 'online'
      ? t('titlebar.status.online')
      : realm?.state === 'offline'
        ? t('titlebar.status.offline')
        : t('titlebar.status.unknown')
  const meta: string[] = []
  if (realm?.latencyMs != null) meta.push(t('titlebar.latency', { ms: realm.latencyMs }))
  if (realm?.players != null) meta.push(t('titlebar.players', { n: realm.players }))

  return (
    <button
      className={`status-pill st-${cls}`}
      onClick={() => void actions.refreshRealm()}
      title={`${realm?.host ?? ''}:${realm?.port ?? ''} — нажмите для проверки`}
    >
      <span className="status-dot" />
      <span className="status-label">{label}</span>
      {meta.length > 0 && <span className="status-meta">{meta.join(' · ')}</span>}
    </button>
  )
}

export function TitleBar({ serverName }: { serverName: string }): ReactElement {
  const { state } = useAppState()
  return (
    <header className="titlebar">
      <div className="titlebar-left">
        <svg className="logo" viewBox="0 0 32 32" aria-hidden="true">
          <path
            d="M16 2 L28 7 v9 c0 8-5.4 12.6-12 14C9.4 28.6 4 24 4 16 V7 Z"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinejoin="round"
          />
          <path d="M16 8 v16 M10.5 12 l11 8 M21.5 12 l-11 8" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
        </svg>
        <span className="titlebar-name">{serverName}</span>
        <span className="titlebar-tag">3.3.5a</span>
      </div>
      <div className="titlebar-right">
        <StatusPill />
        <div className="win-buttons">
          <button className="win-btn" onClick={() => window.launcherAPI.app.minimize()} title="Свернуть">
            <svg viewBox="0 0 10 10">
              <path d="M1 5h8" stroke="currentColor" strokeWidth="1.2" />
            </svg>
          </button>
          <button className="win-btn" onClick={() => window.launcherAPI.app.toggleMaximize()} title="Развернуть">
            {state.maximized ? (
              <svg viewBox="0 0 10 10">
                <path d="M2 3.5h4.5V8H2z M3.5 3.5V2H8v4.5H6.5" fill="none" stroke="currentColor" strokeWidth="1.1" />
              </svg>
            ) : (
              <svg viewBox="0 0 10 10">
                <rect x="2" y="2" width="6" height="6" fill="none" stroke="currentColor" strokeWidth="1.2" />
              </svg>
            )}
          </button>
          <button className="win-btn win-close" onClick={() => window.launcherAPI.app.close()} title="Закрыть">
            <svg viewBox="0 0 10 10">
              <path d="M2 2l6 6M8 2l-6 6" stroke="currentColor" strokeWidth="1.2" />
            </svg>
          </button>
        </div>
      </div>
    </header>
  )
}
