/**
 * ParallaxScene — React-обёртка движка сцены.
 * Слои (сверху вниз по глубине):
 *   sky (CSS-градиент) → far.png (0.16) → туман-задний (0.30) → mid.png (0.46)
 *   → туман-передний (0.58) → руны (0.68, CSS-мерцание) → частицы (0.82)
 *   → near.png (1.0) → виньетка.
 */
import { useEffect, useRef } from 'react'
import type { ReactElement } from 'react'
import { SceneController } from '@renderer/scene/SceneController'
import { useAppState } from '@renderer/state/AppState'
import { useToasts } from '@renderer/components/ui/Toasts'
import { useI18n } from '@renderer/i18n/strings'
import farUrl from '@renderer/assets/far.jpg'
import midUrl from '@renderer/assets/mid.jpg'
import nearUrl from '@renderer/assets/near.jpg'

/** Декоративные руны (SVG, мерцание чисто на CSS — ноль нагрузки на JS). */
function Runes(): ReactElement {
  return (
    <div className="runes" data-depth="0.68" aria-hidden="true">
      {[
        { left: '12%', top: '58%', delay: '0s', size: 46 },
        { left: '26%', top: '72%', delay: '1.4s', size: 30 },
        { left: '68%', top: '64%', delay: '2.6s', size: 38 },
        { left: '84%', top: '52%', delay: '0.8s', size: 26 },
        { left: '48%', top: '80%', delay: '3.4s', size: 34 }
      ].map((r, i) => (
        <svg
          key={i}
          className="rune"
          style={{ left: r.left, top: r.top, animationDelay: r.delay, width: r.size, height: r.size }}
          viewBox="0 0 40 40"
        >
          <circle cx="20" cy="20" r="17" fill="none" stroke="currentColor" strokeWidth="1.4" strokeDasharray="6 4" />
          <path d="M20 7 L20 33 M12 14 L28 26 M28 14 L12 26" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
        </svg>
      ))}
    </div>
  )
}

export function ParallaxScene(): ReactElement {
  const rootRef = useRef<HTMLDivElement>(null)
  const controllerRef = useRef<SceneController | null>(null)
  const { state } = useAppState()
  const toasts = useToasts()
  const { t } = useI18n()

  const user = state.snapshot?.user
  const quality = user?.graphics.quality ?? 'auto'
  const particles = user?.graphics.particles ?? 'embers'
  const parallax = user?.graphics.parallax ?? true
  const fog = user?.graphics.fog ?? true
  const runesOn = user?.graphics.runes ?? true
  const fpsCap = user?.graphics.fpsCap ?? 30
  const paused = !state.windowVisible

  // Создание контроллера один раз
  useEffect(() => {
    const root = rootRef.current
    if (!root) return
    const controller = new SceneController(root, {
      quality: 'auto',
      particles: 'embers',
      parallax: true,
      fog: true,
      fpsCap: 30,
      paused: false
    })
    controller.onDowngrade = () => toasts.push('warn', t('toast.scene.downgrade'))
    controllerRef.current = controller
    return () => {
      controller.destroy()
      controllerRef.current = null
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Синхронизация опций из конфига
  useEffect(() => {
    controllerRef.current?.setOptions({ quality, particles, parallax, fog, fpsCap, paused })
  }, [quality, particles, parallax, fog, fpsCap, paused])

  return (
    <div className={`scene ${runesOn ? '' : 'no-runes'}`} ref={rootRef} aria-hidden="true">
      <div className="scene-sky" />
      <div className="scene-layer layer-far" data-depth="0.16" style={{ backgroundImage: `url(${farUrl})` }} />
      <canvas className="scene-layer scene-canvas" data-depth="0.3" data-fog="back" />
      <div className="scene-layer layer-mid" data-depth="0.46" style={{ backgroundImage: `url(${midUrl})` }} />
      <canvas className="scene-layer scene-canvas" data-depth="0.58" data-fog="front" />
      <Runes />
      <canvas className="scene-layer scene-canvas" data-depth="0.82" data-particles="true" />
      <div className="scene-layer layer-near" data-depth="1" style={{ backgroundImage: `url(${nearUrl})` }} />
      <div className="scene-vignette" />
    </div>
  )
}
