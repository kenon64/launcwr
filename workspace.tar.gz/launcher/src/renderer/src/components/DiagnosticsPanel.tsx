/**
 * Вкладка «Диагностика»: статус realm, проверка целостности (SHA256),
 * журнал лаунчера в реальном времени, сведения о системе.
 */
import { useState } from 'react'
import type { ReactElement } from 'react'
import type { LogLevel } from '@shared/types'
import { useAppState } from '@renderer/state/AppState'
import { useI18n } from '@renderer/i18n/strings'
import { GlowButton, Select } from '@renderer/components/ui/Controls'
import { ProgressBar } from '@renderer/components/ui/ProgressBar'

function formatMb(bytes: number): string {
  return (bytes / 1048576).toFixed(1)
}

function tsFmt(ts: number): string {
  const d = new Date(ts)
  const p = (n: number): string => String(n).padStart(2, '0')
  return `${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`
}

export function DiagnosticsPanel(): ReactElement {
  const { state, actions } = useAppState()
  const { t } = useI18n()
  const [levelFilter, setLevelFilter] = useState<'all' | LogLevel>('all')

  const realm = state.realm
  const progress = state.integrityProgress
  const report = state.integrityReport
  const logs = levelFilter === 'all' ? state.logs : state.logs.filter((l) => l.level === levelFilter)

  const integrityRunning = progress !== null && progress.filesTotal > 0 && progress.filesDone < progress.filesTotal

  return (
    <div className="panel diagnostics-panel">
      <section className="card">
        <div className="card-head">
          <h2>{t('diag.realm')}</h2>
          <GlowButton variant="ghost" onClick={() => void actions.refreshRealm()}>
            {t('diag.realm.refresh')}
          </GlowButton>
        </div>
        <div className={`realm-state st-${realm?.state ?? 'unknown'}`}>
          <span className="status-dot big" />
          <span className="realm-state-text">
            {realm?.state === 'online' ? t('diag.realm.online') : realm?.state === 'offline' ? t('diag.realm.offline') : t('diag.realm.unknown')}
          </span>
        </div>
        <p className="muted">
          {t('diag.realm.host')}: <b className="mono">{realm ? `${realm.host}:${realm.port}` : '—'}</b>
          {realm?.latencyMs != null && <> · {t('titlebar.latency', { ms: realm.latencyMs })}</>}
          {realm?.players != null && <> · {t('titlebar.players', { n: realm.players })}</>}
        </p>
      </section>

      <section className="card">
        <div className="card-head">
          <h2>{t('diag.integrity')}</h2>
          <div className="card-head-actions">
            {integrityRunning ? (
              <GlowButton variant="danger" onClick={() => window.launcherAPI.integrity.cancel()}>
                {t('diag.integrity.cancel')}
              </GlowButton>
            ) : (
              <GlowButton
                variant="teal"
                disabled={!state.snapshot?.user.clientPath}
                onClick={() => void window.launcherAPI.integrity.start().catch(() => undefined)}
              >
                {t('diag.integrity.start')}
              </GlowButton>
            )}
          </div>
        </div>
        {progress && integrityRunning && (
          <ProgressBar
            value={progress.bytesTotal ? progress.bytesDone / progress.bytesTotal : 0}
            active
            label={t('diag.integrity.running', { done: progress.filesDone, total: progress.filesTotal })}
          />
        )}
        {!report && !progress && <p className="muted">{t('diag.integrity.none')}</p>}
        {report && (
          <>
            <p className={report.issues.length === 0 ? 'ok-note' : 'bad-note'}>
              {report.issues.length === 0
                ? t('diag.integrity.ok', { n: report.total, mb: formatMb(report.bytesScanned) })
                : t('diag.integrity.bad', { n: report.issues.length })}
            </p>
            {report.issues.length > 0 && (
              <ul className="issues scroll-box">
                {report.issues.slice(0, 60).map((i, idx) => (
                  <li key={idx} className="issue-warn mono">
                    {i.path} — {t(`diag.integrity.issue.${i.kind}`)}
                  </li>
                ))}
              </ul>
            )}
          </>
        )}
      </section>

      <section className="card">
        <div className="card-head">
          <h2>{t('diag.logs')}</h2>
          <div className="card-head-actions">
            <Select
              label=""
              value={levelFilter}
              onChange={(v) => setLevelFilter(v as 'all' | LogLevel)}
              options={[
                { value: 'all', label: 'ALL' },
                { value: 'error', label: 'ERROR' },
                { value: 'warn', label: 'WARN' },
                { value: 'info', label: 'INFO' },
                { value: 'debug', label: 'DEBUG' }
              ]}
            />
            <GlowButton variant="ghost" onClick={() => void window.launcherAPI.logs.clear()}>
              {t('diag.logs.clear')}
            </GlowButton>
            <GlowButton variant="ghost" onClick={() => void window.launcherAPI.logs.openFile()}>
              {t('diag.logs.open')}
            </GlowButton>
          </div>
        </div>
        <div className="logs scroll-box mono">
          {logs.length === 0 && <p className="muted">{t('diag.logs.empty')}</p>}
          {logs.slice(-200).map((l, i) => (
            <div key={i} className={`log-line log-${l.level}`}>
              <span className="log-ts">{tsFmt(l.ts)}</span>
              <span className="log-level">{l.level.toUpperCase().padEnd(5, ' ')}</span>
              <span className="log-scope">[{l.scope}]</span>
              <span className="log-msg">{l.message}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="card">
        <h2>{t('diag.system')}</h2>
        <p className="muted mono">
          launcher {state.snapshot?.appVersion ?? '—'} · electron {state.appInfo?.electron ?? '—'} · chrome {state.appInfo?.chrome ?? '—'} · node{' '}
          {state.appInfo?.node ?? '—'} · {state.appInfo?.platform ?? '—'}/{state.appInfo?.arch ?? '—'}
        </p>
      </section>
    </div>
  )
}
