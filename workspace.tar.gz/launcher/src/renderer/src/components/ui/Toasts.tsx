/**
 * Тосты (всплывающие уведомления) + модальное подтверждение.
 */
import { createContext, useCallback, useContext, useMemo, useRef, useState } from 'react'
import type { ReactElement, ReactNode } from 'react'

export type ToastKind = 'info' | 'success' | 'error' | 'warn'

export interface Toast {
  id: number
  kind: ToastKind
  text: string
}

interface ToastApi {
  push: (kind: ToastKind, text: string) => void
}

const ToastContext = createContext<ToastApi>({ push: () => undefined })

export function useToasts(): ToastApi {
  return useContext(ToastContext)
}

export function ToastProvider({ children }: { children: ReactNode }): ReactElement {
  const [toasts, setToasts] = useState<Toast[]>([])
  const idRef = useRef(1)

  const push = useCallback((kind: ToastKind, text: string) => {
    const id = idRef.current++
    setToasts((list) => [...list.slice(-3), { id, kind, text }])
    setTimeout(() => setToasts((list) => list.filter((t) => t.id !== id)), 5200)
  }, [])

  const api = useMemo(() => ({ push }), [push])

  return (
    <ToastContext.Provider value={api}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {toasts.map((t) => (
          <div key={t.id} className={`toast toast-${t.kind}`}>
            <span className="toast-dot" />
            <span className="toast-text">{t.text}</span>
          </div>
        ))}
      </div>
    </ToastContext.Provider>
  )
}

// ─── Модальное окно подтверждения ───────────────────────────────────────────

export interface ConfirmRequest {
  title: string
  message: string
  confirmLabel: string
  cancelLabel: string
  onConfirm: () => void
}

export function ConfirmModal({ req, onClose }: { req: ConfirmRequest | null; onClose: () => void }): ReactElement | null {
  if (!req) return null
  return (
    <div className="modal-backdrop" onMouseDown={onClose}>
      <div className="modal" onMouseDown={(e) => e.stopPropagation()}>
        <h3>{req.title}</h3>
        <p>{req.message}</p>
        <div className="modal-actions">
          <button className="btn btn-ghost" onClick={onClose}>
            {req.cancelLabel}
          </button>
          <button
            className="btn btn-gold"
            onClick={() => {
              req.onConfirm()
              onClose()
            }}
          >
            {req.confirmLabel}
          </button>
        </div>
      </div>
    </div>
  )
}
