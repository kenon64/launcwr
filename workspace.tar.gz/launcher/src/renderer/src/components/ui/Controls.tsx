/**
 * Базовые UI-примитивы: кнопки со свечением, переключатели, селекты.
 * Все анимации — CSS (transform/opacity), чтобы не дёргать layout.
 */
import type { ReactElement, ReactNode } from 'react'

// ─── Кнопка со свечением ────────────────────────────────────────────────────
export function GlowButton({
  children,
  onClick,
  variant = 'ghost',
  disabled = false,
  className = '',
  title
}: {
  children: ReactNode
  onClick?: () => void
  variant?: 'gold' | 'ghost' | 'danger' | 'teal'
  disabled?: boolean
  className?: string
  title?: string
}): ReactElement {
  return (
    <button className={`btn btn-${variant} ${className}`} onClick={onClick} disabled={disabled} title={title}>
      {children}
    </button>
  )
}

// ─── Переключатель (toggle) ─────────────────────────────────────────────────
export function Toggle({
  label,
  checked,
  onChange,
  hint
}: {
  label: string
  checked: boolean
  onChange: (v: boolean) => void
  hint?: string
}): ReactElement {
  return (
    <label className="toggle-row" title={hint}>
      <span className="toggle-label">{label}</span>
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        className={`toggle ${checked ? 'on' : ''}`}
        onClick={() => onChange(!checked)}
      >
        <span className="toggle-knob" />
      </button>
    </label>
  )
}

// ─── Селект ─────────────────────────────────────────────────────────────────
export interface SelectOption {
  value: string
  label: string
}

export function Select({
  label,
  value,
  options,
  onChange
}: {
  label: string
  value: string
  options: SelectOption[]
  onChange: (v: string) => void
}): ReactElement {
  return (
    <label className="select-row">
      <span className="select-label">{label}</span>
      <span className="select-wrap">
        <select className="select" value={value} onChange={(e) => onChange(e.target.value)}>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
        <svg className="select-caret" viewBox="0 0 10 6" aria-hidden="true">
          <path d="M0 0l5 6 5-6z" fill="currentColor" />
        </svg>
      </span>
    </label>
  )
}

// ─── Текстовое поле ─────────────────────────────────────────────────────────
export function TextField({
  label,
  value,
  onChange,
  placeholder,
  mono = false
}: {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  mono?: boolean
}): ReactElement {
  return (
    <label className="text-row">
      <span className="select-label">{label}</span>
      <input
        className={`text-input ${mono ? 'mono' : ''}`}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        spellCheck={false}
      />
    </label>
  )
}
