/**
 * Прогресс-бар: градиентная заливка + бегущий блик + искры на кромке.
 * Реализовано чисто на CSS-анимациях (transform/opacity) — дёшево для CPU.
 */
import type { ReactElement } from 'react'

export function ProgressBar({
  value,
  active,
  label
}: {
  /** 0..1 */
  value: number
  active: boolean
  label?: string
}): ReactElement {
  const pct = Math.max(0, Math.min(1, value)) * 100
  return (
    <div className={`progressbar ${active ? 'active' : ''}`} role="progressbar" aria-valuenow={Math.round(pct)} aria-valuemin={0} aria-valuemax={100}>
      <div className="progressbar-track">
        <div className="progressbar-fill" style={{ width: `${pct}%` }}>
          <span className="progressbar-shine" />
          <span className="progressbar-spark s1" />
          <span className="progressbar-spark s2" />
          <span className="progressbar-spark s3" />
        </div>
      </div>
      {label && <div className="progressbar-label">{label}</div>}
    </div>
  )
}
