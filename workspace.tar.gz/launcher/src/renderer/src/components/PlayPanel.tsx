/**
 * Вкладка «Игра»: путь к клиенту, валидация, realmlist, кнопка запуска,
 * прогресс обновлений клиента и баннер апдейта лаунчера.
 */
import { useCallback, useEffect, useState } from 'react'
import type { ReactElement } from 'react'
import type { ClientValidation } from '@shared/types'
import { useAppState } from '@renderer/state/AppState'
import { useI18n } from '@renderer/i18n/strings'
import { useToasts } from '@renderer/components/ui/Toasts'
import { GlowButton } from '@renderer/components/ui/Controls'
import { ProgressBar } from '@renderer/components/ui/ProgressBar'

function formatMb(bytes: number): string {
  return (bytes / 1048576).toFixed(1)
}

export function PlayPanel(): ReactElement {
  const { state, actions } = useAppState()
  const { t } = useI18n()
  const toasts = useToasts()
  const [validation, setValidation] = useState<ClientValidation | null>(null)
  const [checking, setChecking] = useState(false)
  const [launching, setLaunching] = useState(false)

  const clientPath = state.snapshot?.user.clientPath ?? null
  const game = state.game
  const patch = state.patch
  const update = state.update
  const server = state.snapshot?.server

  // Валидация при смене пути
  const revalidate = useCallback(async (p: string | null) => {
    if (!p) {
      setValidation(null)
      return
    }
    setChecking(true)
    try {
      setValidation(await window.launcherAPI.client.validate(p))
    } catch (e) {
      console.error(e)
      setValidation(null)
    } finally {
      setChecking(false)
    }
  }, [])

  useEffect(() => {
    void revalidate(clientPath)
  }, [clientPath, revalidate])

  const onPick = async (): Promise<void> => {
    const dir = await window.launcherAPI.client.pick()
    if (dir) toasts.push('success', t('toast.autodetect.found', { path: dir }))
  }

  const onAutodetect = async (): Promise<void> => {
    const found = await window.launcherAPI.client.autodetect()
    if (found.length === 0) {
      toasts.push('warn', t('toast.autodetect.none'))
      return
    }
    await actions.setConfig({ clientPath: found[0] })
    toasts.push('success', t('toast.autodetect.found', { path: found[0] }))
  }

  const onFixRealmlist = async (): Promise<void> => {
    const res = await window.launcherAPI.realmlist.apply(null)
    if (res.ok) toasts.push('success', t('play.realmlist.ok', { files: res.files.length }))
    else toasts.push('error', t('play.realmlist.fail', { err: res.error ?? '?' }))
  }

  const onLaunch = async (): Promise<void> => {
    setLaunching(true)
    try {
      const res = await window.launcherAPI.game.launch()
      if (res.ok) toasts.push('success', t('play.launch.ok'))
      else toasts.push('error', t('play.launch.error', { err: res.error ?? '?' }))
    } finally {
      setLaunching(false)
    }
  }

  const running = game?.running === true
  const clientOk = validation?.ok === true
  const issues = validation ? [...validation.errors, ...validation.warnings] : []

  // Прогресс патчей
  const patchActive = patch && ['manifest', 'checking', 'downloading', 'applying'].includes(patch.phase)
  const patchProgress = patch ? (patch.progress.bytesTotal > 0 ? patch.progress.bytesDone / patch.progress.bytesTotal : 0) : 0
  const patchLabel = patch
    ? patch.phase === 'downloading'
      ? t('patch.progress', {
          done: patch.progress.filesDone,
          total: patch.progress.filesTotal,
          mb: formatMb(patch.progress.bytesDone),
          speed: (patch.speedBps / 1048576).toFixed(1)
        })
      : t(`patch.phase.${patch.phase}`, { err: patch.error ?? '' })
    : ''

  return (
    <div className="panel play-panel">
      <div className="hero">
        <h1 className="hero-title">{server?.server.name ?? 'WOSERGAME.NET'}</h1>
        <p className="hero-tagline">{server?.server.tagline ?? t('play.hero.tagline')}</p>
      </div>

      {/* Баннер обновления лаунчера */}
      {update && (update.phase === 'available' || update.phase === 'downloading' || update.phase === 'ready') && (
        <div className="update-banner">
          <span className="update-banner-text">
            {update.phase === 'downloading'
              ? t('update.downloading', { mb: formatMb(update.progress.bytesDone) })
              : update.phase === 'ready'
                ? t('update.ready')
                : t('update.banner', { v: update.latestVersion ?? '?' })}
          </span>
          {update.phase === 'ready' && (
            <GlowButton variant="teal" onClick={() => void window.launcherAPI.update.install()}>
              {t('update.install')}
            </GlowButton>
          )}
          {update.phase === 'downloading' && <ProgressBar value={update.progress.bytesTotal ? update.progress.bytesDone / update.progress.bytesTotal : 0} active />}
        </div>
      )}

      {/* Карточка клиента */}
      <section className="card client-card">
        <div className="card-head">
          <h2>{t('play.client.title')}</h2>
          <span className={`badge ${checking ? 'badge-wait' : clientOk ? 'badge-ok' : validation ? 'badge-bad' : 'badge-mute'}`}>
            {checking ? t('play.client.checking') : clientOk ? t('play.client.ok') : validation ? t('play.client.bad') : '—'}
          </span>
        </div>
        <div className="client-row">
          <input className="text-input mono grow" readOnly value={clientPath ?? ''} placeholder={t('play.client.placeholder')} />
          <GlowButton variant="ghost" onClick={() => void onPick()}>
            {t('play.client.pick')}
          </GlowButton>
          <GlowButton variant="ghost" onClick={() => void onAutodetect()}>
            {t('play.client.autodetect')}
          </GlowButton>
          <GlowButton variant="ghost" onClick={() => void onFixRealmlist()} disabled={!clientPath} title={`set realmlist ${server?.server.realmHost ?? ''}`}>
            {t('play.realmlist.fix')}
          </GlowButton>
        </div>
        {issues.length > 0 && (
          <ul className="issues">
            {issues.map((i, idx) => (
              <li key={idx} className={i.fatal ? 'issue-fatal' : 'issue-warn'}>
                {i.message}
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* Обновление клиента */}
      {patch && patch.phase !== 'disabled' && (
        <section className="card patch-card">
          <div className="card-head">
            <h2>{t('patch.title')}</h2>
            <div className="card-head-actions">
              {patchActive ? (
                <GlowButton variant="danger" onClick={() => window.launcherAPI.patch.cancel()}>
                  {t('patch.cancel')}
                </GlowButton>
              ) : (
                <GlowButton variant="ghost" onClick={() => void window.launcherAPI.patch.start()} disabled={!clientOk}>
                  {t('patch.start')}
                </GlowButton>
              )}
            </div>
          </div>
          {patchActive && <ProgressBar value={patchProgress} active label={patchLabel} />}
          {!patchActive && patch.phase !== 'idle' && <p className={`patch-note note-${patch.phase}`}>{patchLabel}</p>}
        </section>
      )}

      <div className="play-footer">
        <GlowButton
          variant="gold"
          className="play-button"
          disabled={running || launching || !clientOk}
          onClick={() => void onLaunch()}
        >
          <span className="play-button-glow" />
          <span className="play-button-label">
            {running ? t('play.running') : launching ? t('play.launching') : t('play.launch')}
          </span>
        </GlowButton>
      </div>
    </div>
  )
}
