/**
 * SceneController — движок «живого фона» (без React, чистый Canvas + rAF).
 *
 * Принципы производительности (ТЗ: ≤5–10% CPU в простое):
 *  - ОДИН requestAnimationFrame-цикл на все слои и канвасы;
 *  - FPS-кап (20/30/60) через аккумулятор времени — кадры просто пропускаются;
 *  - туман рендерится в канвас половинного разрешения (мягкость бесплатно);
 *  - частицы — object pool без аллокаций в кадре, свечение — предрендер-спрайты;
 *  - DOM-слои двигаются ТОЛЬКО через transform: translate3d (GPU-композитинг);
 *  - авто-даунгрейд качества при деградации frame-time (режим «auto»);
 *  - полная остановка цикла, когда окно скрыто/свёрнуто.
 */
import type { GraphicsQuality, ParticleKind } from '@shared/types'

export type SceneLevel = 0 | 1 | 2 | 3

export interface SceneOptions {
  quality: GraphicsQuality
  particles: ParticleKind
  parallax: boolean
  fog: boolean
  fpsCap: 30 | 60
  paused: boolean
}

interface LevelPreset {
  fps: number
  particleCount: number
  fogBack: number
  fogFront: number
}

const PRESETS: Record<SceneLevel, LevelPreset> = {
  0: { fps: 0, particleCount: 0, fogBack: 0, fogFront: 0 },
  1: { fps: 20, particleCount: 22, fogBack: 2, fogFront: 0 },
  2: { fps: 30, particleCount: 55, fogBack: 3, fogFront: 3 },
  3: { fps: 60, particleCount: 100, fogBack: 4, fogFront: 4 }
}

const MAX_PARALLAX_X = 22 // px для depth=1
const MAX_PARALLAX_Y = 12

interface Particle {
  x: number
  y: number
  vx: number
  vy: number
  size: number
  phase: number
  flicker: number
  kind: 0 | 1 | 2 // 0 ember, 1 snow, 2 ash
  alpha: number
}

interface FogBlob {
  x: number
  y: number
  w: number
  h: number
  vx: number
  alpha: number
}

function makeGlowSprite(color: string, size = 32): HTMLCanvasElement {
  const c = document.createElement('canvas')
  c.width = size
  c.height = size
  const ctx = c.getContext('2d')!
  const g = ctx.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2)
  g.addColorStop(0, color)
  g.addColorStop(0.35, color.replace('1)', '0.55)'))
  g.addColorStop(1, 'rgba(0,0,0,0)')
  ctx.fillStyle = g
  ctx.fillRect(0, 0, size, size)
  return c
}

function makeFogSprite(): HTMLCanvasElement {
  const w = 256
  const h = 128
  const c = document.createElement('canvas')
  c.width = w
  c.height = h
  const ctx = c.getContext('2d')!
  // Несколько сливающихся радиальных пятен → органичное облако
  for (let i = 0; i < 5; i++) {
    const cx = w * (0.2 + Math.random() * 0.6)
    const cy = h * (0.3 + Math.random() * 0.4)
    const r = h * (0.25 + Math.random() * 0.3)
    const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, r)
    g.addColorStop(0, 'rgba(190,215,225,0.32)')
    g.addColorStop(0.6, 'rgba(170,200,215,0.12)')
    g.addColorStop(1, 'rgba(160,190,205,0)')
    ctx.fillStyle = g
    ctx.fillRect(0, 0, w, h)
  }
  return c
}

export class SceneController {
  private root: HTMLElement
  private layers: { el: HTMLElement; depth: number }[] = []
  private fogBack: HTMLCanvasElement | null = null
  private fogFront: HTMLCanvasElement | null = null
  private particleCanvas: HTMLCanvasElement | null = null
  private fogBackCtx: CanvasRenderingContext2D | null = null
  private fogFrontCtx: CanvasRenderingContext2D | null = null
  private particleCtx: CanvasRenderingContext2D | null = null

  private opts: SceneOptions
  private level: SceneLevel = 3
  private raf = 0
  private lastTs = 0
  private acc = 0
  private running = false

  private pointer = { x: 0, y: 0 }
  private smoothed = { x: 0, y: 0 }

  private particles: Particle[] = []
  private fogBackBlobs: FogBlob[] = []
  private fogFrontBlobs: FogBlob[] = []

  private emberSprite: HTMLCanvasElement
  private snowSprite: HTMLCanvasElement
  private ashSprite: HTMLCanvasElement
  private fogSprite: HTMLCanvasElement

  private frameTimes: number[] = []
  private lastAutoCheck = 0

  onDowngrade: (() => void) | null = null

  constructor(root: HTMLElement, opts: SceneOptions) {
    this.root = root
    this.opts = { ...opts }
    this.emberSprite = makeGlowSprite('rgba(255,176,84,1)')
    this.snowSprite = makeGlowSprite('rgba(226,240,255,1)')
    this.ashSprite = makeGlowSprite('rgba(148,158,168,1)')
    this.fogSprite = makeFogSprite()

    this.collectLayers()
    this.bindCanvases()
    this.applyLevel(this.resolveTargetLevel())
    this.bindEvents()
    this.start()
  }

  // ─── Инициализация ────────────────────────────────────────────────────────

  private collectLayers(): void {
    this.layers = Array.from(this.root.querySelectorAll<HTMLElement>('[data-depth]')).map((el) => ({
      el,
      depth: Number(el.dataset.depth ?? '0')
    }))
    this.fogBack = this.root.querySelector<HTMLCanvasElement>('canvas[data-fog="back"]')
    this.fogFront = this.root.querySelector<HTMLCanvasElement>('canvas[data-fog="front"]')
    this.particleCanvas = this.root.querySelector<HTMLCanvasElement>('canvas[data-particles]')
  }

  private bindCanvases(): void {
    if (this.fogBack) this.fogBackCtx = this.fogBack.getContext('2d')
    if (this.fogFront) this.fogFrontCtx = this.fogFront.getContext('2d')
    if (this.particleCanvas) this.particleCtx = this.particleCanvas.getContext('2d')
    this.resizeCanvases()
  }

  private resizeCanvases(): void {
    const w = this.root.clientWidth || 1280
    const h = this.root.clientHeight || 800
    // Туман — в половинном разрешении: мягко и дёшево
    for (const c of [this.fogBack, this.fogFront]) {
      if (!c) continue
      c.width = Math.max(2, Math.floor(w / 2))
      c.height = Math.max(2, Math.floor(h / 2))
    }
    if (this.particleCanvas) {
      const dpr = Math.min(window.devicePixelRatio || 1, 1.25)
      this.particleCanvas.width = Math.floor(w * dpr)
      this.particleCanvas.height = Math.floor(h * dpr)
      this.particleCtx?.setTransform(dpr, 0, 0, dpr, 0, 0)
    }
  }

  private bindEvents(): void {
    window.addEventListener('pointermove', this.onPointerMove, { passive: true })
    window.addEventListener('resize', this.onResize)
    document.addEventListener('visibilitychange', this.onVisibility)
  }

  private onPointerMove = (e: PointerEvent): void => {
    if (!this.opts.parallax) return
    const w = window.innerWidth || 1
    const h = window.innerHeight || 1
    this.pointer.x = (e.clientX / w) * 2 - 1
    this.pointer.y = (e.clientY / h) * 2 - 1
  }

  private onResize = (): void => {
    this.resizeCanvases()
  }

  private onVisibility = (): void => {
    if (document.hidden) this.stop()
    else this.start()
  }

  // ─── Качество / уровни ────────────────────────────────────────────────────

  private resolveTargetLevel(): SceneLevel {
    switch (this.opts.quality) {
      case 'off':
        return 0
      case 'low':
        return 1
      case 'medium':
        return 2
      case 'high':
        return 3
      case 'auto': {
        const cores = navigator.hardwareConcurrency ?? 4
        return cores <= 4 ? 2 : 3
      }
      default:
        return 2
    }
  }

  private effectiveFps(): number {
    const preset = PRESETS[this.level]
    if (this.level === 0) return 0
    if (this.opts.quality === 'auto' || this.opts.quality === 'high') {
      return Math.min(preset.fps, this.opts.fpsCap)
    }
    return preset.fps
  }

  /** Применяет уровень: пулы частиц/тумана, видимость канвасов. */
  private applyLevel(level: SceneLevel): void {
    this.level = level
    const preset = PRESETS[level]
    const off = level === 0
    this.root.classList.toggle('scene-off', off)
    if (this.fogBack) this.fogBack.style.display = off || !this.opts.fog ? 'none' : 'block'
    if (this.fogFront) this.fogFront.style.display = off || !this.opts.fog || preset.fogFront === 0 ? 'none' : 'block'
    if (this.particleCanvas) this.particleCanvas.style.display = off ? 'none' : 'block'

    this.rebuildParticles(preset.particleCount)
    this.rebuildFog(this.fogBackBlobs, preset.fogBack)
    this.rebuildFog(this.fogFrontBlobs, preset.fogFront)

    if (off) {
      // Статичная композиция без цикла
      for (const l of this.layers) l.el.style.transform = 'translate3d(0,0,0) scale(1.08)'
    }
  }

  private rebuildParticles(count: number): void {
    const w = this.root.clientWidth || 1280
    const h = this.root.clientHeight || 800
    while (this.particles.length < count) this.particles.push(this.spawnParticle(w, h, true))
    if (this.particles.length > count) this.particles.length = count
  }

  private spawnParticle(w: number, h: number, anywhere: boolean): Particle {
    const kindRaw = this.opts.particles
    let kind: 0 | 1 | 2
    if (kindRaw === 'embers') kind = 0
    else if (kindRaw === 'snow') kind = 1
    else if (kindRaw === 'ash') kind = 2
    else kind = ([0, 1, 2] as const)[Math.floor(Math.random() * 3)]

    const p: Particle = {
      x: Math.random() * w,
      y: anywhere ? Math.random() * h : kind === 0 ? h + 10 : -10,
      vx: 0,
      vy: 0,
      size: 1.5 + Math.random() * 3,
      phase: Math.random() * Math.PI * 2,
      flicker: 1.5 + Math.random() * 3,
      kind,
      alpha: 0.35 + Math.random() * 0.5
    }
    if (kind === 0) {
      p.vy = -(9 + Math.random() * 16)
      p.size = 1.8 + Math.random() * 3.4
    } else if (kind === 1) {
      p.vy = 12 + Math.random() * 18
      p.size = 1.2 + Math.random() * 2.4
    } else {
      p.vy = 6 + Math.random() * 10
      p.size = 1 + Math.random() * 2.2
      p.alpha = 0.2 + Math.random() * 0.35
    }
    return p
  }

  private rebuildFog(pool: FogBlob[], count: number): void {
    const w = this.root.clientWidth || 1280
    const h = this.root.clientHeight || 800
    while (pool.length < count) {
      pool.push({
        x: Math.random() * w,
        y: h * (0.45 + Math.random() * 0.45),
        w: w * (0.45 + Math.random() * 0.5),
        h: h * (0.16 + Math.random() * 0.16),
        vx: (4 + Math.random() * 9) * (Math.random() > 0.5 ? 1 : -1),
        alpha: 0.5 + Math.random() * 0.5
      })
    }
    if (pool.length > count) pool.length = count
  }

  // ─── Публичное API ────────────────────────────────────────────────────────

  setOptions(next: Partial<SceneOptions>): void {
    const prev = this.opts
    this.opts = { ...prev, ...next }
    const levelChanged = prev.quality !== this.opts.quality
    if (levelChanged) {
      this.applyLevel(this.resolveTargetLevel())
    } else {
      // Туман/частицы могли поменяться точечно
      const preset = PRESETS[this.level]
      if (this.fogBack) this.fogBack.style.display = this.level === 0 || !this.opts.fog ? 'none' : 'block'
      if (this.fogFront)
        this.fogFront.style.display = this.level === 0 || !this.opts.fog || preset.fogFront === 0 ? 'none' : 'block'
      this.rebuildFog(this.fogBackBlobs, this.opts.fog ? preset.fogBack : 0)
      this.rebuildFog(this.fogFrontBlobs, this.opts.fog ? preset.fogFront : 0)
      if (prev.particles !== this.opts.particles) {
        this.particles = []
        this.rebuildParticles(preset.particleCount)
      }
    }
    if (this.opts.paused) this.stop()
    else this.start()
  }

  start(): void {
    if (this.running || this.level === 0 || this.opts.paused) return
    this.running = true
    this.lastTs = performance.now()
    this.acc = 0
    this.raf = requestAnimationFrame(this.tick)
  }

  stop(): void {
    if (!this.running) return
    this.running = false
    cancelAnimationFrame(this.raf)
  }

  destroy(): void {
    this.stop()
    window.removeEventListener('pointermove', this.onPointerMove)
    window.removeEventListener('resize', this.onResize)
    document.removeEventListener('visibilitychange', this.onVisibility)
  }

  // ─── Кадр ─────────────────────────────────────────────────────────────────

  private tick = (ts: number): void => {
    if (!this.running) return
    this.raf = requestAnimationFrame(this.tick)

    const dtMs = ts - this.lastTs
    this.lastTs = ts
    const interval = 1000 / Math.max(1, this.effectiveFps())
    this.acc += dtMs
    if (this.acc < interval) return // FPS-кап: пропускаем кадр
    const dt = Math.min(0.05, this.acc / 1000)
    this.acc = 0

    this.trackFrameTime(ts, dtMs)

    const w = this.root.clientWidth || 1280
    const h = this.root.clientHeight || 800

    // Сглаживание указателя + синусоидальный дрейф (живёт даже без мыши)
    this.smoothed.x += (this.pointer.x - this.smoothed.x) * 0.06
    this.smoothed.y += (this.pointer.y - this.smoothed.y) * 0.06
    const driftX = Math.sin(ts * 0.000045) * 0.4 + Math.sin(ts * 0.000013 + 1.7) * 0.2
    const driftY = Math.cos(ts * 0.000031) * 0.25
    const ox = (this.opts.parallax ? this.smoothed.x : 0) + driftX
    const oy = (this.opts.parallax ? this.smoothed.y : 0) + driftY

    // DOM-слои: только transform (GPU)
    for (const l of this.layers) {
      const tx = -ox * l.depth * MAX_PARALLAX_X
      const ty = -oy * l.depth * MAX_PARALLAX_Y
      l.el.style.transform = `translate3d(${tx.toFixed(2)}px, ${ty.toFixed(2)}px, 0) scale(1.08)`
    }

    if (this.opts.fog) {
      this.drawFog(this.fogBackCtx, this.fogBackBlobs, w, h, dt, 0.55)
      this.drawFog(this.fogFrontCtx, this.fogFrontBlobs, w, h, dt, 0.85)
    }
    this.drawParticles(w, h, dt, ts)
  }

  private drawFog(ctx: CanvasRenderingContext2D | null, blobs: FogBlob[], w: number, h: number, dt: number, intensity: number): void {
    if (!ctx || blobs.length === 0) return
    const cw = ctx.canvas.width
    const ch = ctx.canvas.height
    ctx.clearRect(0, 0, cw, ch)
    const sx = cw / w
    const sy = ch / h
    for (const b of blobs) {
      b.x += b.vx * dt
      if (b.vx > 0 && b.x > w + b.w * 0.5) b.x = -b.w * 0.5
      if (b.vx < 0 && b.x < -b.w * 0.5) b.x = w + b.w * 0.5
      ctx.globalAlpha = b.alpha * intensity
      ctx.drawImage(this.fogSprite, b.x * sx - (b.w * sx) / 2, b.y * sy - (b.h * sy) / 2, b.w * sx, b.h * sy)
    }
    ctx.globalAlpha = 1
  }

  private drawParticles(w: number, h: number, dt: number, ts: number): void {
    const ctx = this.particleCtx
    if (!ctx || this.particles.length === 0) return
    ctx.clearRect(0, 0, w, h)
    const wind = Math.sin(ts * 0.00012) * 8 + 4
    for (const p of this.particles) {
      // Движение: собственная скорость + покачивание + ветер
      const sway = Math.sin(ts * 0.001 * p.flicker + p.phase) * (p.kind === 0 ? 10 : 14)
      p.x += (sway * 0.35 + (p.kind === 2 ? wind : wind * 0.35)) * dt
      p.y += p.vy * dt

      // Респаун за пределами экрана
      if (p.kind === 0 && p.y < -20) {
        Object.assign(p, this.spawnParticle(w, h, false))
      } else if (p.kind !== 0 && p.y > h + 20) {
        Object.assign(p, this.spawnParticle(w, h, false))
      }
      if (p.x > w + 30) p.x = -20
      if (p.x < -30) p.x = w + 20

      const sprite = p.kind === 0 ? this.emberSprite : p.kind === 1 ? this.snowSprite : this.ashSprite
      const flick = p.kind === 0 ? 0.65 + 0.35 * Math.sin(ts * 0.004 * p.flicker + p.phase) : 1
      ctx.globalAlpha = p.alpha * flick
      const s = p.size * 4
      ctx.drawImage(sprite, p.x - s / 2, p.y - s / 2, s, s)
    }
    ctx.globalAlpha = 1
  }

  // ─── Авто-даунгрейд (режим auto) ──────────────────────────────────────────

  private trackFrameTime(ts: number, dtMs: number): void {
    // Анализируем производительность только в auto-режиме
    if (this.opts.quality !== 'auto') return
    if (dtMs > 200) return // пауза/сворачивание — не учитываем
    this.frameTimes.push(dtMs)
    if (this.frameTimes.length > 90) this.frameTimes.shift()
    if (ts - this.lastAutoCheck < 5000 || this.frameTimes.length < 60) return
    this.lastAutoCheck = ts
    const avg = this.frameTimes.reduce((s, v) => s + v, 0) / this.frameTimes.length
    const interval = 1000 / Math.max(1, this.effectiveFps())
    if (avg > interval * 1.4 && this.level > 1) {
      this.applyLevel((this.level - 1) as SceneLevel)
      this.frameTimes = []
      this.onDowngrade?.()
    }
  }
}
