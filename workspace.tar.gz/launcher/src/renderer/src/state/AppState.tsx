/**
 * Глобальное состояние приложения (renderer):
 *  - снимок конфигурации + действия изменения;
 *  - статус сервера, состояние игры, состояние патчей/апдейта;
 *  - журнал (кольцевой буфер из main);
 *  - видимость окна (пауза анимаций) и maximized-флаг.
 */
import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState } from 'react'
import type { ReactElement, ReactNode } from 'react'
import type {
  ConfigSnapshot,
  GameState,
  IntegrityProgress,
  IntegrityReport,
  LauncherUpdateState,
  LogEntry,
  PatchState,
  RealmStatus,
  UserConfig
} from '@shared/types'
import type { AppInfo } from '../../../preload/index'

export interface AppState {
  ready: boolean
  snapshot: ConfigSnapshot | null
  appInfo: AppInfo | null
  realm: RealmStatus | null
  game: GameState | null
  patch: PatchState | null
  update: LauncherUpdateState | null
  integrityProgress: IntegrityProgress | null
  integrityReport: IntegrityReport | null
  logs: LogEntry[]
  windowVisible: boolean
  maximized: boolean
}

interface AppActions {
  setConfig: (patch: Partial<UserConfig>) => Promise<void>
  resetConfig: () => Promise<void>
  refreshRealm: () => Promise<void>
}

const StateContext = createContext<{ state: AppState; actions: AppActions } | null>(null)

export function useAppState(): { state: AppState; actions: AppActions } {
  const ctx = useContext(StateContext)
  if (!ctx) throw new Error('useAppState вне провайдера')
  return ctx
}

const LOGS_UI_CAP = 300

export function AppStateProvider({ children }: { children: ReactNode }): ReactElement {
  const [state, setState] = useState<AppState>({
    ready: false,
    snapshot: null,
    appInfo: null,
    realm: null,
    game: null,
    patch: null,
    update: null,
    integrityProgress: null,
    integrityReport: null,
    logs: [],
    windowVisible: true,
    maximized: false
  })
  const patchRef = useRef<(p: Partial<UserConfig>) => Promise<void>>(async () => undefined)

  const patch = useCallback(async (p: Partial<UserConfig>) => {
    const next = await window.launcherAPI.config.set(p)
    setState((s) => (s.snapshot ? { ...s, snapshot: { ...s.snapshot, user: next } } : s))
  }, [])
  patchRef.current = patch

  const reset = useCallback(async () => {
    const next = await window.launcherAPI.config.reset()
    setState((s) => (s.snapshot ? { ...s, snapshot: { ...s.snapshot, user: next } } : s))
  }, [])

  const refreshRealm = useCallback(async () => {
    const st = await window.launcherAPI.status.check()
    setState((s) => ({ ...s, realm: st }))
  }, [])

  // ─── Первичная загрузка ───────────────────────────────────────────────────
  useEffect(() => {
    let disposed = false
    void (async () => {
      try {
        const [snapshot, appInfo, realm, game, patchState, updateState, logs, lastReport] = await Promise.all([
          window.launcherAPI.config.get(),
          window.launcherAPI.app.info(),
          window.launcherAPI.status.check(),
          window.launcherAPI.game.state(),
          window.launcherAPI.patch.state(),
          window.launcherAPI.update.state(),
          window.launcherAPI.logs.recent(),
          window.launcherAPI.integrity.last()
        ])
        if (disposed) return
        setState((s) => ({
          ...s,
          snapshot,
          appInfo,
          realm,
          game,
          patch: patchState,
          update: updateState,
          logs,
          integrityReport: lastReport,
          ready: true
        }))
      } catch (e) {
        console.error('Bootstrap failed', e)
        if (!disposed) setState((s) => ({ ...s, ready: true }))
      }
    })()
    return () => {
      disposed = true
    }
  }, [])

  // ─── Подписки на события main-процесса ────────────────────────────────────
  useEffect(() => {
    const offs = [
      window.launcherAPI.on('game:state', (p) => setState((s) => ({ ...s, game: p as GameState }))),
      window.launcherAPI.on('status:update', (p) => setState((s) => ({ ...s, realm: p as RealmStatus }))),
      window.launcherAPI.on('patch:state', (p) => setState((s) => ({ ...s, patch: p as PatchState }))),
      window.launcherAPI.on('update:state', (p) => setState((s) => ({ ...s, update: p as LauncherUpdateState }))),
      window.launcherAPI.on('integrity:progress', (p) => setState((s) => ({ ...s, integrityProgress: p as IntegrityProgress }))),
      window.launcherAPI.on('integrity:done', (p) =>
        setState((s) => ({ ...s, integrityReport: p as IntegrityReport, integrityProgress: null }))
      ),
      window.launcherAPI.on('log:entry', (p) =>
        setState((s) => {
          const logs = [...s.logs, p as LogEntry]
          return { ...s, logs: logs.length > LOGS_UI_CAP ? logs.slice(logs.length - LOGS_UI_CAP) : logs }
        })
      ),
      window.launcherAPI.on('config:changed', () => {
        void window.launcherAPI.config.get().then((snap) => setState((s) => ({ ...s, snapshot: snap })))
      }),
      window.launcherAPI.on('app:visibility', (p) => setState((s) => ({ ...s, windowVisible: Boolean(p) }))),
      window.launcherAPI.on('app:maximized', (p) => setState((s) => ({ ...s, maximized: Boolean(p) })))
    ]
    return () => offs.forEach((off) => off())
  }, [])

  const actions = useMemo<AppActions>(
    () => ({ setConfig: (p) => patchRef.current(p), resetConfig: reset, refreshRealm }),
    [reset, refreshRealm]
  )

  return <StateContext.Provider value={{ state, actions }}>{children}</StateContext.Provider>
}
