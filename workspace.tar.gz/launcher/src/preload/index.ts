/**
 * Preload-скрипт: единственная граница между Node и браузерным контекстом.
 * contextIsolation: true, sandbox: true → наружу отдаётся только замороженный
 * whitelist-API через contextBridge. Обратные события — по именам из ALLOWED_EVENTS.
 */
import { contextBridge, ipcRenderer, IpcRendererEvent } from 'electron'
import { IPC } from '@shared/ipc'
import type {
  ClientValidation,
  ConfigSnapshot,
  GameState,
  IntegrityReport,
  LaunchResult,
  LauncherUpdateState,
  LogEntry,
  PatchState,
  RealmStatus,
  RealmlistResult,
  UserConfig
} from '@shared/types'

/** События main → renderer, на которые разрешена подписка. */
const ALLOWED_EVENTS = [
  'game:state',
  'integrity:progress',
  'integrity:done',
  'patch:state',
  'update:state',
  'status:update',
  'log:entry',
  'config:changed',
  'app:visibility',
  'app:maximized'
] as const

export type LauncherEventName = (typeof ALLOWED_EVENTS)[number]

export interface AppInfo {
  version: string
  electron: string
  chrome: string
  node: string
  platform: string
  arch: string
}

const api = {
  // ─── Окно / приложение ────────────────────────────────────────────────────
  app: {
    info: (): Promise<AppInfo> => ipcRenderer.invoke(IPC.APP_INFO),
    minimize: (): void => ipcRenderer.send(IPC.APP_MINIMIZE),
    toggleMaximize: (): void => ipcRenderer.send(IPC.APP_MAXIMIZE),
    close: (): void => ipcRenderer.send(IPC.APP_CLOSE),
    openExternal: (url: string): Promise<boolean> => ipcRenderer.invoke(IPC.APP_OPEN_EXTERNAL, url),
    openPath: (p: string): Promise<boolean> => ipcRenderer.invoke(IPC.APP_OPEN_PATH, p)
  },

  // ─── Конфигурация ─────────────────────────────────────────────────────────
  config: {
    get: (): Promise<ConfigSnapshot> => ipcRenderer.invoke(IPC.CONFIG_GET),
    set: (patch: Partial<UserConfig>): Promise<UserConfig> => ipcRenderer.invoke(IPC.CONFIG_SET, patch),
    reset: (): Promise<UserConfig> => ipcRenderer.invoke(IPC.CONFIG_RESET)
  },

  // ─── Клиент ──────────────────────────────────────────────────────────────
  client: {
    validate: (p?: string | null): Promise<ClientValidation> => ipcRenderer.invoke(IPC.CLIENT_VALIDATE, p ?? null),
    pick: (): Promise<string | null> => ipcRenderer.invoke(IPC.CLIENT_PICK),
    autodetect: (): Promise<string[]> => ipcRenderer.invoke(IPC.CLIENT_AUTODETECT)
  },

  // ─── Realmlist / игра ────────────────────────────────────────────────────
  realmlist: {
    apply: (p?: string | null): Promise<RealmlistResult> => ipcRenderer.invoke(IPC.REALMLIST_APPLY, p ?? null)
  },
  game: {
    launch: (): Promise<LaunchResult> => ipcRenderer.invoke(IPC.GAME_LAUNCH),
    state: (): Promise<GameState> => ipcRenderer.invoke(IPC.GAME_STATE)
  },

  // ─── Целостность / патчи / апдейт лаунчера ────────────────────────────────
  integrity: {
    start: (): Promise<IntegrityReport> => ipcRenderer.invoke(IPC.INTEGRITY_START),
    cancel: (): void => ipcRenderer.send(IPC.INTEGRITY_CANCEL),
    last: (): Promise<IntegrityReport | null> => ipcRenderer.invoke(IPC.INTEGRITY_LAST)
  },
  patch: {
    start: (): Promise<PatchState> => ipcRenderer.invoke(IPC.PATCH_START),
    cancel: (): void => ipcRenderer.send(IPC.PATCH_CANCEL),
    state: (): Promise<PatchState> => ipcRenderer.invoke(IPC.PATCH_STATE)
  },
  update: {
    check: (): Promise<LauncherUpdateState> => ipcRenderer.invoke(IPC.UPDATE_CHECK),
    install: (): Promise<boolean> => ipcRenderer.invoke(IPC.UPDATE_INSTALL),
    state: (): Promise<LauncherUpdateState> => ipcRenderer.invoke(IPC.UPDATE_STATE)
  },

  // ─── Статус / логи ───────────────────────────────────────────────────────
  status: {
    check: (): Promise<RealmStatus> => ipcRenderer.invoke(IPC.STATUS_CHECK)
  },
  logs: {
    recent: (): Promise<LogEntry[]> => ipcRenderer.invoke(IPC.LOGS_RECENT),
    clear: (): Promise<boolean> => ipcRenderer.invoke(IPC.LOGS_CLEAR),
    openFile: (): Promise<boolean> => ipcRenderer.invoke(IPC.LOGS_OPEN_FILE)
  },

  // ─── Подписка на события (whitelist) ─────────────────────────────────────
  on: (name: LauncherEventName, cb: (payload: unknown) => void): (() => void) => {
    if (!ALLOWED_EVENTS.includes(name)) {
      return () => undefined
    }
    const channel = name.startsWith('app:') ? name : 'event:' + name
    const handler = (_e: IpcRendererEvent, payload: unknown): void => cb(payload)
    ipcRenderer.on(channel, handler)
    return () => ipcRenderer.removeListener(channel, handler)
  }
}

export type LauncherApi = typeof api

contextBridge.exposeInMainWorld('launcherAPI', api)
