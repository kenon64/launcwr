/**
 * Реестр IPC-каналов (main ⇄ renderer).
 * Единый источник имён: preload whitelist'ит только эти каналы.
 */
export const IPC = {
  // Приложение / окно
  APP_INFO: 'app:info',
  APP_MINIMIZE: 'app:minimize',
  APP_MAXIMIZE: 'app:maximize',
  APP_CLOSE: 'app:close',
  APP_OPEN_EXTERNAL: 'app:open-external',
  APP_OPEN_PATH: 'app:open-path',

  // Конфигурация
  CONFIG_GET: 'config:get',
  CONFIG_SET: 'config:set',
  CONFIG_RESET: 'config:reset',

  // Клиент WoW
  CLIENT_VALIDATE: 'client:validate',
  CLIENT_PICK: 'client:pick',
  CLIENT_AUTODETECT: 'client:autodetect',

  // Realmlist
  REALMLIST_APPLY: 'realmlist:apply',

  // Игра
  GAME_LAUNCH: 'game:launch',
  GAME_STATE: 'game:state',

  // Целостность
  INTEGRITY_START: 'integrity:start',
  INTEGRITY_CANCEL: 'integrity:cancel',
  INTEGRITY_LAST: 'integrity:last',

  // Патчи клиента
  PATCH_START: 'patch:start',
  PATCH_CANCEL: 'patch:cancel',
  PATCH_STATE: 'patch:state',

  // Самообновление лаунчера
  UPDATE_CHECK: 'update:check',
  UPDATE_INSTALL: 'update:install',
  UPDATE_STATE: 'update:state',

  // Статус сервера
  STATUS_CHECK: 'status:check',

  // Логи
  LOGS_RECENT: 'logs:recent',
  LOGS_CLEAR: 'logs:clear',
  LOGS_OPEN_FILE: 'logs:open-file'
} as const

export type IpcChannel = (typeof IPC)[keyof typeof IPC]
