/**
 * Общие типы данных лаунчера WOSERGAME.
 * Используются и главным процессом (Node), и renderer'ом (Chromium),
 * поэтому не содержат импортов platform-специфичных модулей.
 */

// ─── Конфигурация ────────────────────────────────────────────────────────────

export type GraphicsQuality = 'auto' | 'high' | 'medium' | 'low' | 'off'
export type ParticleKind = 'embers' | 'snow' | 'ash' | 'mixed'
export type Locale = 'ru' | 'en'
export type ThemeName = 'dark' | 'light'

/** Серверная (read-only) часть конфигурации — поставляется в resources/config */
export interface ServerConfig {
  version: number
  server: {
    name: string
    tagline: string
    clientVersion: string
    expectedBuild: number
    realmHost: string
    realmPort: number
    websiteUrl: string | null
    supportUrl: string | null
    /** Необязательный HTTPS-endpoint вида {"players": N} */
    statusUrl: string | null
  }
  updates: {
    enabled: boolean
    manifestUrl: string | null
    channel: string
  }
  launcherUpdate: {
    enabled: boolean
    manifestUrl: string | null
  }
  ui: {
    defaultLocale: Locale
    theme: ThemeName
  }
  graphics: {
    quality: GraphicsQuality
    particles: ParticleKind
  }
  launch: {
    extraArgs: string[]
    autoFixRealmlist: boolean
    elevateIfReadonly: boolean
    minimizeOnGameStart: boolean
  }
}

/** Пользовательская (изменяемая) часть конфигурации — %APPDATA%/WOSERGAME */
export interface UserConfig {
  version: number
  clientPath: string | null
  ui: { locale: Locale; theme: ThemeName }
  graphics: {
    quality: GraphicsQuality
    particles: ParticleKind
    parallax: boolean
    fog: boolean
    runes: boolean
    fpsCap: 30 | 60
  }
  launch: {
    extraArgs: string[]
    autoFixRealmlist: boolean
    elevateIfReadonly: boolean
    minimizeOnGameStart: boolean
    windowed: boolean
    console: boolean
  }
  updates: { enabled: boolean }
  launcherUpdate: { enabled: boolean }
  firstRun: boolean
}

/** Объединённый снимок конфигурации для UI */
export interface ConfigSnapshot {
  server: ServerConfig
  user: UserConfig
  appVersion: string
  paths: { userData: string; logs: string; config: string }
}

// ─── Клиент WoW ──────────────────────────────────────────────────────────────

export interface ClientIssue {
  code:
    | 'NO_DIR'
    | 'NO_EXE'
    | 'NO_DATA'
    | 'NO_REALMLIST'
    | 'WRONG_BUILD'
    | 'MISSING_MPQ'
    | 'NOT_WRITABLE'
  message: string
  fatal: boolean
}

export interface ClientValidation {
  ok: boolean
  path: string | null
  wowExe: string | null
  locale: string | null
  build: number | null
  writable: boolean
  errors: ClientIssue[]
  warnings: ClientIssue[]
}

export interface RealmlistFileResult {
  file: string
  previousHost: string | null
  newHost: string
  changed: boolean
}

export interface RealmlistResult {
  ok: boolean
  files: RealmlistFileResult[]
  error: string | null
}

// ─── Запуск игры ─────────────────────────────────────────────────────────────

export interface LaunchResult {
  ok: boolean
  pid: number | null
  elevated: boolean
  error: string | null
}

export interface GameState {
  running: boolean
  pid: number | null
  lastExitCode: number | null
  launchedAt: number | null
}

// ─── Целостность файлов ──────────────────────────────────────────────────────

export interface ManifestFileEntry {
  /** POSIX-путь относительно корня клиента, например "Data/common.MPQ" */
  path: string
  sha256: string
  size: number
}

export interface ClientManifest {
  version: number
  baseUrl: string | null
  files: ManifestFileEntry[]
}

export interface IntegrityIssue {
  path: string
  kind: 'missing' | 'hash-mismatch' | 'size-mismatch' | 'unreadable'
  expected: string | null
  actual: string | null
}

export interface IntegrityReport {
  finishedAt: number
  durationMs: number
  total: number
  okCount: number
  bytesScanned: number
  issues: IntegrityIssue[]
  manifestVersion: number | null
}

export interface IntegrityProgress {
  filesDone: number
  filesTotal: number
  bytesDone: number
  bytesTotal: number
  currentFile: string | null
}

// ─── Обновления клиента ──────────────────────────────────────────────────────

export type PatchPhase = 'idle' | 'manifest' | 'checking' | 'downloading' | 'applying' | 'done' | 'error' | 'disabled'

export interface PatchState {
  phase: PatchPhase
  progress: IntegrityProgress
  speedBps: number
  currentFile: string | null
  error: string | null
  repaired: number
}

// ─── Обновление лаунчера ─────────────────────────────────────────────────────

export type LauncherUpdatePhase = 'idle' | 'checking' | 'available' | 'downloading' | 'ready' | 'installing' | 'error' | 'uptodate' | 'disabled'

export interface LauncherUpdateState {
  phase: LauncherUpdatePhase
  latestVersion: string | null
  progress: { bytesDone: number; bytesTotal: number }
  error: string | null
}

// ─── Статус realm-сервера ────────────────────────────────────────────────────

export type RealmState = 'online' | 'offline' | 'unknown'

export interface RealmStatus {
  state: RealmState
  host: string
  port: number
  latencyMs: number | null
  players: number | null
  checkedAt: number
}

// ─── Логи ────────────────────────────────────────────────────────────────────

export type LogLevel = 'error' | 'warn' | 'info' | 'debug'

export interface LogEntry {
  ts: number
  level: LogLevel
  scope: string
  message: string
}

// ─── События (main → renderer) ───────────────────────────────────────────────

export type LauncherEventName =
  | 'game:state'
  | 'integrity:progress'
  | 'integrity:done'
  | 'patch:state'
  | 'update:state'
  | 'status:update'
  | 'log:entry'
  | 'config:changed'

export interface LauncherEventMap {
  'game:state': GameState
  'integrity:progress': IntegrityProgress
  'integrity:done': IntegrityReport
  'patch:state': PatchState
  'update:state': LauncherUpdateState
  'status:update': RealmStatus
  'log:entry': LogEntry
  'config:changed': null
}
