/**
 * Утилиты валидации/нормализации данных (без зависимостей от Electron).
 * Используются ConfigService и тестами.
 */

import type { GraphicsQuality, Locale, ParticleKind, ThemeName } from '@shared/types'

const GRAPHICS_QUALITIES: GraphicsQuality[] = ['auto', 'high', 'medium', 'low', 'off']
const PARTICLE_KINDS: ParticleKind[] = ['embers', 'snow', 'ash', 'mixed']
const LOCALES: Locale[] = ['ru', 'en']
const THEMES: ThemeName[] = ['dark', 'light']

export function isObject(v: unknown): v is Record<string, unknown> {
  return typeof v === 'object' && v !== null && !Array.isArray(v)
}

export function pickString(v: unknown, fallback: string): string {
  return typeof v === 'string' ? v : fallback
}

export function pickStringOrNull(v: unknown): string | null {
  return typeof v === 'string' && v.length > 0 ? v : null
}

export function pickBool(v: unknown, fallback: boolean): boolean {
  return typeof v === 'boolean' ? v : fallback
}

export function pickNumber(v: unknown, fallback: number): number {
  return typeof v === 'number' && Number.isFinite(v) ? v : fallback
}

export function pickEnum<T extends string>(v: unknown, allowed: readonly T[], fallback: T): T {
  return typeof v === 'string' && (allowed as readonly string[]).includes(v) ? (v as T) : fallback
}

export function pickStringArray(v: unknown, fallback: string[] = []): string[] {
  if (!Array.isArray(v)) return [...fallback]
  return v.filter((x): x is string => typeof x === 'string').slice(0, 64)
}

/**
 * Валидация URL: разрешаем ТОЛЬКО https (требование безопасности ТЗ).
 * Возвращает нормализованный URL или null.
 */
export function sanitizeHttpsUrl(raw: unknown): string | null {
  if (typeof raw !== 'string' || raw.length === 0) return null
  try {
    const u = new URL(raw)
    if (u.protocol !== 'https:') return null
    // Запрещаем userinfo-часть (логин:пароль в URL)
    if (u.username || u.password) return null
    return u.toString()
  } catch {
    return null
  }
}

export { GRAPHICS_QUALITIES, PARTICLE_KINDS, LOCALES, THEMES }
