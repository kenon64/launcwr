"use strict";
/**
 * Общие типы данных лаунчера WOSERGAME.
 * Используются и главным процессом (Node), и renderer'ом (Chromium),
 * поэтому не содержат импортов platform-специфичных модулей.
 */
Object.defineProperty(exports, "__esModule", { value: true });
