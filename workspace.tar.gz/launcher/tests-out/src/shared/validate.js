"use strict";
/**
 * Утилиты валидации/нормализации данных (без зависимостей от Electron).
 * Используются ConfigService и тестами.
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.THEMES = exports.LOCALES = exports.PARTICLE_KINDS = exports.GRAPHICS_QUALITIES = void 0;
exports.isObject = isObject;
exports.pickString = pickString;
exports.pickStringOrNull = pickStringOrNull;
exports.pickBool = pickBool;
exports.pickNumber = pickNumber;
exports.pickEnum = pickEnum;
exports.pickStringArray = pickStringArray;
exports.sanitizeHttpsUrl = sanitizeHttpsUrl;
const GRAPHICS_QUALITIES = ['auto', 'high', 'medium', 'low', 'off'];
exports.GRAPHICS_QUALITIES = GRAPHICS_QUALITIES;
const PARTICLE_KINDS = ['embers', 'snow', 'ash', 'mixed'];
exports.PARTICLE_KINDS = PARTICLE_KINDS;
const LOCALES = ['ru', 'en'];
exports.LOCALES = LOCALES;
const THEMES = ['dark', 'light'];
exports.THEMES = THEMES;
function isObject(v) {
    return typeof v === 'object' && v !== null && !Array.isArray(v);
}
function pickString(v, fallback) {
    return typeof v === 'string' ? v : fallback;
}
function pickStringOrNull(v) {
    return typeof v === 'string' && v.length > 0 ? v : null;
}
function pickBool(v, fallback) {
    return typeof v === 'boolean' ? v : fallback;
}
function pickNumber(v, fallback) {
    return typeof v === 'number' && Number.isFinite(v) ? v : fallback;
}
function pickEnum(v, allowed, fallback) {
    return typeof v === 'string' && allowed.includes(v) ? v : fallback;
}
function pickStringArray(v, fallback = []) {
    if (!Array.isArray(v))
        return [...fallback];
    return v.filter((x) => typeof x === 'string').slice(0, 64);
}
/**
 * Валидация URL: разрешаем ТОЛЬКО https (требование безопасности ТЗ).
 * Возвращает нормализованный URL или null.
 */
function sanitizeHttpsUrl(raw) {
    if (typeof raw !== 'string' || raw.length === 0)
        return null;
    try {
        const u = new URL(raw);
        if (u.protocol !== 'https:')
            return null;
        // Запрещаем userinfo-часть (логин:пароль в URL)
        if (u.username || u.password)
            return null;
        return u.toString();
    }
    catch {
        return null;
    }
}
