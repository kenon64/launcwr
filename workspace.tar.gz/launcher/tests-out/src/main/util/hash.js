"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.hashFileSha256 = hashFileSha256;
exports.hashBufferSha256 = hashBufferSha256;
exports.isValidSha256 = isValidSha256;
/**
 * Потоковое вычисление SHA256 (для проверки целостности и загрузок).
 */
const node_fs_1 = require("node:fs");
const node_crypto_1 = require("node:crypto");
const promises_1 = require("node:fs/promises");
/**
 * Считает SHA256 файла чанками по 4 МБ (не держим файл в памяти).
 * onProgress вызывается не чаще раза в 100 мс, чтобы не спамить IPC.
 */
function hashFileSha256(filePath, onProgress) {
    return new Promise((resolve, reject) => {
        const hash = (0, node_crypto_1.createHash)('sha256');
        let bytesDone = 0;
        let bytesTotal = 0;
        let lastReport = 0;
        (0, promises_1.stat)(filePath)
            .then((s) => {
            bytesTotal = s.size;
            const stream = (0, node_fs_1.createReadStream)(filePath, { highWaterMark: 4 * 1024 * 1024 });
            stream.on('data', (chunk) => {
                hash.update(chunk);
                bytesDone += chunk.length;
                const now = Date.now();
                if (onProgress && now - lastReport > 100) {
                    lastReport = now;
                    onProgress({ bytesDone, bytesTotal });
                }
            });
            stream.on('end', () => resolve(hash.digest('hex')));
            stream.on('error', reject);
        })
            .catch(reject);
    });
}
/** SHA256 буфера (для небольших данных: manifest, realmlist). */
function hashBufferSha256(buf) {
    return (0, node_crypto_1.createHash)('sha256').update(buf).digest('hex');
}
function isValidSha256(hex) {
    return typeof hex === 'string' && /^[0-9a-f]{64}$/.test(hex);
}
