"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PathTraversalError = void 0;
exports.safeJoin = safeJoin;
exports.isInside = isInside;
exports.normalizeDirInput = normalizeDirInput;
/**
 * Безопасная работа с путями: защита от path traversal (требование ТЗ).
 * Все пути из внешних источников (manifest.json, конфиг) проходят через safeJoin.
 */
const node_path_1 = __importDefault(require("node:path"));
class PathTraversalError extends Error {
    constructor(p) {
        super(`Обнаружена попытка path traversal: "${p}"`);
        this.name = 'PathTraversalError';
    }
}
exports.PathTraversalError = PathTraversalError;
/**
 * Объединяет базовый каталог с относительным путём и гарантирует,
 * что результат остаётся ВНУТРИ базового каталога.
 * Блокирует: "..", абсолютные пути, UNC-пути, диски Windows ("C:"), нуль-байты.
 */
function safeJoin(baseDir, relative) {
    if (typeof relative !== 'string' || relative.includes('\0')) {
        throw new PathTraversalError(relative);
    }
    // Нормализуем разделители к платформенным
    const cleaned = relative.replace(/\\/g, '/');
    if (!cleaned || cleaned.length === 0)
        throw new PathTraversalError(relative);
    // Fail-close: любые абсолютные пути из внешних источников отклоняем
    if (cleaned.startsWith('/'))
        throw new PathTraversalError(relative);
    // Явные признаки абсолютного/UNC/drive-пути
    if (/^[a-zA-Z]:/.test(cleaned) || cleaned.startsWith('//') || cleaned.startsWith('\\\\')) {
        throw new PathTraversalError(relative);
    }
    const base = node_path_1.default.resolve(baseDir);
    const target = node_path_1.default.resolve(base, cleaned);
    if (target !== base && !target.startsWith(base + node_path_1.default.sep)) {
        throw new PathTraversalError(relative);
    }
    return target;
}
/** Проверяет, что путь target лежит внутри baseDir (для пользовательского выбора каталога). */
function isInside(baseDir, target) {
    const base = node_path_1.default.resolve(baseDir);
    const t = node_path_1.default.resolve(target);
    return t === base || t.startsWith(base + node_path_1.default.sep);
}
/** Нормализует пользовательский путь к каталогу (убирает хвостовые слеши, кавычки). */
function normalizeDirInput(raw) {
    let p = raw.trim().replace(/^["']|["']$/g, '');
    p = p.replace(/[\\/]+$/, '');
    return p;
}
