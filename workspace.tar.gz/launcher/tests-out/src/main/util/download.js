"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.DownloadError = void 0;
exports.downloadFile = downloadFile;
/**
 * Потоковая загрузка файла на диск с докачкой (resume) и проверкой SHA256.
 * Временный файл: "<target>.wpart". После успешной проверки — атомарный rename.
 */
const node_fs_1 = require("node:fs");
const promises_1 = require("node:fs/promises");
const node_path_1 = __importDefault(require("node:path"));
const node_crypto_1 = require("node:crypto");
const electron_1 = require("electron");
const http_1 = require("./http");
const CHUNK_REPORT_MS = 150;
class DownloadError extends Error {
    code;
    constructor(message, code = 'DOWNLOAD_ERROR') {
        super(message);
        this.code = code;
        this.name = 'DownloadError';
    }
}
exports.DownloadError = DownloadError;
function assertHttps(url) {
    let u;
    try {
        u = new URL(url);
    }
    catch {
        throw new DownloadError(`Некорректный URL: ${url}`);
    }
    if (u.protocol !== 'https:')
        throw new DownloadError(`Разрешён только HTTPS: ${url}`);
    if (u.username || u.password)
        throw new DownloadError('URL не должен содержать учётные данные');
}
/**
 * Скачивает url в targetPath. Если рядом лежит "<target>.wpart" — докачивает.
 * После загрузки (если задан expectedSha256) сверяет хеш и только потом
 * переименовует в целевой файл.
 */
async function downloadFile(url, targetPath, opts = {}) {
    assertHttps(url);
    await (0, promises_1.mkdir)(node_path_1.default.dirname(targetPath), { recursive: true });
    const partPath = targetPath + '.wpart';
    let resumeFrom = 0;
    let resumed = false;
    if ((0, node_fs_1.existsSync)(partPath)) {
        const st = (0, node_fs_1.statSync)(partPath);
        if (st.size > 0) {
            resumeFrom = st.size;
            resumed = true;
        }
        else {
            await (0, promises_1.unlink)(partPath).catch(() => undefined);
        }
    }
    const headers = {
        'User-Agent': 'WOSERGAME-Launcher/1.0 (+https://wosergame.net)'
    };
    if (resumeFrom > 0)
        headers.Range = `bytes=${resumeFrom}-`;
    return await new Promise((resolve, reject) => {
        const request = electron_1.net.request({ url, method: 'GET', headers });
        const stream = (0, node_fs_1.createWriteStream)(partPath, { flags: resumeFrom > 0 ? 'a' : 'w' });
        let bytesDone = resumeFrom;
        let bytesTotal = opts.expectedSize ?? 0;
        let lastReport = 0;
        let lastBytes = resumeFrom;
        let lastTime = Date.now();
        let settled = false;
        const timer = setTimeout(() => {
            cleanup(new DownloadError(`Таймаут загрузки (${opts.timeoutMs ?? 60_000} мс)`));
        }, opts.timeoutMs ?? 60_000);
        function cleanup(err) {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            stream.destroy();
            try {
                request.abort();
            }
            catch {
                /* noop */
            }
            if (err)
                reject(err);
        }
        request.on('response', (response) => {
            const code = response.statusCode;
            if (code !== 200 && code !== 206) {
                cleanup(new http_1.HttpError(`HTTP ${code} при загрузке ${url}`, code, url));
                return;
            }
            if (code === 200 && resumeFrom > 0) {
                // Сервер не поддержал Range — начинаем заново
                bytesDone = 0;
                resumed = false;
                stream.close();
                stream.destroy();
            }
            const clen = Number(response.headers['content-length']);
            if (Number.isFinite(clen) && clen > 0)
                bytesTotal = code === 206 ? bytesDone + clen : clen;
            const out = code === 206
                ? (0, node_fs_1.createWriteStream)(partPath, { flags: 'a' })
                : (0, node_fs_1.createWriteStream)(partPath, { flags: 'w' });
            response.on('data', (chunk) => {
                bytesDone += chunk.length;
                out.write(chunk);
                const now = Date.now();
                if (opts.onProgress && now - lastReport > CHUNK_REPORT_MS) {
                    const dt = (now - lastTime) / 1000;
                    const speed = dt > 0 ? (bytesDone - lastBytes) / dt : 0;
                    lastReport = now;
                    lastBytes = bytesDone;
                    lastTime = now;
                    opts.onProgress(bytesDone, bytesTotal, Math.round(speed));
                }
            });
            response.on('end', () => {
                out.end(() => {
                    clearTimeout(timer);
                    if (opts.signal?.aborted) {
                        cleanup(new DownloadError('Загрузка отменена', 'ABORTED'));
                        return;
                    }
                    verifyAndFinalize()
                        .then(() => {
                        settled = true;
                        resolve({ path: targetPath, bytes: bytesDone, resumed });
                    })
                        .catch((e) => cleanup(e));
                });
            });
            response.on('error', (e) => cleanup(new DownloadError(`Ошибка чтения потока: ${e.message}`)));
        });
        request.on('error', (e) => cleanup(new DownloadError(`Сетевая ошибка: ${e.message}`)));
        if (opts.signal) {
            if (opts.signal.aborted)
                cleanup(new DownloadError('Загрузка отменена', 'ABORTED'));
            opts.signal.addEventListener('abort', () => cleanup(new DownloadError('Загрузка отменена', 'ABORTED')));
        }
        async function verifyAndFinalize() {
            if (opts.expectedSha256) {
                const hash = (0, node_crypto_1.createHash)('sha256');
                await new Promise((res, rej) => {
                    const rs = (0, node_fs_1.createReadStream)(partPath);
                    rs.on('data', (c) => hash.update(c));
                    rs.on('end', () => res());
                    rs.on('error', rej);
                });
                const digest = hash.digest('hex');
                if (digest !== opts.expectedSha256) {
                    await (0, promises_1.unlink)(partPath).catch(() => undefined);
                    throw new DownloadError(`Несовпадение SHA256: ожидался ${opts.expectedSha256}, получен ${digest}`, 'HASH_MISMATCH');
                }
            }
            if (typeof opts.expectedSize === 'number' && bytesDone !== opts.expectedSize) {
                await (0, promises_1.unlink)(partPath).catch(() => undefined);
                throw new DownloadError(`Несовпадение размера: ожидалось ${opts.expectedSize}, получено ${bytesDone}`, 'SIZE_MISMATCH');
            }
            await (0, promises_1.rename)(partPath, targetPath);
        }
        request.end();
    });
}
