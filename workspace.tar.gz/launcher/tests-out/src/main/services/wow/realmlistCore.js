"use strict";
/**
 * Чистая логика работы с содержимым realmlist.wtf (без fs — покрыто тестами).
 * Формат строк WoW 3.3.5a:
 *   set realmlist play.wosergame.net
 *   set realmlistbn eu.actual.battle.net   (игнорируем)
 *   set patchlist ...                       (не трогаем)
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseRealmlist = parseRealmlist;
exports.buildRealmlist = buildRealmlist;
exports.extractHostFromLine = extractHostFromLine;
const REALMLIST_RE = /^\s*set\s+realmlist\s+(\S+)\s*$/i;
/** Разбор текста realmlist.wtf. */
function parseRealmlist(text) {
    if (text === null)
        return { lines: [], host: null, hadFile: false };
    const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    let host = null;
    for (const line of lines) {
        const m = REALMLIST_RE.exec(line);
        if (m)
            host = m[1].toLowerCase();
    }
    return { lines, host, hadFile: true };
}
/**
 * Формирует новое содержимое realmlist.wtf с нужным хостом:
 *  - заменяет существующую строку "set realmlist ..." (последнюю найденную),
 *  - либо добавляет строку в конец, если её не было,
 *  - сохраняет прочие строки и комментарии.
 */
function buildRealmlist(text, host) {
    const cleanHost = host.trim().toLowerCase().replace(/[^a-z0-9.-]/g, '');
    const target = `set realmlist ${cleanHost}`;
    if (text === null)
        return target + '\n';
    const lines = text.replace(/\r\n/g, '\n').replace(/\r/g, '\n').split('\n');
    let replaced = false;
    const out = [];
    for (const line of lines) {
        if (REALMLIST_RE.test(line)) {
            if (!replaced) {
                out.push(target);
                replaced = true;
            }
            // Дубликаты set realmlist удаляем
        }
        else {
            out.push(line);
        }
    }
    if (!replaced) {
        // Убираем хвостовые пустые строки и добавляем нашу
        while (out.length && out[out.length - 1].trim() === '')
            out.pop();
        out.push(target);
    }
    let result = out.join('\n');
    if (!result.endsWith('\n'))
        result += '\n';
    return result;
}
/** Извлекает хост из одиночной строки (для тестов/валидации). */
function extractHostFromLine(line) {
    const m = REALMLIST_RE.exec(line);
    return m ? m[1].toLowerCase() : null;
}
