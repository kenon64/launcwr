"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.parseClientManifest = parseClientManifest;
const validate_1 = require("../../../shared/validate");
const hash_1 = require("../../util/hash");
function normalizeRelPath(p) {
    if (typeof p !== 'string' || p.length === 0 || p.length > 512)
        return null;
    if (p.includes('\0'))
        return null;
    const cleaned = p.replace(/\\/g, '/').replace(/^\/+/, '');
    if (!cleaned)
        return null;
    if (/^[a-zA-Z]:/.test(cleaned))
        return null;
    const parts = cleaned.split('/');
    if (parts.some((seg) => seg === '..' || seg === ''))
        return null;
    return cleaned;
}
/** Валидирует и нормализует manifest.json. Любая ошибка → ok:false. */
function parseClientManifest(raw) {
    if (!(0, validate_1.isObject)(raw))
        return { ok: false, manifest: null, error: 'manifest: корень не является объектом' };
    const version = typeof raw.version === 'number' && Number.isFinite(raw.version) ? Math.floor(raw.version) : null;
    if (version === null)
        return { ok: false, manifest: null, error: 'manifest: нет поля version' };
    const baseUrl = raw.baseUrl === null || raw.baseUrl === undefined ? null : (0, validate_1.sanitizeHttpsUrl)(raw.baseUrl);
    if (raw.baseUrl && !baseUrl)
        return { ok: false, manifest: null, error: 'manifest: baseUrl должен быть HTTPS-URL' };
    if (!Array.isArray(raw.files))
        return { ok: false, manifest: null, error: 'manifest: поле files не является массивом' };
    const files = [];
    const seen = new Set();
    for (const item of raw.files) {
        if (!(0, validate_1.isObject)(item))
            continue;
        const rel = normalizeRelPath(item.path);
        const sha = item.sha256;
        const size = typeof item.size === 'number' && Number.isFinite(item.size) && item.size >= 0 ? Math.floor(item.size) : null;
        if (!rel || !(0, hash_1.isValidSha256)(sha) || size === null)
            continue;
        if (seen.has(rel.toLowerCase()))
            continue;
        seen.add(rel.toLowerCase());
        files.push({ path: rel, sha256: sha, size });
    }
    if (files.length === 0)
        return { ok: false, manifest: null, error: 'manifest: нет валидных записей files' };
    return { ok: true, manifest: { version, baseUrl, files }, error: null };
}
