"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EMBEDDED_SERVER_CONFIG = exports.CONFIG_VERSION = void 0;
exports.sanitizeServerConfig = sanitizeServerConfig;
exports.defaultUserConfig = defaultUserConfig;
exports.sanitizeUserConfig = sanitizeUserConfig;
const validate_1 = require("../../../shared/validate");
exports.CONFIG_VERSION = 1;
/** Встроенный fallback на случай отсутствия resources/config/launcher.config.json */
exports.EMBEDDED_SERVER_CONFIG = {
    version: exports.CONFIG_VERSION,
    server: {
        name: 'WOSERGAME.NET',
        tagline: 'Легендарный приватный сервер World of Warcraft 3.3.5a',
        clientVersion: '3.3.5a',
        expectedBuild: 12340,
        realmHost: 'play.wosergame.net',
        realmPort: 3724,
        websiteUrl: 'https://wosergame.net',
        supportUrl: 'https://vk.ru/wosergame',
        statusUrl: null
    },
    updates: { enabled: false, manifestUrl: null, channel: 'stable' },
    launcherUpdate: { enabled: false, manifestUrl: null },
    ui: { defaultLocale: 'ru', theme: 'dark' },
    graphics: { quality: 'auto', particles: 'embers' },
    launch: { extraArgs: [], autoFixRealmlist: true, elevateIfReadonly: true, minimizeOnGameStart: true }
};
/** Приводит произвольный JSON к валидному ServerConfig (все поля с fallback). */
function sanitizeServerConfig(raw) {
    const d = exports.EMBEDDED_SERVER_CONFIG;
    if (!(0, validate_1.isObject)(raw))
        return structuredClone(d);
    const server = (0, validate_1.isObject)(raw.server) ? raw.server : {};
    const updates = (0, validate_1.isObject)(raw.updates) ? raw.updates : {};
    const launcherUpdate = (0, validate_1.isObject)(raw.launcherUpdate) ? raw.launcherUpdate : {};
    const ui = (0, validate_1.isObject)(raw.ui) ? raw.ui : {};
    const graphics = (0, validate_1.isObject)(raw.graphics) ? raw.graphics : {};
    const launch = (0, validate_1.isObject)(raw.launch) ? raw.launch : {};
    const realmHost = (0, validate_1.pickString)(server.realmHost, d.server.realmHost)
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9.-]/g, '');
    return {
        version: (0, validate_1.pickNumber)(raw.version, exports.CONFIG_VERSION),
        server: {
            name: (0, validate_1.pickString)(server.name, d.server.name).slice(0, 64),
            tagline: (0, validate_1.pickString)(server.tagline, d.server.tagline).slice(0, 128),
            clientVersion: (0, validate_1.pickString)(server.clientVersion, d.server.clientVersion).slice(0, 16),
            expectedBuild: Math.floor((0, validate_1.pickNumber)(server.expectedBuild, d.server.expectedBuild)),
            realmHost: realmHost || d.server.realmHost,
            realmPort: Math.min(65535, Math.max(1, Math.floor((0, validate_1.pickNumber)(server.realmPort, d.server.realmPort)))),
            websiteUrl: (0, validate_1.sanitizeHttpsUrl)(server.websiteUrl),
            supportUrl: (0, validate_1.sanitizeHttpsUrl)(server.supportUrl),
            statusUrl: (0, validate_1.sanitizeHttpsUrl)(server.statusUrl)
        },
        updates: {
            enabled: (0, validate_1.pickBool)(updates.enabled, d.updates.enabled),
            manifestUrl: (0, validate_1.sanitizeHttpsUrl)(updates.manifestUrl),
            channel: (0, validate_1.pickString)(updates.channel, 'stable').slice(0, 32)
        },
        launcherUpdate: {
            enabled: (0, validate_1.pickBool)(launcherUpdate.enabled, d.launcherUpdate.enabled),
            manifestUrl: (0, validate_1.sanitizeHttpsUrl)(launcherUpdate.manifestUrl)
        },
        ui: {
            defaultLocale: (0, validate_1.pickEnum)(ui.defaultLocale, validate_1.LOCALES, d.ui.defaultLocale),
            theme: (0, validate_1.pickEnum)(ui.theme, validate_1.THEMES, d.ui.theme)
        },
        graphics: {
            quality: (0, validate_1.pickEnum)(graphics.quality, validate_1.GRAPHICS_QUALITIES, d.graphics.quality),
            particles: (0, validate_1.pickEnum)(graphics.particles, validate_1.PARTICLE_KINDS, d.graphics.particles)
        },
        launch: {
            extraArgs: (0, validate_1.pickStringArray)(launch.extraArgs, d.launch.extraArgs),
            autoFixRealmlist: (0, validate_1.pickBool)(launch.autoFixRealmlist, d.launch.autoFixRealmlist),
            elevateIfReadonly: (0, validate_1.pickBool)(launch.elevateIfReadonly, d.launch.elevateIfReadonly),
            minimizeOnGameStart: (0, validate_1.pickBool)(launch.minimizeOnGameStart, d.launch.minimizeOnGameStart)
        }
    };
}
/** Дефолтная пользовательская конфигурация (создаётся при первом запуске). */
function defaultUserConfig(server) {
    return {
        version: exports.CONFIG_VERSION,
        clientPath: null,
        ui: { locale: server.ui.defaultLocale, theme: server.ui.theme },
        graphics: {
            quality: server.graphics.quality,
            particles: server.graphics.particles,
            parallax: true,
            fog: true,
            runes: true,
            fpsCap: 30
        },
        launch: {
            extraArgs: [...server.launch.extraArgs],
            autoFixRealmlist: server.launch.autoFixRealmlist,
            elevateIfReadonly: server.launch.elevateIfReadonly,
            minimizeOnGameStart: server.launch.minimizeOnGameStart,
            windowed: false,
            console: false
        },
        updates: { enabled: server.updates.enabled },
        launcherUpdate: { enabled: server.launcherUpdate.enabled },
        firstRun: true
    };
}
/** Приводит произвольный JSON к валидному UserConfig (миграции + fallback'и). */
function sanitizeUserConfig(raw, server) {
    const d = defaultUserConfig(server);
    if (!(0, validate_1.isObject)(raw))
        return d;
    const ui = (0, validate_1.isObject)(raw.ui) ? raw.ui : {};
    const graphics = (0, validate_1.isObject)(raw.graphics) ? raw.graphics : {};
    const launch = (0, validate_1.isObject)(raw.launch) ? raw.launch : {};
    const updates = (0, validate_1.isObject)(raw.updates) ? raw.updates : {};
    const launcherUpdate = (0, validate_1.isObject)(raw.launcherUpdate) ? raw.launcherUpdate : {};
    const clientPath = (0, validate_1.pickStringOrNull)(raw.clientPath);
    const fpsCapRaw = (0, validate_1.pickNumber)(graphics.fpsCap, 30);
    return {
        version: exports.CONFIG_VERSION,
        clientPath,
        ui: {
            locale: (0, validate_1.pickEnum)(ui.locale, validate_1.LOCALES, d.ui.locale),
            theme: (0, validate_1.pickEnum)(ui.theme, validate_1.THEMES, d.ui.theme)
        },
        graphics: {
            quality: (0, validate_1.pickEnum)(graphics.quality, validate_1.GRAPHICS_QUALITIES, d.graphics.quality),
            particles: (0, validate_1.pickEnum)(graphics.particles, validate_1.PARTICLE_KINDS, d.graphics.particles),
            parallax: (0, validate_1.pickBool)(graphics.parallax, d.graphics.parallax),
            fog: (0, validate_1.pickBool)(graphics.fog, d.graphics.fog),
            runes: (0, validate_1.pickBool)(graphics.runes, d.graphics.runes),
            fpsCap: fpsCapRaw >= 60 ? 60 : 30
        },
        launch: {
            extraArgs: (0, validate_1.pickStringArray)(launch.extraArgs, d.launch.extraArgs),
            autoFixRealmlist: (0, validate_1.pickBool)(launch.autoFixRealmlist, d.launch.autoFixRealmlist),
            elevateIfReadonly: (0, validate_1.pickBool)(launch.elevateIfReadonly, d.launch.elevateIfReadonly),
            minimizeOnGameStart: (0, validate_1.pickBool)(launch.minimizeOnGameStart, d.launch.minimizeOnGameStart),
            windowed: (0, validate_1.pickBool)(launch.windowed, d.launch.windowed),
            console: (0, validate_1.pickBool)(launch.console, d.launch.console)
        },
        updates: { enabled: (0, validate_1.pickBool)(updates.enabled, d.updates.enabled) },
        launcherUpdate: { enabled: (0, validate_1.pickBool)(launcherUpdate.enabled, d.launcherUpdate.enabled) },
        firstRun: (0, validate_1.pickBool)(raw.firstRun, d.firstRun)
    };
}
