"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Unit-тесты: защита от path traversal (safeJoin / isInside / normalizeDirInput).
 */
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const node_path_1 = __importDefault(require("node:path"));
const safePath_1 = require("../src/main/util/safePath");
const BASE = node_path_1.default.resolve('/home/user/wow-client');
(0, node_test_1.test)('safeJoin: обычный относительный путь', () => {
    strict_1.default.equal((0, safePath_1.safeJoin)(BASE, 'Data/common.MPQ'), node_path_1.default.join(BASE, 'Data', 'common.MPQ'));
});
(0, node_test_1.test)('safeJoin: backslash-разделители нормализуются', () => {
    strict_1.default.equal((0, safePath_1.safeJoin)(BASE, 'Data\\common.MPQ'), node_path_1.default.join(BASE, 'Data', 'common.MPQ'));
});
(0, node_test_1.test)('safeJoin: блокирует ../', () => {
    strict_1.default.throws(() => (0, safePath_1.safeJoin)(BASE, '../../etc/passwd'), safePath_1.PathTraversalError);
});
(0, node_test_1.test)('safeJoin: блокирует ведущий слэш (абсолютный путь)', () => {
    strict_1.default.throws(() => (0, safePath_1.safeJoin)(BASE, '/etc/passwd'), safePath_1.PathTraversalError);
});
(0, node_test_1.test)('safeJoin: блокирует Windows-диск', () => {
    strict_1.default.throws(() => (0, safePath_1.safeJoin)(BASE, 'C:/Windows/system32/config.sam'), safePath_1.PathTraversalError);
});
(0, node_test_1.test)('safeJoin: блокирует UNC-пути', () => {
    strict_1.default.throws(() => (0, safePath_1.safeJoin)(BASE, '\\\\evil\\share\\x'), safePath_1.PathTraversalError);
});
(0, node_test_1.test)('safeJoin: блокирует нуль-байты', () => {
    strict_1.default.throws(() => (0, safePath_1.safeJoin)(BASE, 'Data/x\0.png'), safePath_1.PathTraversalError);
});
(0, node_test_1.test)('safeJoin: маскировка ".." внутри имени не проходит как traversal-сегмент', () => {
    // "file..txt" — легально, ".." не отдельный сегмент
    strict_1.default.equal((0, safePath_1.safeJoin)(BASE, 'Data/file..txt'), node_path_1.default.join(BASE, 'Data', 'file..txt'));
});
(0, node_test_1.test)('isInside: корректные проверки', () => {
    strict_1.default.equal((0, safePath_1.isInside)(BASE, node_path_1.default.join(BASE, 'Data')), true);
    strict_1.default.equal((0, safePath_1.isInside)(BASE, BASE), true);
    strict_1.default.equal((0, safePath_1.isInside)(BASE, node_path_1.default.join(BASE, '..', 'other')), false);
});
(0, node_test_1.test)('normalizeDirInput: убирает кавычки и хвостовые слеши', () => {
    strict_1.default.equal((0, safePath_1.normalizeDirInput)(' "D:\\Games\\WoW\\" '), 'D:\\Games\\WoW');
});
