"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Unit-тесты: sanitizer'ы конфигурации и манифестов.
 */
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const schema_1 = require("../src/main/services/config/schema");
const manifestSchema_1 = require("../src/main/services/updater/manifestSchema");
const semver_1 = require("../src/main/util/semver");
const validate_1 = require("../src/shared/validate");
(0, node_test_1.test)('server config: http-URL отклоняется (только HTTPS)', () => {
    const cfg = (0, schema_1.sanitizeServerConfig)({
        server: { realmHost: 'play.wosergame.net' },
        updates: { manifestUrl: 'http://evil.net/m.json' },
        launcherUpdate: { manifestUrl: 'https://ok.net/u.json' }
    });
    strict_1.default.equal(cfg.updates.manifestUrl, null);
    strict_1.default.equal(cfg.launcherUpdate.manifestUrl, 'https://ok.net/u.json');
});
(0, node_test_1.test)('server config: realmHost очищается от мусора', () => {
    const cfg = (0, schema_1.sanitizeServerConfig)({ server: { realmHost: '  PLAY.Wosergame.NET/../x  ', realmPort: 999999 } });
    strict_1.default.equal(cfg.server.realmHost, 'play.wosergame.net..x');
    strict_1.default.equal(cfg.server.realmPort, 65535);
});
(0, node_test_1.test)('server config: битый JSON → встроенный fallback', () => {
    const cfg = (0, schema_1.sanitizeServerConfig)('not-an-object');
    strict_1.default.equal(cfg.server.realmHost, 'play.wosergame.net');
    strict_1.default.equal(cfg.server.realmPort, 3724);
});
(0, node_test_1.test)('user config: неизвестные поля отбрасываются, дефолты подставляются', () => {
    const server = (0, schema_1.sanitizeServerConfig)({});
    const user = (0, schema_1.sanitizeUserConfig)({ graphics: { quality: 'ultra', fpsCap: 144 }, ui: { locale: 'de' } }, server);
    strict_1.default.equal(user.graphics.quality, 'auto'); // 'ultra' нет в enum → дефолт
    strict_1.default.equal(user.graphics.fpsCap, 60); // 144 → кламп до максимума (60)
    strict_1.default.equal(user.ui.locale, 'ru'); // 'de' не поддерживается
});
(0, node_test_1.test)('user config: валидные значения сохраняются', () => {
    const server = (0, schema_1.sanitizeServerConfig)({});
    const user = (0, schema_1.sanitizeUserConfig)({ clientPath: 'D:\\Games\\WoW', graphics: { quality: 'low', fpsCap: 60, particles: 'snow' }, launch: { windowed: true, extraArgs: ['-console', 42] } }, server);
    strict_1.default.equal(user.clientPath, 'D:\\Games\\WoW');
    strict_1.default.equal(user.graphics.quality, 'low');
    strict_1.default.equal(user.graphics.fpsCap, 60);
    strict_1.default.equal(user.graphics.particles, 'snow');
    strict_1.default.equal(user.launch.windowed, true);
    strict_1.default.deepEqual(user.launch.extraArgs, ['-console']); // число отброшено
});
(0, node_test_1.test)('defaultUserConfig наследует серверные значения', () => {
    const server = (0, schema_1.sanitizeServerConfig)({ ui: { defaultLocale: 'en' }, graphics: { particles: 'ash' } });
    const user = (0, schema_1.defaultUserConfig)(server);
    strict_1.default.equal(user.ui.locale, 'en');
    strict_1.default.equal(user.graphics.particles, 'ash');
    strict_1.default.equal(user.firstRun, true);
});
(0, node_test_1.test)('manifest: валидный разбирается', () => {
    const r = (0, manifestSchema_1.parseClientManifest)({
        version: 3,
        baseUrl: 'https://cdn.wosergame.net/patch/',
        files: [{ path: 'Data/common.MPQ', sha256: 'a'.repeat(64), size: 100 }]
    });
    strict_1.default.equal(r.ok, true);
    strict_1.default.equal(r.manifest?.files.length, 1);
});
(0, node_test_1.test)('manifest: http baseUrl отклоняется', () => {
    const r = (0, manifestSchema_1.parseClientManifest)({ version: 1, baseUrl: 'http://x/', files: [{ path: 'a', sha256: 'a'.repeat(64), size: 1 }] });
    strict_1.default.equal(r.ok, false);
});
(0, node_test_1.test)('manifest: traversal-пути отбрасываются поштучно', () => {
    const r = (0, manifestSchema_1.parseClientManifest)({
        version: 1,
        baseUrl: null,
        files: [
            { path: '../../etc/passwd', sha256: 'a'.repeat(64), size: 1 },
            { path: 'Data/ok.MPQ', sha256: 'b'.repeat(64), size: 2 }
        ]
    });
    strict_1.default.equal(r.ok, true);
    strict_1.default.equal(r.manifest?.files.length, 1);
    strict_1.default.equal(r.manifest?.files[0].path, 'Data/ok.MPQ');
});
(0, node_test_1.test)('manifest: битый sha256 отбрасывает запись', () => {
    const r = (0, manifestSchema_1.parseClientManifest)({ version: 1, files: [{ path: 'a.MPQ', sha256: 'zz', size: 1 }] });
    strict_1.default.equal(r.ok, false);
});
(0, node_test_1.test)('semver: сравнение версий', () => {
    strict_1.default.equal((0, semver_1.compareVersions)('1.2.3', '1.2.4'), -1);
    strict_1.default.equal((0, semver_1.compareVersions)('2.0.0', '1.9.9'), 1);
    strict_1.default.equal((0, semver_1.compareVersions)('1.0.0', 'v1.0.0'), 0);
    strict_1.default.equal((0, semver_1.isValidVersion)('1.0.0-beta.1'), true);
    strict_1.default.equal((0, semver_1.isValidVersion)('lol'), false);
});
(0, node_test_1.test)('sanitizeHttpsUrl: отклоняет userinfo и http', () => {
    strict_1.default.equal((0, validate_1.sanitizeHttpsUrl)('https://user:pass@x.ru/a'), null);
    strict_1.default.equal((0, validate_1.sanitizeHttpsUrl)('http://x.ru'), null);
    strict_1.default.equal((0, validate_1.sanitizeHttpsUrl)('https://x.ru/a?b=1'), 'https://x.ru/a?b=1');
});
