"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Unit-тесты: чистая логика realmlist.wtf (parse/build).
 * Запуск: npm test
 */
const node_test_1 = require("node:test");
const strict_1 = __importDefault(require("node:assert/strict"));
const realmlistCore_1 = require("../src/main/services/wow/realmlistCore");
(0, node_test_1.test)('parse: извлекает хост из классической строки', () => {
    const p = (0, realmlistCore_1.parseRealmlist)('set realmlist play.wosergame.net\n');
    strict_1.default.equal(p.host, 'play.wosergame.net');
    strict_1.default.equal(p.hadFile, true);
});
(0, node_test_1.test)('parse: регистронезависимость и пробелы', () => {
    const p = (0, realmlistCore_1.parseRealmlist)('  SET   Realmlist   PLAY.Wosergame.NET  \r\n');
    strict_1.default.equal(p.host, 'play.wosergame.net');
});
(0, node_test_1.test)('parse: пустой файл → host null', () => {
    const p = (0, realmlistCore_1.parseRealmlist)('');
    strict_1.default.equal(p.host, null);
});
(0, node_test_1.test)('parse: файл отсутствует → hadFile false', () => {
    const p = (0, realmlistCore_1.parseRealmlist)(null);
    strict_1.default.equal(p.hadFile, false);
    strict_1.default.equal(p.host, null);
});
(0, node_test_1.test)('parse: set realmlistbn не перетирает realmlist', () => {
    const p = (0, realmlistCore_1.parseRealmlist)('set realmlistbn eu.actual.battle.net\nset realmlist old.host.ru\n');
    strict_1.default.equal(p.host, 'old.host.ru');
});
(0, node_test_1.test)('build: заменяет существующую строку, сохраняет остальные', () => {
    const src = 'set realmlist old.host.ru\nset patchlist old.host.ru\n# комментарий\n';
    const out = (0, realmlistCore_1.buildRealmlist)(src, 'play.wosergame.net');
    strict_1.default.match(out, /^set realmlist play\.wosergame\.net$/m);
    strict_1.default.match(out, /set patchlist old\.host\.ru/);
    strict_1.default.match(out, /# комментарий/);
    strict_1.default.equal(out.match(/set realmlist /gi)?.length, 1);
});
(0, node_test_1.test)('build: добавляет строку, если её не было', () => {
    const out = (0, realmlistCore_1.buildRealmlist)('set patchlist x\n', 'play.wosergame.net');
    strict_1.default.match(out, /set realmlist play\.wosergame\.net\n$/);
});
(0, node_test_1.test)('build: null-текст → минимальный файл', () => {
    strict_1.default.equal((0, realmlistCore_1.buildRealmlist)(null, 'play.wosergame.net'), 'set realmlist play.wosergame.net\n');
});
(0, node_test_1.test)('build: дубликаты set realmlist схлопываются в одну строку', () => {
    const src = 'set realmlist a.ru\nset realmlist b.ru\n';
    const out = (0, realmlistCore_1.buildRealmlist)(src, 'c.ru');
    strict_1.default.equal(out.match(/set realmlist/gi)?.length, 1);
    strict_1.default.match(out, /set realmlist c\.ru/);
});
(0, node_test_1.test)('build: sanitizes грязный хост', () => {
    const out = (0, realmlistCore_1.buildRealmlist)(null, '  PLAY.Wosergame.NET/../etc  ');
    const host = (0, realmlistCore_1.parseRealmlist)(out).host;
    strict_1.default.ok(host);
    // В хосте не остаётся slash, пробелов и прочих спецсимволов
    strict_1.default.ok(!host.includes('/'));
    strict_1.default.ok(!host.includes(' '));
    strict_1.default.equal(host, 'play.wosergame.net..etc');
});
(0, node_test_1.test)('extractHostFromLine', () => {
    strict_1.default.equal((0, realmlistCore_1.extractHostFromLine)('set realmlist play.wosergame.net'), 'play.wosergame.net');
    strict_1.default.equal((0, realmlistCore_1.extractHostFromLine)('set patchlist x'), null);
});
