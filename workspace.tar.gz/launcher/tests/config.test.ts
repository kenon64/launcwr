/**
 * Unit-тесты: sanitizer'ы конфигурации и манифестов.
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { sanitizeServerConfig, sanitizeUserConfig, defaultUserConfig } from '../src/main/services/config/schema'
import { parseClientManifest } from '../src/main/services/updater/manifestSchema'
import { compareVersions, isValidVersion } from '../src/main/util/semver'
import { sanitizeHttpsUrl } from '../src/shared/validate'

test('server config: http-URL отклоняется (только HTTPS)', () => {
  const cfg = sanitizeServerConfig({
    server: { realmHost: 'play.wosergame.net' },
    updates: { manifestUrl: 'http://evil.net/m.json' },
    launcherUpdate: { manifestUrl: 'https://ok.net/u.json' }
  })
  assert.equal(cfg.updates.manifestUrl, null)
  assert.equal(cfg.launcherUpdate.manifestUrl, 'https://ok.net/u.json')
})

test('server config: realmHost очищается от мусора', () => {
  const cfg = sanitizeServerConfig({ server: { realmHost: '  PLAY.Wosergame.NET/../x  ', realmPort: 999999 } })
  assert.equal(cfg.server.realmHost, 'play.wosergame.net..x')
  assert.equal(cfg.server.realmPort, 65535)
})

test('server config: битый JSON → встроенный fallback', () => {
  const cfg = sanitizeServerConfig('not-an-object')
  assert.equal(cfg.server.realmHost, 'play.wosergame.net')
  assert.equal(cfg.server.realmPort, 3724)
})

test('user config: неизвестные поля отбрасываются, дефолты подставляются', () => {
  const server = sanitizeServerConfig({})
  const user = sanitizeUserConfig({ graphics: { quality: 'ultra', fpsCap: 144 }, ui: { locale: 'de' } }, server)
  assert.equal(user.graphics.quality, 'auto') // 'ultra' нет в enum → дефолт
  assert.equal(user.graphics.fpsCap, 60) // 144 → кламп до максимума (60)
  assert.equal(user.ui.locale, 'ru') // 'de' не поддерживается
})

test('user config: валидные значения сохраняются', () => {
  const server = sanitizeServerConfig({})
  const user = sanitizeUserConfig(
    { clientPath: 'D:\\Games\\WoW', graphics: { quality: 'low', fpsCap: 60, particles: 'snow' }, launch: { windowed: true, extraArgs: ['-console', 42] } },
    server
  )
  assert.equal(user.clientPath, 'D:\\Games\\WoW')
  assert.equal(user.graphics.quality, 'low')
  assert.equal(user.graphics.fpsCap, 60)
  assert.equal(user.graphics.particles, 'snow')
  assert.equal(user.launch.windowed, true)
  assert.deepEqual(user.launch.extraArgs, ['-console']) // число отброшено
})

test('defaultUserConfig наследует серверные значения', () => {
  const server = sanitizeServerConfig({ ui: { defaultLocale: 'en' }, graphics: { particles: 'ash' } })
  const user = defaultUserConfig(server)
  assert.equal(user.ui.locale, 'en')
  assert.equal(user.graphics.particles, 'ash')
  assert.equal(user.firstRun, true)
})

test('manifest: валидный разбирается', () => {
  const r = parseClientManifest({
    version: 3,
    baseUrl: 'https://cdn.wosergame.net/patch/',
    files: [{ path: 'Data/common.MPQ', sha256: 'a'.repeat(64), size: 100 }]
  })
  assert.equal(r.ok, true)
  assert.equal(r.manifest?.files.length, 1)
})

test('manifest: http baseUrl отклоняется', () => {
  const r = parseClientManifest({ version: 1, baseUrl: 'http://x/', files: [{ path: 'a', sha256: 'a'.repeat(64), size: 1 }] })
  assert.equal(r.ok, false)
})

test('manifest: traversal-пути отбрасываются поштучно', () => {
  const r = parseClientManifest({
    version: 1,
    baseUrl: null,
    files: [
      { path: '../../etc/passwd', sha256: 'a'.repeat(64), size: 1 },
      { path: 'Data/ok.MPQ', sha256: 'b'.repeat(64), size: 2 }
    ]
  })
  assert.equal(r.ok, true)
  assert.equal(r.manifest?.files.length, 1)
  assert.equal(r.manifest?.files[0].path, 'Data/ok.MPQ')
})

test('manifest: битый sha256 отбрасывает запись', () => {
  const r = parseClientManifest({ version: 1, files: [{ path: 'a.MPQ', sha256: 'zz', size: 1 }] })
  assert.equal(r.ok, false)
})

test('semver: сравнение версий', () => {
  assert.equal(compareVersions('1.2.3', '1.2.4'), -1)
  assert.equal(compareVersions('2.0.0', '1.9.9'), 1)
  assert.equal(compareVersions('1.0.0', 'v1.0.0'), 0)
  assert.equal(isValidVersion('1.0.0-beta.1'), true)
  assert.equal(isValidVersion('lol'), false)
})

test('sanitizeHttpsUrl: отклоняет userinfo и http', () => {
  assert.equal(sanitizeHttpsUrl('https://user:pass@x.ru/a'), null)
  assert.equal(sanitizeHttpsUrl('http://x.ru'), null)
  assert.equal(sanitizeHttpsUrl('https://x.ru/a?b=1'), 'https://x.ru/a?b=1')
})
