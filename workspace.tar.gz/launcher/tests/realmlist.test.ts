/**
 * Unit-тесты: чистая логика realmlist.wtf (parse/build).
 * Запуск: npm test
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import { buildRealmlist, extractHostFromLine, parseRealmlist } from '../src/main/services/wow/realmlistCore'

test('parse: извлекает хост из классической строки', () => {
  const p = parseRealmlist('set realmlist play.wosergame.net\n')
  assert.equal(p.host, 'play.wosergame.net')
  assert.equal(p.hadFile, true)
})

test('parse: регистронезависимость и пробелы', () => {
  const p = parseRealmlist('  SET   Realmlist   PLAY.Wosergame.NET  \r\n')
  assert.equal(p.host, 'play.wosergame.net')
})

test('parse: пустой файл → host null', () => {
  const p = parseRealmlist('')
  assert.equal(p.host, null)
})

test('parse: файл отсутствует → hadFile false', () => {
  const p = parseRealmlist(null)
  assert.equal(p.hadFile, false)
  assert.equal(p.host, null)
})

test('parse: set realmlistbn не перетирает realmlist', () => {
  const p = parseRealmlist('set realmlistbn eu.actual.battle.net\nset realmlist old.host.ru\n')
  assert.equal(p.host, 'old.host.ru')
})

test('build: заменяет существующую строку, сохраняет остальные', () => {
  const src = 'set realmlist old.host.ru\nset patchlist old.host.ru\n# комментарий\n'
  const out = buildRealmlist(src, 'play.wosergame.net')
  assert.match(out, /^set realmlist play\.wosergame\.net$/m)
  assert.match(out, /set patchlist old\.host\.ru/)
  assert.match(out, /# комментарий/)
  assert.equal(out.match(/set realmlist /gi)?.length, 1)
})

test('build: добавляет строку, если её не было', () => {
  const out = buildRealmlist('set patchlist x\n', 'play.wosergame.net')
  assert.match(out, /set realmlist play\.wosergame\.net\n$/)
})

test('build: null-текст → минимальный файл', () => {
  assert.equal(buildRealmlist(null, 'play.wosergame.net'), 'set realmlist play.wosergame.net\n')
})

test('build: дубликаты set realmlist схлопываются в одну строку', () => {
  const src = 'set realmlist a.ru\nset realmlist b.ru\n'
  const out = buildRealmlist(src, 'c.ru')
  assert.equal(out.match(/set realmlist/gi)?.length, 1)
  assert.match(out, /set realmlist c\.ru/)
})

test('build: sanitizes грязный хост', () => {
  const out = buildRealmlist(null, '  PLAY.Wosergame.NET/../etc  ')
  const host = parseRealmlist(out).host
  assert.ok(host)
  // В хосте не остаётся slash, пробелов и прочих спецсимволов
  assert.ok(!host.includes('/'))
  assert.ok(!host.includes(' '))
  assert.equal(host, 'play.wosergame.net..etc')
})

test('extractHostFromLine', () => {
  assert.equal(extractHostFromLine('set realmlist play.wosergame.net'), 'play.wosergame.net')
  assert.equal(extractHostFromLine('set patchlist x'), null)
})
