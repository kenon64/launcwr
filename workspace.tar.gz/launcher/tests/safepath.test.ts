/**
 * Unit-тесты: защита от path traversal (safeJoin / isInside / normalizeDirInput).
 */
import { test } from 'node:test'
import assert from 'node:assert/strict'
import path from 'node:path'
import { isInside, normalizeDirInput, PathTraversalError, safeJoin } from '../src/main/util/safePath'

const BASE = path.resolve('/home/user/wow-client')

test('safeJoin: обычный относительный путь', () => {
  assert.equal(safeJoin(BASE, 'Data/common.MPQ'), path.join(BASE, 'Data', 'common.MPQ'))
})

test('safeJoin: backslash-разделители нормализуются', () => {
  assert.equal(safeJoin(BASE, 'Data\\common.MPQ'), path.join(BASE, 'Data', 'common.MPQ'))
})

test('safeJoin: блокирует ../', () => {
  assert.throws(() => safeJoin(BASE, '../../etc/passwd'), PathTraversalError)
})

test('safeJoin: блокирует ведущий слэш (абсолютный путь)', () => {
  assert.throws(() => safeJoin(BASE, '/etc/passwd'), PathTraversalError)
})

test('safeJoin: блокирует Windows-диск', () => {
  assert.throws(() => safeJoin(BASE, 'C:/Windows/system32/config.sam'), PathTraversalError)
})

test('safeJoin: блокирует UNC-пути', () => {
  assert.throws(() => safeJoin(BASE, '\\\\evil\\share\\x'), PathTraversalError)
})

test('safeJoin: блокирует нуль-байты', () => {
  assert.throws(() => safeJoin(BASE, 'Data/x\0.png'), PathTraversalError)
})

test('safeJoin: маскировка ".." внутри имени не проходит как traversal-сегмент', () => {
  // "file..txt" — легально, ".." не отдельный сегмент
  assert.equal(safeJoin(BASE, 'Data/file..txt'), path.join(BASE, 'Data', 'file..txt'))
})

test('isInside: корректные проверки', () => {
  assert.equal(isInside(BASE, path.join(BASE, 'Data')), true)
  assert.equal(isInside(BASE, BASE), true)
  assert.equal(isInside(BASE, path.join(BASE, '..', 'other')), false)
})

test('normalizeDirInput: убирает кавычки и хвостовые слеши', () => {
  assert.equal(normalizeDirInput(' "D:\\Games\\WoW\\" '), 'D:\\Games\\WoW')
})
